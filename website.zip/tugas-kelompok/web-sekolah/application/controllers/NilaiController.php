<?php
defined('BASEPATH') or exit('No direct script access allowed');

class NilaiController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('NilaiModel');
    }

    public function index()
    {
        $data['siswa'] = $this->NilaiModel->getSiswa();
        $data['mata_pelajaran'] = $this->NilaiModel->getMataPelajaran();
        $this->load->view('nilai_form', $data);
    }

    public function simpan()
    {
        $data = [
            'id_siswa' => $this->input->post('id_siswa'),
            'id_mapel' => $this->input->post('id_mapel'),
            'jenis_nilai' => $this->input->post('jenis_nilai'),
            'nilai' => $this->input->post('nilai'),
            'semester' => $this->input->post('semester'),
            'tahun_ajaran' => $this->input->post('tahun_ajaran')
        ];

        $this->NilaiModel->simpanNilai($data);
        redirect('NilaiController/index');
    }

    public function edit($id_nilai)
    {
        // Logic untuk edit nilai
    }

    public function delete($id_nilai)
    {
        $this->NilaiModel->deleteNilai($id_nilai);
        redirect('NilaiController/index');
    }
}
