<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_home');
        $this->load->model('m_guru');
    }

    public function index()
    {
        $data = array(
                'title'  =>'Web Sekolah',
                'berita' =>$this->m_home->course_berita(),
                'guru'   =>$this->m_guru->list(),
                'isi'    =>'v_home',
        );
        $this->load->view('layout/v_wrapperhome',$data,FALSE);
    }

    public function guru()
    {
        $data = array(
            'title'     => 'Guru',
            'guru'      => $this->m_home->guru(),
            'isi'       => 'v_guru'
        );
        $this->load->view('layout/v_wrapper',$data,FALSE);

    }
    public function berita()
    {
        $this->load->library('pagination');
        $config['base_url']     = base_url('home/berita');
        $config['total_rows']   = count($this->m_home->total_berita());
        $config['per_page']     = 8;
        $config['uri_segment']   = 3;
        
        $limit= $config['per_page'];
        $start= ($this->uri->segment(3)) ? ($this->uri->segment(3)) : 0;

        $config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagination_container d-flex flex-row align-items-center justify-content-start text-center"><ul class="pagination_list">';
        $config['num_tag_open']     = '<li>';
        $config['num_tag_close']    = '</li>';
        $config['cur_tag_open']     = '<li class="active"><a>';
        $config['cur_tag_close']    = '</a></li>';
        $config['next_tag_open']    = '<li>';
        $config['next_tag_close']   = '</li>';
        $config['prev_tag_open']    = '<li>';
        $config['prev_tag_close']   = '</li>';
        $config['first_tag_open']   = '<li>';
        $config['first_tag_close']  = '</li>';
        $config['last_tag_open']    = '<li>';
        $config['last_tag_close']   = '</li>';
        $config['full_tag_close']   = '</ul></div>';

        $this->pagination->initialize($config);


        $data = array(
            'paginasi'      =>$this->pagination->create_links(),
            'latest_berita' =>$this->m_home->latest_berita(),
            'berita'        =>$this->m_home->berita($limit,$start),
            'title'         => 'Berita',
            'isi'           => 'v_berita'
        );
        $this->load->view('layout/v_wrapper',$data,FALSE);

    }
    public function detail_berita($slug_berita)
    {
        $data = array(
            'title'         =>'Detail Berita',
            'latest_berita' =>$this->m_home->latest_berita(),
            'berita'        =>$this->m_home->detail_berita($slug_berita),
            'isi'           =>'v_detail_berita'
        );
        $this->load->view('layout/v_wrapper',$data,FALSE);
    }
    public function gallery()
    {
        $data = array(
            'title'     =>'Gallery Foto',
            'gallery'   =>$this->m_home->gallery(),
            'isi'       =>'v_gallery'
        );
        $this->load->view('layout/v_wrapper',$data,FALSE);
    }
    public function detail_gallery($id_gallery)
    {
        $data = array(
            'title'         =>'Detail Gallery Foto',
            'gallery'       =>$this->m_home->detail_gallery($id_gallery),
            'nama_gallery'  =>$this->m_home->nama_gallery($id_gallery),
            'isi'           =>'v_detail_gallery'
        );
        $this->load->view('layout/v_wrapper',$data,FALSE);
    }
    public function profile()
    {
        $data = array(
            'title'     =>'Profile Sekolah',
            'sekolah'   =>$this->m_setting->detail(),
            'isi'       =>'v_profile'
        );
        $this->load->view('layout/v_wrapper',$data,FALSE);
    }
    public function contact()
    {
        $data = array(
            'title'     =>'Contact Sekolah',
            'sekolah'   => $this->m_setting->detail(),
            'isi'       =>'v_hubkami'
        );
        $this->load->view('layout/v_wrapper',$data,FALSE);
    }

    public function send() {
        // Proses data dari formulir kontak
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = htmlspecialchars($this->input->post('name'));
            $email = htmlspecialchars($this->input->post('email'));
            $message = htmlspecialchars($this->input->post('message'));

            // Konfigurasi email (gunakan mail() atau library)
            $to = "your-email@example.com";
            $subject = "New Contact Form Submission";
            $headers = "From: sdn15kabila@gmail.com\r\n";
            $headers .= "Reply-To: $email\r\n";
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

            $body = "Name: $name\nEmail: $email\n\nMessage:\n$message";

            // Kirim email
            if (mail($to, $subject, $body, $headers)) {
                $this->session->set_flashdata('success', 'Pesan berhasil terkirim.');
            } else {
                $this->session->set_flashdata('error', 'Gagal mengirim pesan.');
            }

            // Redirect ke halaman formulir kontak
            redirect('contact');
    
        }
        $this->Contact_model->save_message([
            'name' => $name,
            'email' => $email,
            'message' => $message,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
    }

}