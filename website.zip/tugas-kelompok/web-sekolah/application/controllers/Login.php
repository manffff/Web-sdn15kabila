<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function index()
    {
        // Set aturan validasi untuk form input
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        // Cek apakah validasi form berjalan dengan benar
        if ($this->form_validation->run() == TRUE) {
            // Ambil data input dari form
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            // Panggil model atau fungsi untuk login
            $this->user_login->login($username, $password);
        }

        // Data yang dikirim ke view
        $data = array('title' => 'Login');

        // Load view login dengan data yang sudah disiapkan
        $this->load->view('v_login', $data, FALSE);
    }
    public function logout()
    {
        $this->user_login->logout();
    }
}
