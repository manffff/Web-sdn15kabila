<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-12 15:12:15 --> Config Class Initialized
INFO - 2024-12-12 15:12:15 --> Hooks Class Initialized
DEBUG - 2024-12-12 15:12:15 --> UTF-8 Support Enabled
INFO - 2024-12-12 15:12:15 --> Utf8 Class Initialized
INFO - 2024-12-12 15:12:15 --> URI Class Initialized
INFO - 2024-12-12 15:12:15 --> Router Class Initialized
INFO - 2024-12-12 15:12:15 --> Output Class Initialized
INFO - 2024-12-12 15:12:15 --> Security Class Initialized
DEBUG - 2024-12-12 15:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 15:12:15 --> Input Class Initialized
INFO - 2024-12-12 15:12:15 --> Language Class Initialized
INFO - 2024-12-12 15:12:15 --> Loader Class Initialized
INFO - 2024-12-12 15:12:15 --> Helper loaded: url_helper
INFO - 2024-12-12 15:12:15 --> Helper loaded: form_helper
INFO - 2024-12-12 15:12:15 --> Helper loaded: file_helper
INFO - 2024-12-12 15:12:15 --> Database Driver Class Initialized
DEBUG - 2024-12-12 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-12 15:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-12 15:12:15 --> Form Validation Class Initialized
INFO - 2024-12-12 15:12:15 --> Upload Class Initialized
INFO - 2024-12-12 15:12:15 --> Model "M_login" initialized
INFO - 2024-12-12 15:12:15 --> Model "M_home" initialized
INFO - 2024-12-12 15:12:15 --> Model "M_setting" initialized
INFO - 2024-12-12 15:12:15 --> Controller Class Initialized
INFO - 2024-12-12 15:12:15 --> Model "M_guru" initialized
INFO - 2024-12-12 15:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-12 15:12:15 --> Pagination Class Initialized
INFO - 2024-12-12 15:12:15 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-12 15:12:15 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-12 15:12:15 --> Final output sent to browser
DEBUG - 2024-12-12 15:12:15 --> Total execution time: 0.4297
INFO - 2024-12-12 15:12:44 --> Config Class Initialized
INFO - 2024-12-12 15:12:44 --> Hooks Class Initialized
DEBUG - 2024-12-12 15:12:44 --> UTF-8 Support Enabled
INFO - 2024-12-12 15:12:44 --> Utf8 Class Initialized
INFO - 2024-12-12 15:12:44 --> URI Class Initialized
INFO - 2024-12-12 15:12:44 --> Router Class Initialized
INFO - 2024-12-12 15:12:44 --> Output Class Initialized
INFO - 2024-12-12 15:12:44 --> Security Class Initialized
DEBUG - 2024-12-12 15:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 15:12:44 --> Input Class Initialized
INFO - 2024-12-12 15:12:44 --> Language Class Initialized
INFO - 2024-12-12 15:12:44 --> Loader Class Initialized
INFO - 2024-12-12 15:12:44 --> Helper loaded: url_helper
INFO - 2024-12-12 15:12:44 --> Helper loaded: form_helper
INFO - 2024-12-12 15:12:44 --> Helper loaded: file_helper
INFO - 2024-12-12 15:12:44 --> Database Driver Class Initialized
DEBUG - 2024-12-12 15:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-12 15:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-12 15:12:44 --> Form Validation Class Initialized
INFO - 2024-12-12 15:12:44 --> Upload Class Initialized
INFO - 2024-12-12 15:12:44 --> Model "M_login" initialized
INFO - 2024-12-12 15:12:44 --> Model "M_home" initialized
INFO - 2024-12-12 15:12:44 --> Model "M_setting" initialized
INFO - 2024-12-12 15:12:44 --> Controller Class Initialized
INFO - 2024-12-12 15:12:44 --> Model "M_guru" initialized
INFO - 2024-12-12 15:12:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-12 15:12:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-12 15:12:44 --> Final output sent to browser
DEBUG - 2024-12-12 15:12:44 --> Total execution time: 0.1245
INFO - 2024-12-12 15:12:44 --> Config Class Initialized
INFO - 2024-12-12 15:12:44 --> Hooks Class Initialized
DEBUG - 2024-12-12 15:12:44 --> UTF-8 Support Enabled
INFO - 2024-12-12 15:12:44 --> Utf8 Class Initialized
INFO - 2024-12-12 15:12:44 --> URI Class Initialized
INFO - 2024-12-12 15:12:44 --> Router Class Initialized
INFO - 2024-12-12 15:12:44 --> Output Class Initialized
INFO - 2024-12-12 15:12:44 --> Security Class Initialized
DEBUG - 2024-12-12 15:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 15:12:44 --> Input Class Initialized
INFO - 2024-12-12 15:12:44 --> Language Class Initialized
ERROR - 2024-12-12 15:12:44 --> 404 Page Not Found: Home/images
INFO - 2024-12-12 15:13:15 --> Config Class Initialized
INFO - 2024-12-12 15:13:15 --> Hooks Class Initialized
DEBUG - 2024-12-12 15:13:15 --> UTF-8 Support Enabled
INFO - 2024-12-12 15:13:15 --> Utf8 Class Initialized
INFO - 2024-12-12 15:13:15 --> URI Class Initialized
INFO - 2024-12-12 15:13:15 --> Router Class Initialized
INFO - 2024-12-12 15:13:15 --> Output Class Initialized
INFO - 2024-12-12 15:13:15 --> Security Class Initialized
DEBUG - 2024-12-12 15:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 15:13:15 --> Input Class Initialized
INFO - 2024-12-12 15:13:15 --> Language Class Initialized
INFO - 2024-12-12 15:13:15 --> Loader Class Initialized
INFO - 2024-12-12 15:13:15 --> Helper loaded: url_helper
INFO - 2024-12-12 15:13:15 --> Helper loaded: form_helper
INFO - 2024-12-12 15:13:15 --> Helper loaded: file_helper
INFO - 2024-12-12 15:13:15 --> Database Driver Class Initialized
DEBUG - 2024-12-12 15:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-12 15:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-12 15:13:15 --> Form Validation Class Initialized
INFO - 2024-12-12 15:13:15 --> Upload Class Initialized
INFO - 2024-12-12 15:13:15 --> Model "M_login" initialized
INFO - 2024-12-12 15:13:15 --> Model "M_home" initialized
INFO - 2024-12-12 15:13:15 --> Model "M_setting" initialized
INFO - 2024-12-12 15:13:15 --> Controller Class Initialized
INFO - 2024-12-12 15:13:15 --> Model "M_guru" initialized
INFO - 2024-12-12 15:13:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-12 15:13:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-12 15:13:16 --> Final output sent to browser
DEBUG - 2024-12-12 15:13:16 --> Total execution time: 0.1264
