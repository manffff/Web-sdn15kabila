<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-10 00:12:19 --> Config Class Initialized
INFO - 2024-12-10 00:12:19 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:12:19 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:12:19 --> Utf8 Class Initialized
INFO - 2024-12-10 00:12:19 --> URI Class Initialized
INFO - 2024-12-10 00:12:19 --> Router Class Initialized
INFO - 2024-12-10 00:12:19 --> Output Class Initialized
INFO - 2024-12-10 00:12:19 --> Security Class Initialized
DEBUG - 2024-12-10 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:12:19 --> Input Class Initialized
INFO - 2024-12-10 00:12:19 --> Language Class Initialized
INFO - 2024-12-10 00:12:19 --> Loader Class Initialized
INFO - 2024-12-10 00:12:19 --> Helper loaded: url_helper
INFO - 2024-12-10 00:12:19 --> Helper loaded: form_helper
INFO - 2024-12-10 00:12:19 --> Helper loaded: file_helper
INFO - 2024-12-10 00:12:19 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:12:19 --> Form Validation Class Initialized
INFO - 2024-12-10 00:12:19 --> Upload Class Initialized
INFO - 2024-12-10 00:12:19 --> Model "M_login" initialized
INFO - 2024-12-10 00:12:19 --> Model "M_home" initialized
INFO - 2024-12-10 00:12:19 --> Model "M_setting" initialized
INFO - 2024-12-10 00:12:19 --> Controller Class Initialized
INFO - 2024-12-10 00:12:19 --> Config Class Initialized
INFO - 2024-12-10 00:12:19 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:12:19 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:12:19 --> Utf8 Class Initialized
INFO - 2024-12-10 00:12:19 --> URI Class Initialized
INFO - 2024-12-10 00:12:19 --> Router Class Initialized
INFO - 2024-12-10 00:12:19 --> Output Class Initialized
INFO - 2024-12-10 00:12:19 --> Security Class Initialized
DEBUG - 2024-12-10 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:12:19 --> Input Class Initialized
INFO - 2024-12-10 00:12:19 --> Language Class Initialized
INFO - 2024-12-10 00:12:19 --> Loader Class Initialized
INFO - 2024-12-10 00:12:19 --> Helper loaded: url_helper
INFO - 2024-12-10 00:12:19 --> Helper loaded: form_helper
INFO - 2024-12-10 00:12:19 --> Helper loaded: file_helper
INFO - 2024-12-10 00:12:19 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:12:19 --> Form Validation Class Initialized
INFO - 2024-12-10 00:12:19 --> Upload Class Initialized
INFO - 2024-12-10 00:12:19 --> Model "M_login" initialized
INFO - 2024-12-10 00:12:19 --> Model "M_home" initialized
INFO - 2024-12-10 00:12:19 --> Model "M_setting" initialized
INFO - 2024-12-10 00:12:19 --> Controller Class Initialized
INFO - 2024-12-10 00:12:19 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_login.php
INFO - 2024-12-10 00:12:19 --> Final output sent to browser
DEBUG - 2024-12-10 00:12:19 --> Total execution time: 0.1212
INFO - 2024-12-10 00:12:23 --> Config Class Initialized
INFO - 2024-12-10 00:12:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:12:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:12:23 --> Utf8 Class Initialized
INFO - 2024-12-10 00:12:23 --> URI Class Initialized
INFO - 2024-12-10 00:12:23 --> Router Class Initialized
INFO - 2024-12-10 00:12:23 --> Output Class Initialized
INFO - 2024-12-10 00:12:23 --> Security Class Initialized
DEBUG - 2024-12-10 00:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:12:23 --> Input Class Initialized
INFO - 2024-12-10 00:12:23 --> Language Class Initialized
INFO - 2024-12-10 00:12:23 --> Loader Class Initialized
INFO - 2024-12-10 00:12:23 --> Helper loaded: url_helper
INFO - 2024-12-10 00:12:23 --> Helper loaded: form_helper
INFO - 2024-12-10 00:12:23 --> Helper loaded: file_helper
INFO - 2024-12-10 00:12:23 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:12:23 --> Form Validation Class Initialized
INFO - 2024-12-10 00:12:23 --> Upload Class Initialized
INFO - 2024-12-10 00:12:23 --> Model "M_login" initialized
INFO - 2024-12-10 00:12:23 --> Model "M_home" initialized
INFO - 2024-12-10 00:12:23 --> Model "M_setting" initialized
INFO - 2024-12-10 00:12:23 --> Controller Class Initialized
INFO - 2024-12-10 00:12:23 --> Model "M_guru" initialized
INFO - 2024-12-10 00:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 00:12:23 --> Pagination Class Initialized
INFO - 2024-12-10 00:12:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 00:12:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:12:23 --> Final output sent to browser
DEBUG - 2024-12-10 00:12:23 --> Total execution time: 0.2324
INFO - 2024-12-10 00:12:27 --> Config Class Initialized
INFO - 2024-12-10 00:12:27 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:12:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:12:27 --> Utf8 Class Initialized
INFO - 2024-12-10 00:12:27 --> URI Class Initialized
INFO - 2024-12-10 00:12:27 --> Router Class Initialized
INFO - 2024-12-10 00:12:27 --> Output Class Initialized
INFO - 2024-12-10 00:12:27 --> Security Class Initialized
DEBUG - 2024-12-10 00:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:12:27 --> Input Class Initialized
INFO - 2024-12-10 00:12:27 --> Language Class Initialized
INFO - 2024-12-10 00:12:27 --> Loader Class Initialized
INFO - 2024-12-10 00:12:27 --> Helper loaded: url_helper
INFO - 2024-12-10 00:12:27 --> Helper loaded: form_helper
INFO - 2024-12-10 00:12:27 --> Helper loaded: file_helper
INFO - 2024-12-10 00:12:27 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:12:27 --> Form Validation Class Initialized
INFO - 2024-12-10 00:12:27 --> Upload Class Initialized
INFO - 2024-12-10 00:12:27 --> Model "M_login" initialized
INFO - 2024-12-10 00:12:27 --> Model "M_home" initialized
INFO - 2024-12-10 00:12:27 --> Model "M_setting" initialized
INFO - 2024-12-10 00:12:27 --> Controller Class Initialized
INFO - 2024-12-10 00:12:27 --> Model "M_guru" initialized
INFO - 2024-12-10 00:12:27 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:12:27 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:12:27 --> Final output sent to browser
DEBUG - 2024-12-10 00:12:27 --> Total execution time: 0.1399
INFO - 2024-12-10 00:12:27 --> Config Class Initialized
INFO - 2024-12-10 00:12:27 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:12:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:12:27 --> Utf8 Class Initialized
INFO - 2024-12-10 00:12:27 --> URI Class Initialized
INFO - 2024-12-10 00:12:27 --> Router Class Initialized
INFO - 2024-12-10 00:12:27 --> Output Class Initialized
INFO - 2024-12-10 00:12:27 --> Security Class Initialized
DEBUG - 2024-12-10 00:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:12:27 --> Input Class Initialized
INFO - 2024-12-10 00:12:27 --> Language Class Initialized
ERROR - 2024-12-10 00:12:27 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:14:37 --> Config Class Initialized
INFO - 2024-12-10 00:14:37 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:14:37 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:14:37 --> Utf8 Class Initialized
INFO - 2024-12-10 00:14:37 --> URI Class Initialized
INFO - 2024-12-10 00:14:37 --> Router Class Initialized
INFO - 2024-12-10 00:14:37 --> Output Class Initialized
INFO - 2024-12-10 00:14:37 --> Security Class Initialized
DEBUG - 2024-12-10 00:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:14:37 --> Input Class Initialized
INFO - 2024-12-10 00:14:37 --> Language Class Initialized
INFO - 2024-12-10 00:14:37 --> Loader Class Initialized
INFO - 2024-12-10 00:14:37 --> Helper loaded: url_helper
INFO - 2024-12-10 00:14:37 --> Helper loaded: form_helper
INFO - 2024-12-10 00:14:37 --> Helper loaded: file_helper
INFO - 2024-12-10 00:14:37 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:14:37 --> Form Validation Class Initialized
INFO - 2024-12-10 00:14:37 --> Upload Class Initialized
INFO - 2024-12-10 00:14:37 --> Model "M_login" initialized
INFO - 2024-12-10 00:14:37 --> Model "M_home" initialized
INFO - 2024-12-10 00:14:37 --> Model "M_setting" initialized
INFO - 2024-12-10 00:14:37 --> Controller Class Initialized
INFO - 2024-12-10 00:14:37 --> Model "M_guru" initialized
INFO - 2024-12-10 00:14:37 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:14:37 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:14:37 --> Final output sent to browser
DEBUG - 2024-12-10 00:14:37 --> Total execution time: 0.2439
INFO - 2024-12-10 00:14:38 --> Config Class Initialized
INFO - 2024-12-10 00:14:38 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:14:38 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:14:38 --> Utf8 Class Initialized
INFO - 2024-12-10 00:14:38 --> URI Class Initialized
INFO - 2024-12-10 00:14:38 --> Router Class Initialized
INFO - 2024-12-10 00:14:38 --> Output Class Initialized
INFO - 2024-12-10 00:14:38 --> Security Class Initialized
DEBUG - 2024-12-10 00:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:14:38 --> Input Class Initialized
INFO - 2024-12-10 00:14:38 --> Language Class Initialized
ERROR - 2024-12-10 00:14:38 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:15:19 --> Config Class Initialized
INFO - 2024-12-10 00:15:19 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:19 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:19 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:19 --> URI Class Initialized
INFO - 2024-12-10 00:15:19 --> Router Class Initialized
INFO - 2024-12-10 00:15:19 --> Output Class Initialized
INFO - 2024-12-10 00:15:19 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:19 --> Input Class Initialized
INFO - 2024-12-10 00:15:19 --> Language Class Initialized
INFO - 2024-12-10 00:15:19 --> Loader Class Initialized
INFO - 2024-12-10 00:15:19 --> Helper loaded: url_helper
INFO - 2024-12-10 00:15:19 --> Helper loaded: form_helper
INFO - 2024-12-10 00:15:19 --> Helper loaded: file_helper
INFO - 2024-12-10 00:15:19 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:15:19 --> Form Validation Class Initialized
INFO - 2024-12-10 00:15:19 --> Upload Class Initialized
INFO - 2024-12-10 00:15:19 --> Model "M_login" initialized
INFO - 2024-12-10 00:15:19 --> Model "M_home" initialized
INFO - 2024-12-10 00:15:19 --> Model "M_setting" initialized
INFO - 2024-12-10 00:15:19 --> Controller Class Initialized
INFO - 2024-12-10 00:15:19 --> Model "M_guru" initialized
INFO - 2024-12-10 00:15:19 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:15:19 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:15:19 --> Final output sent to browser
DEBUG - 2024-12-10 00:15:19 --> Total execution time: 0.1464
INFO - 2024-12-10 00:15:19 --> Config Class Initialized
INFO - 2024-12-10 00:15:19 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:19 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:19 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:19 --> URI Class Initialized
INFO - 2024-12-10 00:15:19 --> Router Class Initialized
INFO - 2024-12-10 00:15:19 --> Output Class Initialized
INFO - 2024-12-10 00:15:19 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:19 --> Input Class Initialized
INFO - 2024-12-10 00:15:19 --> Language Class Initialized
ERROR - 2024-12-10 00:15:19 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:15:28 --> Config Class Initialized
INFO - 2024-12-10 00:15:28 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:28 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:28 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:28 --> URI Class Initialized
INFO - 2024-12-10 00:15:28 --> Router Class Initialized
INFO - 2024-12-10 00:15:28 --> Output Class Initialized
INFO - 2024-12-10 00:15:28 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:28 --> Input Class Initialized
INFO - 2024-12-10 00:15:28 --> Language Class Initialized
INFO - 2024-12-10 00:15:28 --> Loader Class Initialized
INFO - 2024-12-10 00:15:28 --> Helper loaded: url_helper
INFO - 2024-12-10 00:15:28 --> Helper loaded: form_helper
INFO - 2024-12-10 00:15:28 --> Helper loaded: file_helper
INFO - 2024-12-10 00:15:28 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:15:28 --> Form Validation Class Initialized
INFO - 2024-12-10 00:15:28 --> Upload Class Initialized
INFO - 2024-12-10 00:15:28 --> Model "M_login" initialized
INFO - 2024-12-10 00:15:28 --> Model "M_home" initialized
INFO - 2024-12-10 00:15:28 --> Model "M_setting" initialized
INFO - 2024-12-10 00:15:28 --> Controller Class Initialized
INFO - 2024-12-10 00:15:28 --> Model "M_guru" initialized
INFO - 2024-12-10 00:15:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:15:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:15:28 --> Final output sent to browser
DEBUG - 2024-12-10 00:15:28 --> Total execution time: 0.1239
INFO - 2024-12-10 00:15:28 --> Config Class Initialized
INFO - 2024-12-10 00:15:28 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:28 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:28 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:28 --> URI Class Initialized
INFO - 2024-12-10 00:15:28 --> Router Class Initialized
INFO - 2024-12-10 00:15:28 --> Output Class Initialized
INFO - 2024-12-10 00:15:28 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:28 --> Input Class Initialized
INFO - 2024-12-10 00:15:28 --> Language Class Initialized
ERROR - 2024-12-10 00:15:28 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:15:40 --> Config Class Initialized
INFO - 2024-12-10 00:15:40 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:40 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:40 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:40 --> URI Class Initialized
INFO - 2024-12-10 00:15:40 --> Router Class Initialized
INFO - 2024-12-10 00:15:40 --> Output Class Initialized
INFO - 2024-12-10 00:15:40 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:40 --> Input Class Initialized
INFO - 2024-12-10 00:15:40 --> Language Class Initialized
INFO - 2024-12-10 00:15:40 --> Loader Class Initialized
INFO - 2024-12-10 00:15:40 --> Helper loaded: url_helper
INFO - 2024-12-10 00:15:40 --> Helper loaded: form_helper
INFO - 2024-12-10 00:15:40 --> Helper loaded: file_helper
INFO - 2024-12-10 00:15:40 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:15:41 --> Form Validation Class Initialized
INFO - 2024-12-10 00:15:41 --> Upload Class Initialized
INFO - 2024-12-10 00:15:41 --> Model "M_login" initialized
INFO - 2024-12-10 00:15:41 --> Model "M_home" initialized
INFO - 2024-12-10 00:15:41 --> Model "M_setting" initialized
INFO - 2024-12-10 00:15:41 --> Controller Class Initialized
INFO - 2024-12-10 00:15:41 --> Model "M_guru" initialized
INFO - 2024-12-10 00:15:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:15:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:15:41 --> Final output sent to browser
DEBUG - 2024-12-10 00:15:41 --> Total execution time: 0.1266
INFO - 2024-12-10 00:15:41 --> Config Class Initialized
INFO - 2024-12-10 00:15:41 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:41 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:41 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:41 --> URI Class Initialized
INFO - 2024-12-10 00:15:41 --> Router Class Initialized
INFO - 2024-12-10 00:15:41 --> Output Class Initialized
INFO - 2024-12-10 00:15:41 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:41 --> Input Class Initialized
INFO - 2024-12-10 00:15:41 --> Language Class Initialized
ERROR - 2024-12-10 00:15:41 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:15:51 --> Config Class Initialized
INFO - 2024-12-10 00:15:51 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:51 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:51 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:51 --> URI Class Initialized
INFO - 2024-12-10 00:15:51 --> Router Class Initialized
INFO - 2024-12-10 00:15:51 --> Output Class Initialized
INFO - 2024-12-10 00:15:51 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:51 --> Input Class Initialized
INFO - 2024-12-10 00:15:51 --> Language Class Initialized
INFO - 2024-12-10 00:15:51 --> Loader Class Initialized
INFO - 2024-12-10 00:15:51 --> Helper loaded: url_helper
INFO - 2024-12-10 00:15:51 --> Helper loaded: form_helper
INFO - 2024-12-10 00:15:51 --> Helper loaded: file_helper
INFO - 2024-12-10 00:15:51 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:15:51 --> Form Validation Class Initialized
INFO - 2024-12-10 00:15:51 --> Upload Class Initialized
INFO - 2024-12-10 00:15:51 --> Model "M_login" initialized
INFO - 2024-12-10 00:15:51 --> Model "M_home" initialized
INFO - 2024-12-10 00:15:51 --> Model "M_setting" initialized
INFO - 2024-12-10 00:15:51 --> Controller Class Initialized
INFO - 2024-12-10 00:15:51 --> Model "M_guru" initialized
INFO - 2024-12-10 00:15:51 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:15:51 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:15:51 --> Final output sent to browser
DEBUG - 2024-12-10 00:15:51 --> Total execution time: 0.1165
INFO - 2024-12-10 00:15:51 --> Config Class Initialized
INFO - 2024-12-10 00:15:51 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:51 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:51 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:51 --> URI Class Initialized
INFO - 2024-12-10 00:15:51 --> Router Class Initialized
INFO - 2024-12-10 00:15:51 --> Output Class Initialized
INFO - 2024-12-10 00:15:51 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:51 --> Input Class Initialized
INFO - 2024-12-10 00:15:51 --> Language Class Initialized
ERROR - 2024-12-10 00:15:51 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:15:59 --> Config Class Initialized
INFO - 2024-12-10 00:15:59 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:59 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:59 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:59 --> URI Class Initialized
INFO - 2024-12-10 00:15:59 --> Router Class Initialized
INFO - 2024-12-10 00:15:59 --> Output Class Initialized
INFO - 2024-12-10 00:15:59 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:59 --> Input Class Initialized
INFO - 2024-12-10 00:15:59 --> Language Class Initialized
INFO - 2024-12-10 00:15:59 --> Loader Class Initialized
INFO - 2024-12-10 00:15:59 --> Helper loaded: url_helper
INFO - 2024-12-10 00:15:59 --> Helper loaded: form_helper
INFO - 2024-12-10 00:15:59 --> Helper loaded: file_helper
INFO - 2024-12-10 00:15:59 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:15:59 --> Form Validation Class Initialized
INFO - 2024-12-10 00:15:59 --> Upload Class Initialized
INFO - 2024-12-10 00:15:59 --> Model "M_login" initialized
INFO - 2024-12-10 00:15:59 --> Model "M_home" initialized
INFO - 2024-12-10 00:15:59 --> Model "M_setting" initialized
INFO - 2024-12-10 00:15:59 --> Controller Class Initialized
INFO - 2024-12-10 00:15:59 --> Model "M_guru" initialized
INFO - 2024-12-10 00:15:59 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:15:59 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:15:59 --> Final output sent to browser
DEBUG - 2024-12-10 00:15:59 --> Total execution time: 0.1043
INFO - 2024-12-10 00:15:59 --> Config Class Initialized
INFO - 2024-12-10 00:15:59 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:15:59 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:15:59 --> Utf8 Class Initialized
INFO - 2024-12-10 00:15:59 --> URI Class Initialized
INFO - 2024-12-10 00:15:59 --> Router Class Initialized
INFO - 2024-12-10 00:15:59 --> Output Class Initialized
INFO - 2024-12-10 00:15:59 --> Security Class Initialized
DEBUG - 2024-12-10 00:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:15:59 --> Input Class Initialized
INFO - 2024-12-10 00:15:59 --> Language Class Initialized
ERROR - 2024-12-10 00:15:59 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:16:05 --> Config Class Initialized
INFO - 2024-12-10 00:16:05 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:16:05 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:16:05 --> Utf8 Class Initialized
INFO - 2024-12-10 00:16:05 --> URI Class Initialized
INFO - 2024-12-10 00:16:05 --> Router Class Initialized
INFO - 2024-12-10 00:16:05 --> Output Class Initialized
INFO - 2024-12-10 00:16:05 --> Security Class Initialized
DEBUG - 2024-12-10 00:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:16:05 --> Input Class Initialized
INFO - 2024-12-10 00:16:05 --> Language Class Initialized
INFO - 2024-12-10 00:16:05 --> Loader Class Initialized
INFO - 2024-12-10 00:16:05 --> Helper loaded: url_helper
INFO - 2024-12-10 00:16:05 --> Helper loaded: form_helper
INFO - 2024-12-10 00:16:05 --> Helper loaded: file_helper
INFO - 2024-12-10 00:16:05 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:16:05 --> Form Validation Class Initialized
INFO - 2024-12-10 00:16:05 --> Upload Class Initialized
INFO - 2024-12-10 00:16:05 --> Model "M_login" initialized
INFO - 2024-12-10 00:16:05 --> Model "M_home" initialized
INFO - 2024-12-10 00:16:05 --> Model "M_setting" initialized
INFO - 2024-12-10 00:16:05 --> Controller Class Initialized
INFO - 2024-12-10 00:16:05 --> Model "M_guru" initialized
INFO - 2024-12-10 00:16:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:16:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:16:05 --> Final output sent to browser
DEBUG - 2024-12-10 00:16:05 --> Total execution time: 0.1095
INFO - 2024-12-10 00:16:06 --> Config Class Initialized
INFO - 2024-12-10 00:16:06 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:16:06 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:16:06 --> Utf8 Class Initialized
INFO - 2024-12-10 00:16:06 --> URI Class Initialized
INFO - 2024-12-10 00:16:06 --> Router Class Initialized
INFO - 2024-12-10 00:16:06 --> Output Class Initialized
INFO - 2024-12-10 00:16:06 --> Security Class Initialized
DEBUG - 2024-12-10 00:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:16:06 --> Input Class Initialized
INFO - 2024-12-10 00:16:06 --> Language Class Initialized
ERROR - 2024-12-10 00:16:06 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:16:14 --> Config Class Initialized
INFO - 2024-12-10 00:16:14 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:16:14 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:16:14 --> Utf8 Class Initialized
INFO - 2024-12-10 00:16:14 --> URI Class Initialized
INFO - 2024-12-10 00:16:14 --> Router Class Initialized
INFO - 2024-12-10 00:16:14 --> Output Class Initialized
INFO - 2024-12-10 00:16:14 --> Security Class Initialized
DEBUG - 2024-12-10 00:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:16:14 --> Input Class Initialized
INFO - 2024-12-10 00:16:14 --> Language Class Initialized
INFO - 2024-12-10 00:16:14 --> Loader Class Initialized
INFO - 2024-12-10 00:16:14 --> Helper loaded: url_helper
INFO - 2024-12-10 00:16:14 --> Helper loaded: form_helper
INFO - 2024-12-10 00:16:14 --> Helper loaded: file_helper
INFO - 2024-12-10 00:16:14 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:16:14 --> Form Validation Class Initialized
INFO - 2024-12-10 00:16:14 --> Upload Class Initialized
INFO - 2024-12-10 00:16:14 --> Model "M_login" initialized
INFO - 2024-12-10 00:16:14 --> Model "M_home" initialized
INFO - 2024-12-10 00:16:14 --> Model "M_setting" initialized
INFO - 2024-12-10 00:16:14 --> Controller Class Initialized
INFO - 2024-12-10 00:16:14 --> Model "M_guru" initialized
INFO - 2024-12-10 00:16:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:16:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:16:14 --> Final output sent to browser
DEBUG - 2024-12-10 00:16:14 --> Total execution time: 0.1287
INFO - 2024-12-10 00:16:14 --> Config Class Initialized
INFO - 2024-12-10 00:16:14 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:16:14 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:16:14 --> Utf8 Class Initialized
INFO - 2024-12-10 00:16:14 --> URI Class Initialized
INFO - 2024-12-10 00:16:14 --> Router Class Initialized
INFO - 2024-12-10 00:16:14 --> Output Class Initialized
INFO - 2024-12-10 00:16:14 --> Security Class Initialized
DEBUG - 2024-12-10 00:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:16:14 --> Input Class Initialized
INFO - 2024-12-10 00:16:14 --> Language Class Initialized
ERROR - 2024-12-10 00:16:14 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:16:18 --> Config Class Initialized
INFO - 2024-12-10 00:16:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:16:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:16:18 --> Utf8 Class Initialized
INFO - 2024-12-10 00:16:18 --> URI Class Initialized
INFO - 2024-12-10 00:16:18 --> Router Class Initialized
INFO - 2024-12-10 00:16:18 --> Output Class Initialized
INFO - 2024-12-10 00:16:18 --> Security Class Initialized
DEBUG - 2024-12-10 00:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:16:18 --> Input Class Initialized
INFO - 2024-12-10 00:16:18 --> Language Class Initialized
INFO - 2024-12-10 00:16:18 --> Loader Class Initialized
INFO - 2024-12-10 00:16:18 --> Helper loaded: url_helper
INFO - 2024-12-10 00:16:18 --> Helper loaded: form_helper
INFO - 2024-12-10 00:16:18 --> Helper loaded: file_helper
INFO - 2024-12-10 00:16:18 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:16:18 --> Form Validation Class Initialized
INFO - 2024-12-10 00:16:18 --> Upload Class Initialized
INFO - 2024-12-10 00:16:18 --> Model "M_login" initialized
INFO - 2024-12-10 00:16:18 --> Model "M_home" initialized
INFO - 2024-12-10 00:16:18 --> Model "M_setting" initialized
INFO - 2024-12-10 00:16:18 --> Controller Class Initialized
INFO - 2024-12-10 00:16:18 --> Model "M_guru" initialized
INFO - 2024-12-10 00:16:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:16:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:16:18 --> Final output sent to browser
DEBUG - 2024-12-10 00:16:18 --> Total execution time: 0.1280
INFO - 2024-12-10 00:16:18 --> Config Class Initialized
INFO - 2024-12-10 00:16:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:16:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:16:18 --> Utf8 Class Initialized
INFO - 2024-12-10 00:16:18 --> URI Class Initialized
INFO - 2024-12-10 00:16:18 --> Router Class Initialized
INFO - 2024-12-10 00:16:18 --> Output Class Initialized
INFO - 2024-12-10 00:16:18 --> Security Class Initialized
DEBUG - 2024-12-10 00:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:16:18 --> Input Class Initialized
INFO - 2024-12-10 00:16:18 --> Language Class Initialized
ERROR - 2024-12-10 00:16:18 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:16:56 --> Config Class Initialized
INFO - 2024-12-10 00:16:56 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:16:56 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:16:56 --> Utf8 Class Initialized
INFO - 2024-12-10 00:16:56 --> URI Class Initialized
INFO - 2024-12-10 00:16:56 --> Router Class Initialized
INFO - 2024-12-10 00:16:56 --> Output Class Initialized
INFO - 2024-12-10 00:16:56 --> Security Class Initialized
DEBUG - 2024-12-10 00:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:16:56 --> Input Class Initialized
INFO - 2024-12-10 00:16:56 --> Language Class Initialized
INFO - 2024-12-10 00:16:56 --> Loader Class Initialized
INFO - 2024-12-10 00:16:56 --> Helper loaded: url_helper
INFO - 2024-12-10 00:16:56 --> Helper loaded: form_helper
INFO - 2024-12-10 00:16:56 --> Helper loaded: file_helper
INFO - 2024-12-10 00:16:56 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:16:56 --> Form Validation Class Initialized
INFO - 2024-12-10 00:16:56 --> Upload Class Initialized
INFO - 2024-12-10 00:16:56 --> Model "M_login" initialized
INFO - 2024-12-10 00:16:56 --> Model "M_home" initialized
INFO - 2024-12-10 00:16:56 --> Model "M_setting" initialized
INFO - 2024-12-10 00:16:56 --> Controller Class Initialized
INFO - 2024-12-10 00:16:56 --> Model "M_guru" initialized
INFO - 2024-12-10 00:16:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:16:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:16:56 --> Final output sent to browser
DEBUG - 2024-12-10 00:16:56 --> Total execution time: 0.1281
INFO - 2024-12-10 00:16:56 --> Config Class Initialized
INFO - 2024-12-10 00:16:56 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:16:56 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:16:56 --> Utf8 Class Initialized
INFO - 2024-12-10 00:16:56 --> URI Class Initialized
INFO - 2024-12-10 00:16:56 --> Router Class Initialized
INFO - 2024-12-10 00:16:56 --> Output Class Initialized
INFO - 2024-12-10 00:16:56 --> Security Class Initialized
DEBUG - 2024-12-10 00:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:16:56 --> Input Class Initialized
INFO - 2024-12-10 00:16:56 --> Language Class Initialized
ERROR - 2024-12-10 00:16:56 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:17:36 --> Config Class Initialized
INFO - 2024-12-10 00:17:36 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:17:36 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:17:36 --> Utf8 Class Initialized
INFO - 2024-12-10 00:17:36 --> URI Class Initialized
INFO - 2024-12-10 00:17:36 --> Router Class Initialized
INFO - 2024-12-10 00:17:36 --> Output Class Initialized
INFO - 2024-12-10 00:17:36 --> Security Class Initialized
DEBUG - 2024-12-10 00:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:17:36 --> Input Class Initialized
INFO - 2024-12-10 00:17:36 --> Language Class Initialized
INFO - 2024-12-10 00:17:36 --> Loader Class Initialized
INFO - 2024-12-10 00:17:36 --> Helper loaded: url_helper
INFO - 2024-12-10 00:17:36 --> Helper loaded: form_helper
INFO - 2024-12-10 00:17:36 --> Helper loaded: file_helper
INFO - 2024-12-10 00:17:36 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:17:36 --> Form Validation Class Initialized
INFO - 2024-12-10 00:17:36 --> Upload Class Initialized
INFO - 2024-12-10 00:17:36 --> Model "M_login" initialized
INFO - 2024-12-10 00:17:36 --> Model "M_home" initialized
INFO - 2024-12-10 00:17:36 --> Model "M_setting" initialized
INFO - 2024-12-10 00:17:36 --> Controller Class Initialized
INFO - 2024-12-10 00:17:36 --> Model "M_guru" initialized
INFO - 2024-12-10 00:17:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 00:17:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 00:17:36 --> Final output sent to browser
DEBUG - 2024-12-10 00:17:36 --> Total execution time: 0.1032
INFO - 2024-12-10 00:17:36 --> Config Class Initialized
INFO - 2024-12-10 00:17:36 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:17:37 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:17:37 --> Utf8 Class Initialized
INFO - 2024-12-10 00:17:37 --> URI Class Initialized
INFO - 2024-12-10 00:17:37 --> Router Class Initialized
INFO - 2024-12-10 00:17:37 --> Output Class Initialized
INFO - 2024-12-10 00:17:37 --> Security Class Initialized
DEBUG - 2024-12-10 00:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:17:37 --> Input Class Initialized
INFO - 2024-12-10 00:17:37 --> Language Class Initialized
ERROR - 2024-12-10 00:17:37 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 00:18:40 --> Config Class Initialized
INFO - 2024-12-10 00:18:40 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:18:40 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:18:40 --> Utf8 Class Initialized
INFO - 2024-12-10 00:18:40 --> URI Class Initialized
INFO - 2024-12-10 00:18:40 --> Router Class Initialized
INFO - 2024-12-10 00:18:40 --> Output Class Initialized
INFO - 2024-12-10 00:18:40 --> Security Class Initialized
DEBUG - 2024-12-10 00:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:18:40 --> Input Class Initialized
INFO - 2024-12-10 00:18:40 --> Language Class Initialized
INFO - 2024-12-10 00:18:40 --> Loader Class Initialized
INFO - 2024-12-10 00:18:40 --> Helper loaded: url_helper
INFO - 2024-12-10 00:18:40 --> Helper loaded: form_helper
INFO - 2024-12-10 00:18:40 --> Helper loaded: file_helper
INFO - 2024-12-10 00:18:40 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:18:40 --> Form Validation Class Initialized
INFO - 2024-12-10 00:18:40 --> Upload Class Initialized
INFO - 2024-12-10 00:18:40 --> Model "M_login" initialized
INFO - 2024-12-10 00:18:40 --> Model "M_home" initialized
INFO - 2024-12-10 00:18:40 --> Model "M_setting" initialized
INFO - 2024-12-10 00:18:40 --> Controller Class Initialized
INFO - 2024-12-10 00:18:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-10 00:18:40 --> Config Class Initialized
INFO - 2024-12-10 00:18:40 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:18:40 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:18:40 --> Utf8 Class Initialized
INFO - 2024-12-10 00:18:40 --> URI Class Initialized
INFO - 2024-12-10 00:18:40 --> Router Class Initialized
INFO - 2024-12-10 00:18:40 --> Output Class Initialized
INFO - 2024-12-10 00:18:40 --> Security Class Initialized
DEBUG - 2024-12-10 00:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:18:40 --> Input Class Initialized
INFO - 2024-12-10 00:18:40 --> Language Class Initialized
INFO - 2024-12-10 00:18:40 --> Loader Class Initialized
INFO - 2024-12-10 00:18:40 --> Helper loaded: url_helper
INFO - 2024-12-10 00:18:40 --> Helper loaded: form_helper
INFO - 2024-12-10 00:18:40 --> Helper loaded: file_helper
INFO - 2024-12-10 00:18:40 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:18:40 --> Form Validation Class Initialized
INFO - 2024-12-10 00:18:40 --> Upload Class Initialized
INFO - 2024-12-10 00:18:40 --> Model "M_login" initialized
INFO - 2024-12-10 00:18:40 --> Model "M_home" initialized
INFO - 2024-12-10 00:18:40 --> Model "M_setting" initialized
INFO - 2024-12-10 00:18:40 --> Controller Class Initialized
INFO - 2024-12-10 00:18:40 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\Admin/v_dashboard.php
INFO - 2024-12-10 00:18:40 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:18:40 --> Final output sent to browser
DEBUG - 2024-12-10 00:18:40 --> Total execution time: 0.0868
INFO - 2024-12-10 00:18:56 --> Config Class Initialized
INFO - 2024-12-10 00:18:56 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:18:56 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:18:56 --> Utf8 Class Initialized
INFO - 2024-12-10 00:18:56 --> URI Class Initialized
INFO - 2024-12-10 00:18:56 --> Router Class Initialized
INFO - 2024-12-10 00:18:56 --> Output Class Initialized
INFO - 2024-12-10 00:18:56 --> Security Class Initialized
DEBUG - 2024-12-10 00:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:18:56 --> Input Class Initialized
INFO - 2024-12-10 00:18:56 --> Language Class Initialized
INFO - 2024-12-10 00:18:56 --> Loader Class Initialized
INFO - 2024-12-10 00:18:56 --> Helper loaded: url_helper
INFO - 2024-12-10 00:18:56 --> Helper loaded: form_helper
INFO - 2024-12-10 00:18:56 --> Helper loaded: file_helper
INFO - 2024-12-10 00:18:56 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:18:56 --> Form Validation Class Initialized
INFO - 2024-12-10 00:18:56 --> Upload Class Initialized
INFO - 2024-12-10 00:18:56 --> Model "M_login" initialized
INFO - 2024-12-10 00:18:56 --> Model "M_home" initialized
INFO - 2024-12-10 00:18:56 --> Model "M_setting" initialized
INFO - 2024-12-10 00:18:56 --> Controller Class Initialized
INFO - 2024-12-10 00:18:56 --> Model "M_berita" initialized
INFO - 2024-12-10 00:18:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:18:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:18:56 --> Final output sent to browser
DEBUG - 2024-12-10 00:18:56 --> Total execution time: 0.1133
INFO - 2024-12-10 00:18:59 --> Config Class Initialized
INFO - 2024-12-10 00:18:59 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:18:59 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:18:59 --> Utf8 Class Initialized
INFO - 2024-12-10 00:18:59 --> URI Class Initialized
INFO - 2024-12-10 00:18:59 --> Router Class Initialized
INFO - 2024-12-10 00:18:59 --> Output Class Initialized
INFO - 2024-12-10 00:18:59 --> Security Class Initialized
DEBUG - 2024-12-10 00:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:18:59 --> Input Class Initialized
INFO - 2024-12-10 00:18:59 --> Language Class Initialized
INFO - 2024-12-10 00:18:59 --> Loader Class Initialized
INFO - 2024-12-10 00:18:59 --> Helper loaded: url_helper
INFO - 2024-12-10 00:18:59 --> Helper loaded: form_helper
INFO - 2024-12-10 00:18:59 --> Helper loaded: file_helper
INFO - 2024-12-10 00:18:59 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:18:59 --> Form Validation Class Initialized
INFO - 2024-12-10 00:18:59 --> Upload Class Initialized
INFO - 2024-12-10 00:18:59 --> Model "M_login" initialized
INFO - 2024-12-10 00:18:59 --> Model "M_home" initialized
INFO - 2024-12-10 00:18:59 --> Model "M_setting" initialized
INFO - 2024-12-10 00:18:59 --> Controller Class Initialized
INFO - 2024-12-10 00:18:59 --> Model "M_gallery" initialized
INFO - 2024-12-10 00:18:59 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/gallery/v_list.php
INFO - 2024-12-10 00:18:59 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:18:59 --> Final output sent to browser
DEBUG - 2024-12-10 00:18:59 --> Total execution time: 0.1843
INFO - 2024-12-10 00:19:00 --> Config Class Initialized
INFO - 2024-12-10 00:19:00 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:19:00 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:19:00 --> Utf8 Class Initialized
INFO - 2024-12-10 00:19:00 --> URI Class Initialized
INFO - 2024-12-10 00:19:00 --> Router Class Initialized
INFO - 2024-12-10 00:19:00 --> Output Class Initialized
INFO - 2024-12-10 00:19:00 --> Security Class Initialized
DEBUG - 2024-12-10 00:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:19:00 --> Input Class Initialized
INFO - 2024-12-10 00:19:00 --> Language Class Initialized
INFO - 2024-12-10 00:19:00 --> Loader Class Initialized
INFO - 2024-12-10 00:19:00 --> Helper loaded: url_helper
INFO - 2024-12-10 00:19:00 --> Helper loaded: form_helper
INFO - 2024-12-10 00:19:00 --> Helper loaded: file_helper
INFO - 2024-12-10 00:19:00 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:19:00 --> Form Validation Class Initialized
INFO - 2024-12-10 00:19:00 --> Upload Class Initialized
INFO - 2024-12-10 00:19:00 --> Model "M_login" initialized
INFO - 2024-12-10 00:19:00 --> Model "M_home" initialized
INFO - 2024-12-10 00:19:00 --> Model "M_setting" initialized
INFO - 2024-12-10 00:19:00 --> Controller Class Initialized
INFO - 2024-12-10 00:19:00 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/v_setting.php
INFO - 2024-12-10 00:19:00 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:19:00 --> Final output sent to browser
DEBUG - 2024-12-10 00:19:00 --> Total execution time: 0.1081
INFO - 2024-12-10 00:19:06 --> Config Class Initialized
INFO - 2024-12-10 00:19:06 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:19:06 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:19:06 --> Utf8 Class Initialized
INFO - 2024-12-10 00:19:06 --> URI Class Initialized
INFO - 2024-12-10 00:19:06 --> Router Class Initialized
INFO - 2024-12-10 00:19:06 --> Output Class Initialized
INFO - 2024-12-10 00:19:06 --> Security Class Initialized
DEBUG - 2024-12-10 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:19:06 --> Input Class Initialized
INFO - 2024-12-10 00:19:06 --> Language Class Initialized
INFO - 2024-12-10 00:19:06 --> Loader Class Initialized
INFO - 2024-12-10 00:19:06 --> Helper loaded: url_helper
INFO - 2024-12-10 00:19:06 --> Helper loaded: form_helper
INFO - 2024-12-10 00:19:06 --> Helper loaded: file_helper
INFO - 2024-12-10 00:19:06 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:19:06 --> Form Validation Class Initialized
INFO - 2024-12-10 00:19:06 --> Upload Class Initialized
INFO - 2024-12-10 00:19:06 --> Model "M_login" initialized
INFO - 2024-12-10 00:19:06 --> Model "M_home" initialized
INFO - 2024-12-10 00:19:06 --> Model "M_setting" initialized
INFO - 2024-12-10 00:19:06 --> Controller Class Initialized
INFO - 2024-12-10 00:19:06 --> Model "M_gallery" initialized
INFO - 2024-12-10 00:19:06 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/gallery/v_list.php
INFO - 2024-12-10 00:19:06 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:19:06 --> Final output sent to browser
DEBUG - 2024-12-10 00:19:06 --> Total execution time: 0.1061
INFO - 2024-12-10 00:19:09 --> Config Class Initialized
INFO - 2024-12-10 00:19:09 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:19:09 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:19:09 --> Utf8 Class Initialized
INFO - 2024-12-10 00:19:09 --> URI Class Initialized
INFO - 2024-12-10 00:19:09 --> Router Class Initialized
INFO - 2024-12-10 00:19:09 --> Output Class Initialized
INFO - 2024-12-10 00:19:09 --> Security Class Initialized
DEBUG - 2024-12-10 00:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:19:09 --> Input Class Initialized
INFO - 2024-12-10 00:19:09 --> Language Class Initialized
INFO - 2024-12-10 00:19:09 --> Loader Class Initialized
INFO - 2024-12-10 00:19:09 --> Helper loaded: url_helper
INFO - 2024-12-10 00:19:09 --> Helper loaded: form_helper
INFO - 2024-12-10 00:19:09 --> Helper loaded: file_helper
INFO - 2024-12-10 00:19:09 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:19:10 --> Form Validation Class Initialized
INFO - 2024-12-10 00:19:10 --> Upload Class Initialized
INFO - 2024-12-10 00:19:10 --> Model "M_login" initialized
INFO - 2024-12-10 00:19:10 --> Model "M_home" initialized
INFO - 2024-12-10 00:19:10 --> Model "M_setting" initialized
INFO - 2024-12-10 00:19:10 --> Controller Class Initialized
INFO - 2024-12-10 00:19:10 --> Model "M_berita" initialized
INFO - 2024-12-10 00:19:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:19:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:19:10 --> Final output sent to browser
DEBUG - 2024-12-10 00:19:10 --> Total execution time: 0.0954
INFO - 2024-12-10 00:20:48 --> Config Class Initialized
INFO - 2024-12-10 00:20:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:20:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:20:48 --> Utf8 Class Initialized
INFO - 2024-12-10 00:20:48 --> URI Class Initialized
INFO - 2024-12-10 00:20:48 --> Router Class Initialized
INFO - 2024-12-10 00:20:48 --> Output Class Initialized
INFO - 2024-12-10 00:20:48 --> Security Class Initialized
DEBUG - 2024-12-10 00:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:20:48 --> Input Class Initialized
INFO - 2024-12-10 00:20:48 --> Language Class Initialized
ERROR - 2024-12-10 00:20:48 --> 404 Page Not Found: Template/back-end
INFO - 2024-12-10 00:21:42 --> Config Class Initialized
INFO - 2024-12-10 00:21:42 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:21:42 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:21:42 --> Utf8 Class Initialized
INFO - 2024-12-10 00:21:42 --> URI Class Initialized
INFO - 2024-12-10 00:21:43 --> Router Class Initialized
INFO - 2024-12-10 00:21:43 --> Output Class Initialized
INFO - 2024-12-10 00:21:43 --> Security Class Initialized
DEBUG - 2024-12-10 00:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:21:43 --> Input Class Initialized
INFO - 2024-12-10 00:21:43 --> Language Class Initialized
INFO - 2024-12-10 00:21:43 --> Loader Class Initialized
INFO - 2024-12-10 00:21:43 --> Helper loaded: url_helper
INFO - 2024-12-10 00:21:43 --> Helper loaded: form_helper
INFO - 2024-12-10 00:21:43 --> Helper loaded: file_helper
INFO - 2024-12-10 00:21:43 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:21:43 --> Form Validation Class Initialized
INFO - 2024-12-10 00:21:43 --> Upload Class Initialized
INFO - 2024-12-10 00:21:43 --> Model "M_login" initialized
INFO - 2024-12-10 00:21:43 --> Model "M_home" initialized
INFO - 2024-12-10 00:21:43 --> Model "M_setting" initialized
INFO - 2024-12-10 00:21:43 --> Controller Class Initialized
INFO - 2024-12-10 00:21:43 --> Model "M_berita" initialized
INFO - 2024-12-10 00:21:43 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:21:43 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:21:43 --> Final output sent to browser
DEBUG - 2024-12-10 00:21:43 --> Total execution time: 0.1553
INFO - 2024-12-10 00:21:55 --> Config Class Initialized
INFO - 2024-12-10 00:21:55 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:21:55 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:21:55 --> Utf8 Class Initialized
INFO - 2024-12-10 00:21:55 --> URI Class Initialized
INFO - 2024-12-10 00:21:55 --> Router Class Initialized
INFO - 2024-12-10 00:21:55 --> Output Class Initialized
INFO - 2024-12-10 00:21:55 --> Security Class Initialized
DEBUG - 2024-12-10 00:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:21:55 --> Input Class Initialized
INFO - 2024-12-10 00:21:55 --> Language Class Initialized
INFO - 2024-12-10 00:21:55 --> Loader Class Initialized
INFO - 2024-12-10 00:21:55 --> Helper loaded: url_helper
INFO - 2024-12-10 00:21:55 --> Helper loaded: form_helper
INFO - 2024-12-10 00:21:55 --> Helper loaded: file_helper
INFO - 2024-12-10 00:21:55 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:21:55 --> Form Validation Class Initialized
INFO - 2024-12-10 00:21:55 --> Upload Class Initialized
INFO - 2024-12-10 00:21:55 --> Model "M_login" initialized
INFO - 2024-12-10 00:21:55 --> Model "M_home" initialized
INFO - 2024-12-10 00:21:55 --> Model "M_setting" initialized
INFO - 2024-12-10 00:21:55 --> Controller Class Initialized
INFO - 2024-12-10 00:21:55 --> Model "M_berita" initialized
INFO - 2024-12-10 00:21:55 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:21:55 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:21:55 --> Final output sent to browser
DEBUG - 2024-12-10 00:21:55 --> Total execution time: 0.1336
INFO - 2024-12-10 00:22:40 --> Config Class Initialized
INFO - 2024-12-10 00:22:40 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:22:40 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:22:40 --> Utf8 Class Initialized
INFO - 2024-12-10 00:22:40 --> URI Class Initialized
INFO - 2024-12-10 00:22:40 --> Router Class Initialized
INFO - 2024-12-10 00:22:40 --> Output Class Initialized
INFO - 2024-12-10 00:22:40 --> Security Class Initialized
DEBUG - 2024-12-10 00:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:22:40 --> Input Class Initialized
INFO - 2024-12-10 00:22:40 --> Language Class Initialized
INFO - 2024-12-10 00:22:40 --> Loader Class Initialized
INFO - 2024-12-10 00:22:40 --> Helper loaded: url_helper
INFO - 2024-12-10 00:22:40 --> Helper loaded: form_helper
INFO - 2024-12-10 00:22:40 --> Helper loaded: file_helper
INFO - 2024-12-10 00:22:40 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:22:41 --> Form Validation Class Initialized
INFO - 2024-12-10 00:22:41 --> Upload Class Initialized
INFO - 2024-12-10 00:22:41 --> Model "M_login" initialized
INFO - 2024-12-10 00:22:41 --> Model "M_home" initialized
INFO - 2024-12-10 00:22:41 --> Model "M_setting" initialized
INFO - 2024-12-10 00:22:41 --> Controller Class Initialized
INFO - 2024-12-10 00:22:41 --> Model "M_gallery" initialized
INFO - 2024-12-10 00:22:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/gallery/v_list.php
INFO - 2024-12-10 00:22:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:22:41 --> Final output sent to browser
DEBUG - 2024-12-10 00:22:41 --> Total execution time: 0.1120
INFO - 2024-12-10 00:23:18 --> Config Class Initialized
INFO - 2024-12-10 00:23:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:23:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:23:18 --> Utf8 Class Initialized
INFO - 2024-12-10 00:23:18 --> URI Class Initialized
INFO - 2024-12-10 00:23:18 --> Router Class Initialized
INFO - 2024-12-10 00:23:18 --> Output Class Initialized
INFO - 2024-12-10 00:23:18 --> Security Class Initialized
DEBUG - 2024-12-10 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:23:18 --> Input Class Initialized
INFO - 2024-12-10 00:23:18 --> Language Class Initialized
INFO - 2024-12-10 00:23:18 --> Loader Class Initialized
INFO - 2024-12-10 00:23:18 --> Helper loaded: url_helper
INFO - 2024-12-10 00:23:18 --> Helper loaded: form_helper
INFO - 2024-12-10 00:23:18 --> Helper loaded: file_helper
INFO - 2024-12-10 00:23:18 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:23:18 --> Form Validation Class Initialized
INFO - 2024-12-10 00:23:18 --> Upload Class Initialized
INFO - 2024-12-10 00:23:18 --> Model "M_login" initialized
INFO - 2024-12-10 00:23:18 --> Model "M_home" initialized
INFO - 2024-12-10 00:23:18 --> Model "M_setting" initialized
INFO - 2024-12-10 00:23:18 --> Controller Class Initialized
INFO - 2024-12-10 00:23:18 --> Model "M_gallery" initialized
INFO - 2024-12-10 00:23:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/gallery/v_list.php
INFO - 2024-12-10 00:23:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:23:18 --> Final output sent to browser
DEBUG - 2024-12-10 00:23:18 --> Total execution time: 0.1014
INFO - 2024-12-10 00:23:21 --> Config Class Initialized
INFO - 2024-12-10 00:23:21 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:23:21 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:23:21 --> Utf8 Class Initialized
INFO - 2024-12-10 00:23:21 --> URI Class Initialized
INFO - 2024-12-10 00:23:21 --> Router Class Initialized
INFO - 2024-12-10 00:23:21 --> Output Class Initialized
INFO - 2024-12-10 00:23:21 --> Security Class Initialized
DEBUG - 2024-12-10 00:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:23:21 --> Input Class Initialized
INFO - 2024-12-10 00:23:21 --> Language Class Initialized
INFO - 2024-12-10 00:23:21 --> Loader Class Initialized
INFO - 2024-12-10 00:23:21 --> Helper loaded: url_helper
INFO - 2024-12-10 00:23:21 --> Helper loaded: form_helper
INFO - 2024-12-10 00:23:21 --> Helper loaded: file_helper
INFO - 2024-12-10 00:23:21 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:23:21 --> Form Validation Class Initialized
INFO - 2024-12-10 00:23:21 --> Upload Class Initialized
INFO - 2024-12-10 00:23:21 --> Model "M_login" initialized
INFO - 2024-12-10 00:23:21 --> Model "M_home" initialized
INFO - 2024-12-10 00:23:21 --> Model "M_setting" initialized
INFO - 2024-12-10 00:23:21 --> Controller Class Initialized
INFO - 2024-12-10 00:23:21 --> Model "M_berita" initialized
INFO - 2024-12-10 00:23:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:23:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:23:21 --> Final output sent to browser
DEBUG - 2024-12-10 00:23:21 --> Total execution time: 0.1011
INFO - 2024-12-10 00:23:23 --> Config Class Initialized
INFO - 2024-12-10 00:23:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:23:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:23:23 --> Utf8 Class Initialized
INFO - 2024-12-10 00:23:23 --> URI Class Initialized
INFO - 2024-12-10 00:23:23 --> Router Class Initialized
INFO - 2024-12-10 00:23:23 --> Output Class Initialized
INFO - 2024-12-10 00:23:23 --> Security Class Initialized
DEBUG - 2024-12-10 00:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:23:23 --> Input Class Initialized
INFO - 2024-12-10 00:23:23 --> Language Class Initialized
INFO - 2024-12-10 00:23:23 --> Loader Class Initialized
INFO - 2024-12-10 00:23:23 --> Helper loaded: url_helper
INFO - 2024-12-10 00:23:23 --> Helper loaded: form_helper
INFO - 2024-12-10 00:23:23 --> Helper loaded: file_helper
INFO - 2024-12-10 00:23:23 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:23:23 --> Form Validation Class Initialized
INFO - 2024-12-10 00:23:23 --> Upload Class Initialized
INFO - 2024-12-10 00:23:23 --> Model "M_login" initialized
INFO - 2024-12-10 00:23:23 --> Model "M_home" initialized
INFO - 2024-12-10 00:23:23 --> Model "M_setting" initialized
INFO - 2024-12-10 00:23:23 --> Controller Class Initialized
INFO - 2024-12-10 00:23:23 --> Model "M_berita" initialized
INFO - 2024-12-10 00:23:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:23:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:23:23 --> Final output sent to browser
DEBUG - 2024-12-10 00:23:23 --> Total execution time: 0.0998
INFO - 2024-12-10 00:23:26 --> Config Class Initialized
INFO - 2024-12-10 00:23:26 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:23:26 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:23:26 --> Utf8 Class Initialized
INFO - 2024-12-10 00:23:26 --> URI Class Initialized
INFO - 2024-12-10 00:23:26 --> Router Class Initialized
INFO - 2024-12-10 00:23:26 --> Output Class Initialized
INFO - 2024-12-10 00:23:26 --> Security Class Initialized
DEBUG - 2024-12-10 00:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:23:26 --> Input Class Initialized
INFO - 2024-12-10 00:23:26 --> Language Class Initialized
INFO - 2024-12-10 00:23:26 --> Loader Class Initialized
INFO - 2024-12-10 00:23:26 --> Helper loaded: url_helper
INFO - 2024-12-10 00:23:26 --> Helper loaded: form_helper
INFO - 2024-12-10 00:23:26 --> Helper loaded: file_helper
INFO - 2024-12-10 00:23:26 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:23:26 --> Form Validation Class Initialized
INFO - 2024-12-10 00:23:26 --> Upload Class Initialized
INFO - 2024-12-10 00:23:26 --> Model "M_login" initialized
INFO - 2024-12-10 00:23:26 --> Model "M_home" initialized
INFO - 2024-12-10 00:23:26 --> Model "M_setting" initialized
INFO - 2024-12-10 00:23:26 --> Controller Class Initialized
INFO - 2024-12-10 00:23:26 --> Model "M_gallery" initialized
INFO - 2024-12-10 00:23:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/gallery/v_list.php
INFO - 2024-12-10 00:23:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:23:26 --> Final output sent to browser
DEBUG - 2024-12-10 00:23:26 --> Total execution time: 0.1075
INFO - 2024-12-10 00:23:30 --> Config Class Initialized
INFO - 2024-12-10 00:23:30 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:23:30 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:23:30 --> Utf8 Class Initialized
INFO - 2024-12-10 00:23:30 --> URI Class Initialized
INFO - 2024-12-10 00:23:30 --> Router Class Initialized
INFO - 2024-12-10 00:23:30 --> Output Class Initialized
INFO - 2024-12-10 00:23:30 --> Security Class Initialized
DEBUG - 2024-12-10 00:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:23:30 --> Input Class Initialized
INFO - 2024-12-10 00:23:30 --> Language Class Initialized
INFO - 2024-12-10 00:23:30 --> Loader Class Initialized
INFO - 2024-12-10 00:23:30 --> Helper loaded: url_helper
INFO - 2024-12-10 00:23:30 --> Helper loaded: form_helper
INFO - 2024-12-10 00:23:30 --> Helper loaded: file_helper
INFO - 2024-12-10 00:23:30 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:23:30 --> Form Validation Class Initialized
INFO - 2024-12-10 00:23:30 --> Upload Class Initialized
INFO - 2024-12-10 00:23:30 --> Model "M_login" initialized
INFO - 2024-12-10 00:23:30 --> Model "M_home" initialized
INFO - 2024-12-10 00:23:30 --> Model "M_setting" initialized
INFO - 2024-12-10 00:23:30 --> Controller Class Initialized
INFO - 2024-12-10 00:23:30 --> Model "M_berita" initialized
INFO - 2024-12-10 00:23:30 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:23:30 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:23:30 --> Final output sent to browser
DEBUG - 2024-12-10 00:23:30 --> Total execution time: 0.0980
INFO - 2024-12-10 00:23:49 --> Config Class Initialized
INFO - 2024-12-10 00:23:49 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:23:49 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:23:49 --> Utf8 Class Initialized
INFO - 2024-12-10 00:23:49 --> URI Class Initialized
INFO - 2024-12-10 00:23:49 --> Router Class Initialized
INFO - 2024-12-10 00:23:49 --> Output Class Initialized
INFO - 2024-12-10 00:23:49 --> Security Class Initialized
DEBUG - 2024-12-10 00:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:23:49 --> Input Class Initialized
INFO - 2024-12-10 00:23:49 --> Language Class Initialized
INFO - 2024-12-10 00:23:49 --> Loader Class Initialized
INFO - 2024-12-10 00:23:49 --> Helper loaded: url_helper
INFO - 2024-12-10 00:23:49 --> Helper loaded: form_helper
INFO - 2024-12-10 00:23:49 --> Helper loaded: file_helper
INFO - 2024-12-10 00:23:49 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:23:49 --> Form Validation Class Initialized
INFO - 2024-12-10 00:23:49 --> Upload Class Initialized
INFO - 2024-12-10 00:23:49 --> Model "M_login" initialized
INFO - 2024-12-10 00:23:49 --> Model "M_home" initialized
INFO - 2024-12-10 00:23:49 --> Model "M_setting" initialized
INFO - 2024-12-10 00:23:49 --> Controller Class Initialized
INFO - 2024-12-10 00:23:49 --> Model "M_berita" initialized
INFO - 2024-12-10 00:23:49 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:23:49 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:23:49 --> Final output sent to browser
DEBUG - 2024-12-10 00:23:49 --> Total execution time: 0.1445
INFO - 2024-12-10 00:27:24 --> Config Class Initialized
INFO - 2024-12-10 00:27:25 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:27:25 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:27:25 --> Utf8 Class Initialized
INFO - 2024-12-10 00:27:25 --> URI Class Initialized
INFO - 2024-12-10 00:27:25 --> Router Class Initialized
INFO - 2024-12-10 00:27:25 --> Output Class Initialized
INFO - 2024-12-10 00:27:25 --> Security Class Initialized
DEBUG - 2024-12-10 00:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:27:25 --> Input Class Initialized
INFO - 2024-12-10 00:27:25 --> Language Class Initialized
INFO - 2024-12-10 00:27:25 --> Loader Class Initialized
INFO - 2024-12-10 00:27:25 --> Helper loaded: url_helper
INFO - 2024-12-10 00:27:25 --> Helper loaded: form_helper
INFO - 2024-12-10 00:27:25 --> Helper loaded: file_helper
INFO - 2024-12-10 00:27:25 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:27:25 --> Form Validation Class Initialized
INFO - 2024-12-10 00:27:25 --> Upload Class Initialized
INFO - 2024-12-10 00:27:25 --> Model "M_login" initialized
INFO - 2024-12-10 00:27:25 --> Model "M_home" initialized
INFO - 2024-12-10 00:27:25 --> Model "M_setting" initialized
INFO - 2024-12-10 00:27:25 --> Controller Class Initialized
INFO - 2024-12-10 00:27:25 --> Model "M_berita" initialized
INFO - 2024-12-10 00:27:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:27:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:27:25 --> Final output sent to browser
DEBUG - 2024-12-10 00:27:25 --> Total execution time: 0.1234
INFO - 2024-12-10 00:27:39 --> Config Class Initialized
INFO - 2024-12-10 00:27:39 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:27:39 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:27:39 --> Utf8 Class Initialized
INFO - 2024-12-10 00:27:39 --> URI Class Initialized
INFO - 2024-12-10 00:27:39 --> Router Class Initialized
INFO - 2024-12-10 00:27:39 --> Output Class Initialized
INFO - 2024-12-10 00:27:39 --> Security Class Initialized
DEBUG - 2024-12-10 00:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:27:39 --> Input Class Initialized
INFO - 2024-12-10 00:27:39 --> Language Class Initialized
INFO - 2024-12-10 00:27:39 --> Loader Class Initialized
INFO - 2024-12-10 00:27:39 --> Helper loaded: url_helper
INFO - 2024-12-10 00:27:39 --> Helper loaded: form_helper
INFO - 2024-12-10 00:27:39 --> Helper loaded: file_helper
INFO - 2024-12-10 00:27:39 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:27:39 --> Form Validation Class Initialized
INFO - 2024-12-10 00:27:39 --> Upload Class Initialized
INFO - 2024-12-10 00:27:39 --> Model "M_login" initialized
INFO - 2024-12-10 00:27:39 --> Model "M_home" initialized
INFO - 2024-12-10 00:27:39 --> Model "M_setting" initialized
INFO - 2024-12-10 00:27:39 --> Controller Class Initialized
INFO - 2024-12-10 00:27:39 --> Model "M_berita" initialized
INFO - 2024-12-10 00:27:39 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:27:39 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:27:39 --> Final output sent to browser
DEBUG - 2024-12-10 00:27:39 --> Total execution time: 0.1182
INFO - 2024-12-10 00:29:58 --> Config Class Initialized
INFO - 2024-12-10 00:29:58 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:29:58 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:29:58 --> Utf8 Class Initialized
INFO - 2024-12-10 00:29:58 --> URI Class Initialized
INFO - 2024-12-10 00:29:58 --> Router Class Initialized
INFO - 2024-12-10 00:29:58 --> Output Class Initialized
INFO - 2024-12-10 00:29:58 --> Security Class Initialized
DEBUG - 2024-12-10 00:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:29:58 --> Input Class Initialized
INFO - 2024-12-10 00:29:58 --> Language Class Initialized
INFO - 2024-12-10 00:29:58 --> Loader Class Initialized
INFO - 2024-12-10 00:29:58 --> Helper loaded: url_helper
INFO - 2024-12-10 00:29:58 --> Helper loaded: form_helper
INFO - 2024-12-10 00:29:58 --> Helper loaded: file_helper
INFO - 2024-12-10 00:29:58 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:29:58 --> Form Validation Class Initialized
INFO - 2024-12-10 00:29:58 --> Upload Class Initialized
INFO - 2024-12-10 00:29:58 --> Model "M_login" initialized
INFO - 2024-12-10 00:29:58 --> Model "M_home" initialized
INFO - 2024-12-10 00:29:58 --> Model "M_setting" initialized
INFO - 2024-12-10 00:29:58 --> Controller Class Initialized
INFO - 2024-12-10 00:29:58 --> Model "M_berita" initialized
INFO - 2024-12-10 00:29:58 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:29:58 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:29:58 --> Final output sent to browser
DEBUG - 2024-12-10 00:29:58 --> Total execution time: 0.1082
INFO - 2024-12-10 00:30:12 --> Config Class Initialized
INFO - 2024-12-10 00:30:12 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:30:12 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:30:12 --> Utf8 Class Initialized
INFO - 2024-12-10 00:30:12 --> URI Class Initialized
INFO - 2024-12-10 00:30:12 --> Router Class Initialized
INFO - 2024-12-10 00:30:12 --> Output Class Initialized
INFO - 2024-12-10 00:30:12 --> Security Class Initialized
DEBUG - 2024-12-10 00:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:30:12 --> Input Class Initialized
INFO - 2024-12-10 00:30:12 --> Language Class Initialized
INFO - 2024-12-10 00:30:12 --> Loader Class Initialized
INFO - 2024-12-10 00:30:12 --> Helper loaded: url_helper
INFO - 2024-12-10 00:30:12 --> Helper loaded: form_helper
INFO - 2024-12-10 00:30:12 --> Helper loaded: file_helper
INFO - 2024-12-10 00:30:12 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:30:12 --> Form Validation Class Initialized
INFO - 2024-12-10 00:30:12 --> Upload Class Initialized
INFO - 2024-12-10 00:30:12 --> Model "M_login" initialized
INFO - 2024-12-10 00:30:12 --> Model "M_home" initialized
INFO - 2024-12-10 00:30:12 --> Model "M_setting" initialized
INFO - 2024-12-10 00:30:12 --> Controller Class Initialized
INFO - 2024-12-10 00:30:12 --> Model "M_berita" initialized
INFO - 2024-12-10 00:30:12 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:30:12 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:30:12 --> Final output sent to browser
DEBUG - 2024-12-10 00:30:12 --> Total execution time: 0.1163
INFO - 2024-12-10 00:33:20 --> Config Class Initialized
INFO - 2024-12-10 00:33:20 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:33:20 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:33:20 --> Utf8 Class Initialized
INFO - 2024-12-10 00:33:20 --> URI Class Initialized
INFO - 2024-12-10 00:33:20 --> Router Class Initialized
INFO - 2024-12-10 00:33:20 --> Output Class Initialized
INFO - 2024-12-10 00:33:20 --> Security Class Initialized
DEBUG - 2024-12-10 00:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:33:20 --> Input Class Initialized
INFO - 2024-12-10 00:33:20 --> Language Class Initialized
INFO - 2024-12-10 00:33:20 --> Loader Class Initialized
INFO - 2024-12-10 00:33:20 --> Helper loaded: url_helper
INFO - 2024-12-10 00:33:20 --> Helper loaded: form_helper
INFO - 2024-12-10 00:33:20 --> Helper loaded: file_helper
INFO - 2024-12-10 00:33:20 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:33:20 --> Form Validation Class Initialized
INFO - 2024-12-10 00:33:20 --> Upload Class Initialized
INFO - 2024-12-10 00:33:20 --> Model "M_login" initialized
INFO - 2024-12-10 00:33:20 --> Model "M_home" initialized
INFO - 2024-12-10 00:33:20 --> Model "M_setting" initialized
INFO - 2024-12-10 00:33:20 --> Controller Class Initialized
INFO - 2024-12-10 00:33:20 --> Model "M_berita" initialized
INFO - 2024-12-10 00:33:20 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:33:20 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:33:20 --> Final output sent to browser
DEBUG - 2024-12-10 00:33:20 --> Total execution time: 0.0929
INFO - 2024-12-10 00:41:00 --> Config Class Initialized
INFO - 2024-12-10 00:41:00 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:41:00 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:41:00 --> Utf8 Class Initialized
INFO - 2024-12-10 00:41:00 --> URI Class Initialized
INFO - 2024-12-10 00:41:00 --> Router Class Initialized
INFO - 2024-12-10 00:41:00 --> Output Class Initialized
INFO - 2024-12-10 00:41:00 --> Security Class Initialized
DEBUG - 2024-12-10 00:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:41:00 --> Input Class Initialized
INFO - 2024-12-10 00:41:00 --> Language Class Initialized
INFO - 2024-12-10 00:41:00 --> Loader Class Initialized
INFO - 2024-12-10 00:41:00 --> Helper loaded: url_helper
INFO - 2024-12-10 00:41:00 --> Helper loaded: form_helper
INFO - 2024-12-10 00:41:00 --> Helper loaded: file_helper
INFO - 2024-12-10 00:41:00 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:41:00 --> Form Validation Class Initialized
INFO - 2024-12-10 00:41:00 --> Upload Class Initialized
INFO - 2024-12-10 00:41:00 --> Model "M_login" initialized
INFO - 2024-12-10 00:41:00 --> Model "M_home" initialized
INFO - 2024-12-10 00:41:00 --> Model "M_setting" initialized
INFO - 2024-12-10 00:41:00 --> Controller Class Initialized
INFO - 2024-12-10 00:41:00 --> Model "M_berita" initialized
ERROR - 2024-12-10 00:41:00 --> Severity: Warning --> Undefined variable $pagination C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin\berita\v_list.php 57
INFO - 2024-12-10 00:41:00 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:41:00 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:41:00 --> Final output sent to browser
DEBUG - 2024-12-10 00:41:00 --> Total execution time: 0.1393
INFO - 2024-12-10 00:43:18 --> Config Class Initialized
INFO - 2024-12-10 00:43:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:43:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:43:18 --> Utf8 Class Initialized
INFO - 2024-12-10 00:43:18 --> URI Class Initialized
INFO - 2024-12-10 00:43:18 --> Router Class Initialized
INFO - 2024-12-10 00:43:18 --> Output Class Initialized
INFO - 2024-12-10 00:43:18 --> Security Class Initialized
DEBUG - 2024-12-10 00:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:43:18 --> Input Class Initialized
INFO - 2024-12-10 00:43:18 --> Language Class Initialized
INFO - 2024-12-10 00:43:18 --> Loader Class Initialized
INFO - 2024-12-10 00:43:18 --> Helper loaded: url_helper
INFO - 2024-12-10 00:43:18 --> Helper loaded: form_helper
INFO - 2024-12-10 00:43:18 --> Helper loaded: file_helper
INFO - 2024-12-10 00:43:18 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:43:18 --> Form Validation Class Initialized
INFO - 2024-12-10 00:43:18 --> Upload Class Initialized
INFO - 2024-12-10 00:43:19 --> Model "M_login" initialized
INFO - 2024-12-10 00:43:19 --> Model "M_home" initialized
INFO - 2024-12-10 00:43:19 --> Model "M_setting" initialized
INFO - 2024-12-10 00:43:19 --> Controller Class Initialized
INFO - 2024-12-10 00:43:19 --> Model "M_berita" initialized
ERROR - 2024-12-10 00:43:19 --> Severity: Warning --> Undefined variable $pagination C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin\berita\v_list.php 57
INFO - 2024-12-10 00:43:19 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:43:19 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:43:19 --> Final output sent to browser
DEBUG - 2024-12-10 00:43:19 --> Total execution time: 0.1284
INFO - 2024-12-10 00:43:42 --> Config Class Initialized
INFO - 2024-12-10 00:43:42 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:43:42 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:43:42 --> Utf8 Class Initialized
INFO - 2024-12-10 00:43:42 --> URI Class Initialized
INFO - 2024-12-10 00:43:42 --> Router Class Initialized
INFO - 2024-12-10 00:43:42 --> Output Class Initialized
INFO - 2024-12-10 00:43:42 --> Security Class Initialized
DEBUG - 2024-12-10 00:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:43:42 --> Input Class Initialized
INFO - 2024-12-10 00:43:42 --> Language Class Initialized
INFO - 2024-12-10 00:43:42 --> Loader Class Initialized
INFO - 2024-12-10 00:43:42 --> Helper loaded: url_helper
INFO - 2024-12-10 00:43:42 --> Helper loaded: form_helper
INFO - 2024-12-10 00:43:42 --> Helper loaded: file_helper
INFO - 2024-12-10 00:43:42 --> Database Driver Class Initialized
DEBUG - 2024-12-10 00:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 00:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:43:42 --> Form Validation Class Initialized
INFO - 2024-12-10 00:43:42 --> Upload Class Initialized
INFO - 2024-12-10 00:43:42 --> Model "M_login" initialized
INFO - 2024-12-10 00:43:42 --> Model "M_home" initialized
INFO - 2024-12-10 00:43:42 --> Model "M_setting" initialized
INFO - 2024-12-10 00:43:42 --> Controller Class Initialized
INFO - 2024-12-10 00:43:42 --> Model "M_berita" initialized
INFO - 2024-12-10 00:43:42 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 00:43:42 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 00:43:42 --> Final output sent to browser
DEBUG - 2024-12-10 00:43:42 --> Total execution time: 0.0968
INFO - 2024-12-10 00:47:26 --> Config Class Initialized
INFO - 2024-12-10 00:47:26 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:47:26 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:47:26 --> Utf8 Class Initialized
INFO - 2024-12-10 00:47:26 --> URI Class Initialized
INFO - 2024-12-10 00:47:26 --> Router Class Initialized
INFO - 2024-12-10 00:47:26 --> Output Class Initialized
INFO - 2024-12-10 00:47:26 --> Security Class Initialized
DEBUG - 2024-12-10 00:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:47:26 --> Input Class Initialized
INFO - 2024-12-10 00:47:26 --> Language Class Initialized
ERROR - 2024-12-10 00:47:26 --> 404 Page Not Found: Template/front-end
INFO - 2024-12-10 00:47:31 --> Config Class Initialized
INFO - 2024-12-10 00:47:31 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:47:31 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:47:31 --> Utf8 Class Initialized
INFO - 2024-12-10 00:47:31 --> URI Class Initialized
INFO - 2024-12-10 00:47:31 --> Router Class Initialized
INFO - 2024-12-10 00:47:31 --> Output Class Initialized
INFO - 2024-12-10 00:47:31 --> Security Class Initialized
DEBUG - 2024-12-10 00:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:47:31 --> Input Class Initialized
INFO - 2024-12-10 00:47:31 --> Language Class Initialized
ERROR - 2024-12-10 00:47:31 --> 404 Page Not Found: Template/back-end
INFO - 2024-12-10 01:00:18 --> Config Class Initialized
INFO - 2024-12-10 01:00:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:00:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:00:18 --> Utf8 Class Initialized
INFO - 2024-12-10 01:00:18 --> URI Class Initialized
INFO - 2024-12-10 01:00:18 --> Router Class Initialized
INFO - 2024-12-10 01:00:18 --> Output Class Initialized
INFO - 2024-12-10 01:00:18 --> Security Class Initialized
DEBUG - 2024-12-10 01:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:00:18 --> Input Class Initialized
INFO - 2024-12-10 01:00:18 --> Language Class Initialized
INFO - 2024-12-10 01:00:18 --> Loader Class Initialized
INFO - 2024-12-10 01:00:18 --> Helper loaded: url_helper
INFO - 2024-12-10 01:00:18 --> Helper loaded: form_helper
INFO - 2024-12-10 01:00:18 --> Helper loaded: file_helper
INFO - 2024-12-10 01:00:18 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:00:18 --> Form Validation Class Initialized
INFO - 2024-12-10 01:00:18 --> Upload Class Initialized
INFO - 2024-12-10 01:00:18 --> Model "M_login" initialized
INFO - 2024-12-10 01:00:18 --> Model "M_home" initialized
INFO - 2024-12-10 01:00:18 --> Model "M_setting" initialized
INFO - 2024-12-10 01:00:18 --> Controller Class Initialized
INFO - 2024-12-10 01:00:18 --> Model "M_guru" initialized
INFO - 2024-12-10 01:00:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 01:00:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:00:18 --> Final output sent to browser
DEBUG - 2024-12-10 01:00:18 --> Total execution time: 0.2193
INFO - 2024-12-10 01:00:21 --> Config Class Initialized
INFO - 2024-12-10 01:00:21 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:00:21 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:00:21 --> Utf8 Class Initialized
INFO - 2024-12-10 01:00:21 --> URI Class Initialized
INFO - 2024-12-10 01:00:21 --> Router Class Initialized
INFO - 2024-12-10 01:00:21 --> Output Class Initialized
INFO - 2024-12-10 01:00:21 --> Security Class Initialized
DEBUG - 2024-12-10 01:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:00:21 --> Input Class Initialized
INFO - 2024-12-10 01:00:21 --> Language Class Initialized
INFO - 2024-12-10 01:00:21 --> Loader Class Initialized
INFO - 2024-12-10 01:00:21 --> Helper loaded: url_helper
INFO - 2024-12-10 01:00:21 --> Helper loaded: form_helper
INFO - 2024-12-10 01:00:21 --> Helper loaded: file_helper
INFO - 2024-12-10 01:00:21 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:00:21 --> Form Validation Class Initialized
INFO - 2024-12-10 01:00:21 --> Upload Class Initialized
INFO - 2024-12-10 01:00:21 --> Model "M_login" initialized
INFO - 2024-12-10 01:00:21 --> Model "M_home" initialized
INFO - 2024-12-10 01:00:21 --> Model "M_setting" initialized
INFO - 2024-12-10 01:00:21 --> Controller Class Initialized
INFO - 2024-12-10 01:00:21 --> Model "M_guru" initialized
INFO - 2024-12-10 01:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:00:21 --> Pagination Class Initialized
INFO - 2024-12-10 01:00:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:00:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:00:21 --> Final output sent to browser
DEBUG - 2024-12-10 01:00:21 --> Total execution time: 0.1272
INFO - 2024-12-10 01:09:38 --> Config Class Initialized
INFO - 2024-12-10 01:09:38 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:09:38 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:09:38 --> Utf8 Class Initialized
INFO - 2024-12-10 01:09:38 --> URI Class Initialized
INFO - 2024-12-10 01:09:38 --> Router Class Initialized
INFO - 2024-12-10 01:09:38 --> Output Class Initialized
INFO - 2024-12-10 01:09:38 --> Security Class Initialized
DEBUG - 2024-12-10 01:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:09:38 --> Input Class Initialized
INFO - 2024-12-10 01:09:38 --> Language Class Initialized
INFO - 2024-12-10 01:09:38 --> Loader Class Initialized
INFO - 2024-12-10 01:09:38 --> Helper loaded: url_helper
INFO - 2024-12-10 01:09:38 --> Helper loaded: form_helper
INFO - 2024-12-10 01:09:38 --> Helper loaded: file_helper
INFO - 2024-12-10 01:09:38 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:09:38 --> Form Validation Class Initialized
INFO - 2024-12-10 01:09:38 --> Upload Class Initialized
INFO - 2024-12-10 01:09:38 --> Model "M_login" initialized
INFO - 2024-12-10 01:09:38 --> Model "M_home" initialized
INFO - 2024-12-10 01:09:38 --> Model "M_setting" initialized
INFO - 2024-12-10 01:09:38 --> Controller Class Initialized
INFO - 2024-12-10 01:09:38 --> Model "M_guru" initialized
INFO - 2024-12-10 01:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:09:38 --> Pagination Class Initialized
INFO - 2024-12-10 01:09:38 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:09:38 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:09:38 --> Final output sent to browser
DEBUG - 2024-12-10 01:09:38 --> Total execution time: 0.1307
INFO - 2024-12-10 01:09:55 --> Config Class Initialized
INFO - 2024-12-10 01:09:55 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:09:55 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:09:55 --> Utf8 Class Initialized
INFO - 2024-12-10 01:09:55 --> URI Class Initialized
INFO - 2024-12-10 01:09:55 --> Router Class Initialized
INFO - 2024-12-10 01:09:55 --> Output Class Initialized
INFO - 2024-12-10 01:09:55 --> Security Class Initialized
DEBUG - 2024-12-10 01:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:09:55 --> Input Class Initialized
INFO - 2024-12-10 01:09:55 --> Language Class Initialized
INFO - 2024-12-10 01:09:55 --> Loader Class Initialized
INFO - 2024-12-10 01:09:55 --> Helper loaded: url_helper
INFO - 2024-12-10 01:09:55 --> Helper loaded: form_helper
INFO - 2024-12-10 01:09:55 --> Helper loaded: file_helper
INFO - 2024-12-10 01:09:55 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:09:55 --> Form Validation Class Initialized
INFO - 2024-12-10 01:09:55 --> Upload Class Initialized
INFO - 2024-12-10 01:09:55 --> Model "M_login" initialized
INFO - 2024-12-10 01:09:55 --> Model "M_home" initialized
INFO - 2024-12-10 01:09:55 --> Model "M_setting" initialized
INFO - 2024-12-10 01:09:55 --> Controller Class Initialized
INFO - 2024-12-10 01:09:55 --> Model "M_guru" initialized
INFO - 2024-12-10 01:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:09:55 --> Pagination Class Initialized
INFO - 2024-12-10 01:09:55 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:09:55 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:09:55 --> Final output sent to browser
DEBUG - 2024-12-10 01:09:55 --> Total execution time: 0.1326
INFO - 2024-12-10 01:10:16 --> Config Class Initialized
INFO - 2024-12-10 01:10:16 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:10:16 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:10:16 --> Utf8 Class Initialized
INFO - 2024-12-10 01:10:16 --> URI Class Initialized
INFO - 2024-12-10 01:10:16 --> Router Class Initialized
INFO - 2024-12-10 01:10:16 --> Output Class Initialized
INFO - 2024-12-10 01:10:16 --> Security Class Initialized
DEBUG - 2024-12-10 01:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:10:16 --> Input Class Initialized
INFO - 2024-12-10 01:10:16 --> Language Class Initialized
INFO - 2024-12-10 01:10:16 --> Loader Class Initialized
INFO - 2024-12-10 01:10:16 --> Helper loaded: url_helper
INFO - 2024-12-10 01:10:16 --> Helper loaded: form_helper
INFO - 2024-12-10 01:10:16 --> Helper loaded: file_helper
INFO - 2024-12-10 01:10:16 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:10:16 --> Form Validation Class Initialized
INFO - 2024-12-10 01:10:16 --> Upload Class Initialized
INFO - 2024-12-10 01:10:16 --> Model "M_login" initialized
INFO - 2024-12-10 01:10:16 --> Model "M_home" initialized
INFO - 2024-12-10 01:10:16 --> Model "M_setting" initialized
INFO - 2024-12-10 01:10:16 --> Controller Class Initialized
INFO - 2024-12-10 01:10:16 --> Model "M_guru" initialized
INFO - 2024-12-10 01:10:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-10 01:10:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:10:16 --> Final output sent to browser
DEBUG - 2024-12-10 01:10:16 --> Total execution time: 0.1159
INFO - 2024-12-10 01:10:20 --> Config Class Initialized
INFO - 2024-12-10 01:10:20 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:10:20 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:10:20 --> Utf8 Class Initialized
INFO - 2024-12-10 01:10:20 --> URI Class Initialized
INFO - 2024-12-10 01:10:20 --> Router Class Initialized
INFO - 2024-12-10 01:10:20 --> Output Class Initialized
INFO - 2024-12-10 01:10:20 --> Security Class Initialized
DEBUG - 2024-12-10 01:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:10:20 --> Input Class Initialized
INFO - 2024-12-10 01:10:20 --> Language Class Initialized
INFO - 2024-12-10 01:10:20 --> Loader Class Initialized
INFO - 2024-12-10 01:10:20 --> Helper loaded: url_helper
INFO - 2024-12-10 01:10:20 --> Helper loaded: form_helper
INFO - 2024-12-10 01:10:20 --> Helper loaded: file_helper
INFO - 2024-12-10 01:10:20 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:10:20 --> Form Validation Class Initialized
INFO - 2024-12-10 01:10:20 --> Upload Class Initialized
INFO - 2024-12-10 01:10:20 --> Model "M_login" initialized
INFO - 2024-12-10 01:10:20 --> Model "M_home" initialized
INFO - 2024-12-10 01:10:20 --> Model "M_setting" initialized
INFO - 2024-12-10 01:10:20 --> Controller Class Initialized
INFO - 2024-12-10 01:10:20 --> Model "M_guru" initialized
INFO - 2024-12-10 01:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:10:20 --> Pagination Class Initialized
INFO - 2024-12-10 01:10:20 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:10:20 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:10:20 --> Final output sent to browser
DEBUG - 2024-12-10 01:10:20 --> Total execution time: 0.1057
INFO - 2024-12-10 01:14:30 --> Config Class Initialized
INFO - 2024-12-10 01:14:30 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:14:30 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:14:30 --> Utf8 Class Initialized
INFO - 2024-12-10 01:14:30 --> URI Class Initialized
INFO - 2024-12-10 01:14:30 --> Router Class Initialized
INFO - 2024-12-10 01:14:30 --> Output Class Initialized
INFO - 2024-12-10 01:14:30 --> Security Class Initialized
DEBUG - 2024-12-10 01:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:14:30 --> Input Class Initialized
INFO - 2024-12-10 01:14:30 --> Language Class Initialized
INFO - 2024-12-10 01:14:30 --> Loader Class Initialized
INFO - 2024-12-10 01:14:30 --> Helper loaded: url_helper
INFO - 2024-12-10 01:14:30 --> Helper loaded: form_helper
INFO - 2024-12-10 01:14:30 --> Helper loaded: file_helper
INFO - 2024-12-10 01:14:30 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:14:30 --> Form Validation Class Initialized
INFO - 2024-12-10 01:14:30 --> Upload Class Initialized
INFO - 2024-12-10 01:14:30 --> Model "M_login" initialized
INFO - 2024-12-10 01:14:30 --> Model "M_home" initialized
INFO - 2024-12-10 01:14:30 --> Model "M_setting" initialized
INFO - 2024-12-10 01:14:30 --> Controller Class Initialized
INFO - 2024-12-10 01:14:30 --> Model "M_berita" initialized
INFO - 2024-12-10 01:14:30 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 01:14:30 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 01:14:30 --> Final output sent to browser
DEBUG - 2024-12-10 01:14:30 --> Total execution time: 0.1799
INFO - 2024-12-10 01:14:32 --> Config Class Initialized
INFO - 2024-12-10 01:14:32 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:14:32 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:14:32 --> Utf8 Class Initialized
INFO - 2024-12-10 01:14:32 --> URI Class Initialized
INFO - 2024-12-10 01:14:32 --> Router Class Initialized
INFO - 2024-12-10 01:14:32 --> Output Class Initialized
INFO - 2024-12-10 01:14:32 --> Security Class Initialized
DEBUG - 2024-12-10 01:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:14:32 --> Input Class Initialized
INFO - 2024-12-10 01:14:32 --> Language Class Initialized
INFO - 2024-12-10 01:14:32 --> Loader Class Initialized
INFO - 2024-12-10 01:14:32 --> Helper loaded: url_helper
INFO - 2024-12-10 01:14:32 --> Helper loaded: form_helper
INFO - 2024-12-10 01:14:32 --> Helper loaded: file_helper
INFO - 2024-12-10 01:14:32 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:14:32 --> Form Validation Class Initialized
INFO - 2024-12-10 01:14:32 --> Upload Class Initialized
INFO - 2024-12-10 01:14:32 --> Model "M_login" initialized
INFO - 2024-12-10 01:14:32 --> Model "M_home" initialized
INFO - 2024-12-10 01:14:32 --> Model "M_setting" initialized
INFO - 2024-12-10 01:14:32 --> Controller Class Initialized
INFO - 2024-12-10 01:14:32 --> Model "M_guru" initialized
INFO - 2024-12-10 01:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:14:32 --> Pagination Class Initialized
INFO - 2024-12-10 01:14:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:14:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:14:32 --> Final output sent to browser
DEBUG - 2024-12-10 01:14:32 --> Total execution time: 0.1213
INFO - 2024-12-10 01:15:28 --> Config Class Initialized
INFO - 2024-12-10 01:15:28 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:15:28 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:15:28 --> Utf8 Class Initialized
INFO - 2024-12-10 01:15:28 --> URI Class Initialized
INFO - 2024-12-10 01:15:28 --> Router Class Initialized
INFO - 2024-12-10 01:15:28 --> Output Class Initialized
INFO - 2024-12-10 01:15:28 --> Security Class Initialized
DEBUG - 2024-12-10 01:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:15:28 --> Input Class Initialized
INFO - 2024-12-10 01:15:28 --> Language Class Initialized
INFO - 2024-12-10 01:15:28 --> Loader Class Initialized
INFO - 2024-12-10 01:15:28 --> Helper loaded: url_helper
INFO - 2024-12-10 01:15:28 --> Helper loaded: form_helper
INFO - 2024-12-10 01:15:28 --> Helper loaded: file_helper
INFO - 2024-12-10 01:15:28 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:15:28 --> Form Validation Class Initialized
INFO - 2024-12-10 01:15:28 --> Upload Class Initialized
INFO - 2024-12-10 01:15:28 --> Model "M_login" initialized
INFO - 2024-12-10 01:15:28 --> Model "M_home" initialized
INFO - 2024-12-10 01:15:28 --> Model "M_setting" initialized
INFO - 2024-12-10 01:15:28 --> Controller Class Initialized
INFO - 2024-12-10 01:15:28 --> Model "M_guru" initialized
INFO - 2024-12-10 01:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:15:28 --> Pagination Class Initialized
INFO - 2024-12-10 01:15:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:15:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:15:28 --> Final output sent to browser
DEBUG - 2024-12-10 01:15:28 --> Total execution time: 0.1343
INFO - 2024-12-10 01:15:35 --> Config Class Initialized
INFO - 2024-12-10 01:15:35 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:15:35 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:15:35 --> Utf8 Class Initialized
INFO - 2024-12-10 01:15:35 --> URI Class Initialized
INFO - 2024-12-10 01:15:35 --> Router Class Initialized
INFO - 2024-12-10 01:15:35 --> Output Class Initialized
INFO - 2024-12-10 01:15:35 --> Security Class Initialized
DEBUG - 2024-12-10 01:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:15:35 --> Input Class Initialized
INFO - 2024-12-10 01:15:35 --> Language Class Initialized
INFO - 2024-12-10 01:15:35 --> Loader Class Initialized
INFO - 2024-12-10 01:15:35 --> Helper loaded: url_helper
INFO - 2024-12-10 01:15:35 --> Helper loaded: form_helper
INFO - 2024-12-10 01:15:35 --> Helper loaded: file_helper
INFO - 2024-12-10 01:15:35 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:15:35 --> Form Validation Class Initialized
INFO - 2024-12-10 01:15:35 --> Upload Class Initialized
INFO - 2024-12-10 01:15:35 --> Model "M_login" initialized
INFO - 2024-12-10 01:15:35 --> Model "M_home" initialized
INFO - 2024-12-10 01:15:35 --> Model "M_setting" initialized
INFO - 2024-12-10 01:15:35 --> Controller Class Initialized
INFO - 2024-12-10 01:15:35 --> Model "M_guru" initialized
INFO - 2024-12-10 01:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:15:35 --> Pagination Class Initialized
INFO - 2024-12-10 01:15:35 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:15:35 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:15:35 --> Final output sent to browser
DEBUG - 2024-12-10 01:15:35 --> Total execution time: 0.2225
INFO - 2024-12-10 01:23:38 --> Config Class Initialized
INFO - 2024-12-10 01:23:38 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:23:38 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:23:38 --> Utf8 Class Initialized
INFO - 2024-12-10 01:23:38 --> URI Class Initialized
INFO - 2024-12-10 01:23:38 --> Router Class Initialized
INFO - 2024-12-10 01:23:38 --> Output Class Initialized
INFO - 2024-12-10 01:23:38 --> Security Class Initialized
DEBUG - 2024-12-10 01:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:23:38 --> Input Class Initialized
INFO - 2024-12-10 01:23:38 --> Language Class Initialized
ERROR - 2024-12-10 01:23:38 --> 404 Page Not Found: Template/front-end
INFO - 2024-12-10 01:23:43 --> Config Class Initialized
INFO - 2024-12-10 01:23:43 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:23:44 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:23:44 --> Utf8 Class Initialized
INFO - 2024-12-10 01:23:44 --> URI Class Initialized
INFO - 2024-12-10 01:23:44 --> Router Class Initialized
INFO - 2024-12-10 01:23:44 --> Output Class Initialized
INFO - 2024-12-10 01:23:44 --> Security Class Initialized
DEBUG - 2024-12-10 01:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:23:44 --> Input Class Initialized
INFO - 2024-12-10 01:23:44 --> Language Class Initialized
INFO - 2024-12-10 01:23:44 --> Loader Class Initialized
INFO - 2024-12-10 01:23:44 --> Helper loaded: url_helper
INFO - 2024-12-10 01:23:44 --> Helper loaded: form_helper
INFO - 2024-12-10 01:23:44 --> Helper loaded: file_helper
INFO - 2024-12-10 01:23:44 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:23:44 --> Form Validation Class Initialized
INFO - 2024-12-10 01:23:44 --> Upload Class Initialized
INFO - 2024-12-10 01:23:44 --> Model "M_login" initialized
INFO - 2024-12-10 01:23:44 --> Model "M_home" initialized
INFO - 2024-12-10 01:23:44 --> Model "M_setting" initialized
INFO - 2024-12-10 01:23:44 --> Controller Class Initialized
INFO - 2024-12-10 01:23:44 --> Model "M_guru" initialized
INFO - 2024-12-10 01:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:23:44 --> Pagination Class Initialized
INFO - 2024-12-10 01:23:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:23:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:23:44 --> Final output sent to browser
DEBUG - 2024-12-10 01:23:44 --> Total execution time: 0.2704
INFO - 2024-12-10 01:23:47 --> Config Class Initialized
INFO - 2024-12-10 01:23:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:23:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:23:47 --> Utf8 Class Initialized
INFO - 2024-12-10 01:23:47 --> URI Class Initialized
INFO - 2024-12-10 01:23:47 --> Router Class Initialized
INFO - 2024-12-10 01:23:47 --> Output Class Initialized
INFO - 2024-12-10 01:23:47 --> Security Class Initialized
DEBUG - 2024-12-10 01:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:23:47 --> Input Class Initialized
INFO - 2024-12-10 01:23:47 --> Language Class Initialized
INFO - 2024-12-10 01:23:47 --> Loader Class Initialized
INFO - 2024-12-10 01:23:47 --> Helper loaded: url_helper
INFO - 2024-12-10 01:23:47 --> Helper loaded: form_helper
INFO - 2024-12-10 01:23:47 --> Helper loaded: file_helper
INFO - 2024-12-10 01:23:47 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:23:47 --> Form Validation Class Initialized
INFO - 2024-12-10 01:23:47 --> Upload Class Initialized
INFO - 2024-12-10 01:23:47 --> Model "M_login" initialized
INFO - 2024-12-10 01:23:47 --> Model "M_home" initialized
INFO - 2024-12-10 01:23:47 --> Model "M_setting" initialized
INFO - 2024-12-10 01:23:47 --> Controller Class Initialized
INFO - 2024-12-10 01:23:47 --> Model "M_guru" initialized
INFO - 2024-12-10 01:23:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:23:47 --> Pagination Class Initialized
INFO - 2024-12-10 01:23:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:23:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:23:47 --> Final output sent to browser
DEBUG - 2024-12-10 01:23:47 --> Total execution time: 0.1062
INFO - 2024-12-10 01:23:56 --> Config Class Initialized
INFO - 2024-12-10 01:23:56 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:23:56 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:23:56 --> Utf8 Class Initialized
INFO - 2024-12-10 01:23:56 --> URI Class Initialized
INFO - 2024-12-10 01:23:56 --> Router Class Initialized
INFO - 2024-12-10 01:23:56 --> Output Class Initialized
INFO - 2024-12-10 01:23:56 --> Security Class Initialized
DEBUG - 2024-12-10 01:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:23:56 --> Input Class Initialized
INFO - 2024-12-10 01:23:56 --> Language Class Initialized
INFO - 2024-12-10 01:23:56 --> Loader Class Initialized
INFO - 2024-12-10 01:23:56 --> Helper loaded: url_helper
INFO - 2024-12-10 01:23:56 --> Helper loaded: form_helper
INFO - 2024-12-10 01:23:56 --> Helper loaded: file_helper
INFO - 2024-12-10 01:23:56 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:23:56 --> Form Validation Class Initialized
INFO - 2024-12-10 01:23:56 --> Upload Class Initialized
INFO - 2024-12-10 01:23:56 --> Model "M_login" initialized
INFO - 2024-12-10 01:23:56 --> Model "M_home" initialized
INFO - 2024-12-10 01:23:56 --> Model "M_setting" initialized
INFO - 2024-12-10 01:23:56 --> Controller Class Initialized
INFO - 2024-12-10 01:23:56 --> Model "M_guru" initialized
INFO - 2024-12-10 01:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:23:56 --> Pagination Class Initialized
INFO - 2024-12-10 01:23:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:23:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:23:56 --> Final output sent to browser
DEBUG - 2024-12-10 01:23:56 --> Total execution time: 0.1224
INFO - 2024-12-10 01:29:17 --> Config Class Initialized
INFO - 2024-12-10 01:29:17 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:29:17 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:29:17 --> Utf8 Class Initialized
INFO - 2024-12-10 01:29:17 --> URI Class Initialized
INFO - 2024-12-10 01:29:17 --> Router Class Initialized
INFO - 2024-12-10 01:29:17 --> Output Class Initialized
INFO - 2024-12-10 01:29:17 --> Security Class Initialized
DEBUG - 2024-12-10 01:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:29:17 --> Input Class Initialized
INFO - 2024-12-10 01:29:17 --> Language Class Initialized
INFO - 2024-12-10 01:29:17 --> Loader Class Initialized
INFO - 2024-12-10 01:29:17 --> Helper loaded: url_helper
INFO - 2024-12-10 01:29:17 --> Helper loaded: form_helper
INFO - 2024-12-10 01:29:17 --> Helper loaded: file_helper
INFO - 2024-12-10 01:29:17 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:29:17 --> Form Validation Class Initialized
INFO - 2024-12-10 01:29:17 --> Upload Class Initialized
INFO - 2024-12-10 01:29:17 --> Model "M_login" initialized
INFO - 2024-12-10 01:29:17 --> Model "M_home" initialized
INFO - 2024-12-10 01:29:17 --> Model "M_setting" initialized
INFO - 2024-12-10 01:29:17 --> Controller Class Initialized
INFO - 2024-12-10 01:29:17 --> Model "M_guru" initialized
INFO - 2024-12-10 01:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:29:17 --> Pagination Class Initialized
INFO - 2024-12-10 01:29:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:29:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:29:17 --> Final output sent to browser
DEBUG - 2024-12-10 01:29:17 --> Total execution time: 0.1192
INFO - 2024-12-10 01:29:47 --> Config Class Initialized
INFO - 2024-12-10 01:29:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:29:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:29:48 --> Utf8 Class Initialized
INFO - 2024-12-10 01:29:48 --> URI Class Initialized
INFO - 2024-12-10 01:29:48 --> Router Class Initialized
INFO - 2024-12-10 01:29:48 --> Output Class Initialized
INFO - 2024-12-10 01:29:48 --> Security Class Initialized
DEBUG - 2024-12-10 01:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:29:48 --> Input Class Initialized
INFO - 2024-12-10 01:29:48 --> Language Class Initialized
INFO - 2024-12-10 01:29:48 --> Loader Class Initialized
INFO - 2024-12-10 01:29:48 --> Helper loaded: url_helper
INFO - 2024-12-10 01:29:48 --> Helper loaded: form_helper
INFO - 2024-12-10 01:29:48 --> Helper loaded: file_helper
INFO - 2024-12-10 01:29:48 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:29:48 --> Form Validation Class Initialized
INFO - 2024-12-10 01:29:48 --> Upload Class Initialized
INFO - 2024-12-10 01:29:48 --> Model "M_login" initialized
INFO - 2024-12-10 01:29:48 --> Model "M_home" initialized
INFO - 2024-12-10 01:29:48 --> Model "M_setting" initialized
INFO - 2024-12-10 01:29:48 --> Controller Class Initialized
INFO - 2024-12-10 01:29:48 --> Model "M_guru" initialized
INFO - 2024-12-10 01:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:29:48 --> Pagination Class Initialized
ERROR - 2024-12-10 01:29:48 --> Severity: error --> Exception: Call to undefined function issets() C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php 67
INFO - 2024-12-10 01:29:52 --> Config Class Initialized
INFO - 2024-12-10 01:29:52 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:29:52 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:29:52 --> Utf8 Class Initialized
INFO - 2024-12-10 01:29:52 --> URI Class Initialized
INFO - 2024-12-10 01:29:52 --> Router Class Initialized
INFO - 2024-12-10 01:29:52 --> Output Class Initialized
INFO - 2024-12-10 01:29:52 --> Security Class Initialized
DEBUG - 2024-12-10 01:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:29:52 --> Input Class Initialized
INFO - 2024-12-10 01:29:52 --> Language Class Initialized
INFO - 2024-12-10 01:29:52 --> Loader Class Initialized
INFO - 2024-12-10 01:29:52 --> Helper loaded: url_helper
INFO - 2024-12-10 01:29:52 --> Helper loaded: form_helper
INFO - 2024-12-10 01:29:52 --> Helper loaded: file_helper
INFO - 2024-12-10 01:29:52 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:29:52 --> Form Validation Class Initialized
INFO - 2024-12-10 01:29:52 --> Upload Class Initialized
INFO - 2024-12-10 01:29:52 --> Model "M_login" initialized
INFO - 2024-12-10 01:29:52 --> Model "M_home" initialized
INFO - 2024-12-10 01:29:52 --> Model "M_setting" initialized
INFO - 2024-12-10 01:29:52 --> Controller Class Initialized
INFO - 2024-12-10 01:29:52 --> Model "M_guru" initialized
INFO - 2024-12-10 01:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:29:52 --> Pagination Class Initialized
INFO - 2024-12-10 01:29:52 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:29:52 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:29:52 --> Final output sent to browser
DEBUG - 2024-12-10 01:29:52 --> Total execution time: 0.1312
INFO - 2024-12-10 01:33:04 --> Config Class Initialized
INFO - 2024-12-10 01:33:04 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:33:04 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:33:04 --> Utf8 Class Initialized
INFO - 2024-12-10 01:33:04 --> URI Class Initialized
INFO - 2024-12-10 01:33:04 --> Router Class Initialized
INFO - 2024-12-10 01:33:04 --> Output Class Initialized
INFO - 2024-12-10 01:33:04 --> Security Class Initialized
DEBUG - 2024-12-10 01:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:33:04 --> Input Class Initialized
INFO - 2024-12-10 01:33:04 --> Language Class Initialized
INFO - 2024-12-10 01:33:04 --> Loader Class Initialized
INFO - 2024-12-10 01:33:04 --> Helper loaded: url_helper
INFO - 2024-12-10 01:33:04 --> Helper loaded: form_helper
INFO - 2024-12-10 01:33:04 --> Helper loaded: file_helper
INFO - 2024-12-10 01:33:04 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:33:04 --> Form Validation Class Initialized
INFO - 2024-12-10 01:33:04 --> Upload Class Initialized
INFO - 2024-12-10 01:33:04 --> Model "M_login" initialized
INFO - 2024-12-10 01:33:04 --> Model "M_home" initialized
INFO - 2024-12-10 01:33:04 --> Model "M_setting" initialized
INFO - 2024-12-10 01:33:04 --> Controller Class Initialized
INFO - 2024-12-10 01:33:04 --> Model "M_guru" initialized
INFO - 2024-12-10 01:33:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:33:04 --> Pagination Class Initialized
ERROR - 2024-12-10 01:33:04 --> Severity: Warning --> Undefined property: Home::$Berita_model C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\controllers\Home.php 45
ERROR - 2024-12-10 01:33:04 --> Severity: error --> Exception: Call to a member function get_count() on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\controllers\Home.php 45
INFO - 2024-12-10 01:36:25 --> Config Class Initialized
INFO - 2024-12-10 01:36:25 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:36:25 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:36:25 --> Utf8 Class Initialized
INFO - 2024-12-10 01:36:25 --> URI Class Initialized
INFO - 2024-12-10 01:36:25 --> Router Class Initialized
INFO - 2024-12-10 01:36:25 --> Output Class Initialized
INFO - 2024-12-10 01:36:25 --> Security Class Initialized
DEBUG - 2024-12-10 01:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:36:25 --> Input Class Initialized
INFO - 2024-12-10 01:36:25 --> Language Class Initialized
INFO - 2024-12-10 01:36:25 --> Loader Class Initialized
INFO - 2024-12-10 01:36:25 --> Helper loaded: url_helper
INFO - 2024-12-10 01:36:25 --> Helper loaded: form_helper
INFO - 2024-12-10 01:36:25 --> Helper loaded: file_helper
INFO - 2024-12-10 01:36:25 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:36:25 --> Form Validation Class Initialized
INFO - 2024-12-10 01:36:25 --> Upload Class Initialized
INFO - 2024-12-10 01:36:25 --> Model "M_login" initialized
INFO - 2024-12-10 01:36:25 --> Model "M_home" initialized
INFO - 2024-12-10 01:36:25 --> Model "M_setting" initialized
INFO - 2024-12-10 01:36:25 --> Controller Class Initialized
INFO - 2024-12-10 01:36:25 --> Model "M_guru" initialized
INFO - 2024-12-10 01:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:36:25 --> Pagination Class Initialized
INFO - 2024-12-10 01:36:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:36:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:36:25 --> Final output sent to browser
DEBUG - 2024-12-10 01:36:25 --> Total execution time: 0.1441
INFO - 2024-12-10 01:37:34 --> Config Class Initialized
INFO - 2024-12-10 01:37:34 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:37:34 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:37:34 --> Utf8 Class Initialized
INFO - 2024-12-10 01:37:34 --> URI Class Initialized
INFO - 2024-12-10 01:37:34 --> Router Class Initialized
INFO - 2024-12-10 01:37:34 --> Output Class Initialized
INFO - 2024-12-10 01:37:34 --> Security Class Initialized
DEBUG - 2024-12-10 01:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:37:34 --> Input Class Initialized
INFO - 2024-12-10 01:37:34 --> Language Class Initialized
INFO - 2024-12-10 01:37:34 --> Loader Class Initialized
INFO - 2024-12-10 01:37:34 --> Helper loaded: url_helper
INFO - 2024-12-10 01:37:34 --> Helper loaded: form_helper
INFO - 2024-12-10 01:37:34 --> Helper loaded: file_helper
INFO - 2024-12-10 01:37:34 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:37:34 --> Form Validation Class Initialized
INFO - 2024-12-10 01:37:34 --> Upload Class Initialized
INFO - 2024-12-10 01:37:34 --> Model "M_login" initialized
INFO - 2024-12-10 01:37:34 --> Model "M_home" initialized
INFO - 2024-12-10 01:37:34 --> Model "M_setting" initialized
INFO - 2024-12-10 01:37:34 --> Controller Class Initialized
INFO - 2024-12-10 01:37:34 --> Model "M_guru" initialized
INFO - 2024-12-10 01:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:37:34 --> Pagination Class Initialized
INFO - 2024-12-10 01:37:34 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:37:34 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:37:34 --> Final output sent to browser
DEBUG - 2024-12-10 01:37:34 --> Total execution time: 0.1091
INFO - 2024-12-10 01:39:09 --> Config Class Initialized
INFO - 2024-12-10 01:39:09 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:39:09 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:39:09 --> Utf8 Class Initialized
INFO - 2024-12-10 01:39:09 --> URI Class Initialized
INFO - 2024-12-10 01:39:09 --> Router Class Initialized
INFO - 2024-12-10 01:39:09 --> Output Class Initialized
INFO - 2024-12-10 01:39:09 --> Security Class Initialized
DEBUG - 2024-12-10 01:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:39:09 --> Input Class Initialized
INFO - 2024-12-10 01:39:09 --> Language Class Initialized
INFO - 2024-12-10 01:39:09 --> Loader Class Initialized
INFO - 2024-12-10 01:39:09 --> Helper loaded: url_helper
INFO - 2024-12-10 01:39:09 --> Helper loaded: form_helper
INFO - 2024-12-10 01:39:09 --> Helper loaded: file_helper
INFO - 2024-12-10 01:39:09 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:39:10 --> Form Validation Class Initialized
INFO - 2024-12-10 01:39:10 --> Upload Class Initialized
INFO - 2024-12-10 01:39:10 --> Model "M_login" initialized
INFO - 2024-12-10 01:39:10 --> Model "M_home" initialized
INFO - 2024-12-10 01:39:10 --> Model "M_setting" initialized
INFO - 2024-12-10 01:39:10 --> Controller Class Initialized
INFO - 2024-12-10 01:39:10 --> Model "M_guru" initialized
INFO - 2024-12-10 01:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:39:10 --> Pagination Class Initialized
ERROR - 2024-12-10 01:39:10 --> Query error: Table 'web-sekolah.berita' doesn't exist - Invalid query: SELECT *
FROM `tbl_berita`, `berita`
ORDER BY `id_berita` DESC
 LIMIT 8
INFO - 2024-12-10 01:39:10 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-10 01:40:17 --> Config Class Initialized
INFO - 2024-12-10 01:40:17 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:40:17 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:40:17 --> Utf8 Class Initialized
INFO - 2024-12-10 01:40:17 --> URI Class Initialized
INFO - 2024-12-10 01:40:17 --> Router Class Initialized
INFO - 2024-12-10 01:40:17 --> Output Class Initialized
INFO - 2024-12-10 01:40:17 --> Security Class Initialized
DEBUG - 2024-12-10 01:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:40:17 --> Input Class Initialized
INFO - 2024-12-10 01:40:17 --> Language Class Initialized
INFO - 2024-12-10 01:40:17 --> Loader Class Initialized
INFO - 2024-12-10 01:40:17 --> Helper loaded: url_helper
INFO - 2024-12-10 01:40:17 --> Helper loaded: form_helper
INFO - 2024-12-10 01:40:17 --> Helper loaded: file_helper
INFO - 2024-12-10 01:40:17 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:40:17 --> Form Validation Class Initialized
INFO - 2024-12-10 01:40:17 --> Upload Class Initialized
INFO - 2024-12-10 01:40:17 --> Model "M_login" initialized
INFO - 2024-12-10 01:40:17 --> Model "M_home" initialized
INFO - 2024-12-10 01:40:17 --> Model "M_setting" initialized
INFO - 2024-12-10 01:40:17 --> Controller Class Initialized
INFO - 2024-12-10 01:40:17 --> Model "M_guru" initialized
INFO - 2024-12-10 01:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:40:17 --> Pagination Class Initialized
INFO - 2024-12-10 01:40:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:40:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:40:17 --> Final output sent to browser
DEBUG - 2024-12-10 01:40:17 --> Total execution time: 0.1170
INFO - 2024-12-10 01:40:21 --> Config Class Initialized
INFO - 2024-12-10 01:40:21 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:40:21 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:40:21 --> Utf8 Class Initialized
INFO - 2024-12-10 01:40:21 --> URI Class Initialized
INFO - 2024-12-10 01:40:21 --> Router Class Initialized
INFO - 2024-12-10 01:40:21 --> Output Class Initialized
INFO - 2024-12-10 01:40:21 --> Security Class Initialized
DEBUG - 2024-12-10 01:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:40:21 --> Input Class Initialized
INFO - 2024-12-10 01:40:21 --> Language Class Initialized
INFO - 2024-12-10 01:40:21 --> Loader Class Initialized
INFO - 2024-12-10 01:40:21 --> Helper loaded: url_helper
INFO - 2024-12-10 01:40:21 --> Helper loaded: form_helper
INFO - 2024-12-10 01:40:21 --> Helper loaded: file_helper
INFO - 2024-12-10 01:40:21 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:40:21 --> Form Validation Class Initialized
INFO - 2024-12-10 01:40:21 --> Upload Class Initialized
INFO - 2024-12-10 01:40:21 --> Model "M_login" initialized
INFO - 2024-12-10 01:40:21 --> Model "M_home" initialized
INFO - 2024-12-10 01:40:21 --> Model "M_setting" initialized
INFO - 2024-12-10 01:40:21 --> Controller Class Initialized
INFO - 2024-12-10 01:40:21 --> Model "M_guru" initialized
INFO - 2024-12-10 01:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:40:21 --> Pagination Class Initialized
INFO - 2024-12-10 01:40:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:40:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:40:21 --> Final output sent to browser
DEBUG - 2024-12-10 01:40:21 --> Total execution time: 0.0990
INFO - 2024-12-10 01:41:21 --> Config Class Initialized
INFO - 2024-12-10 01:41:21 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:41:21 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:41:21 --> Utf8 Class Initialized
INFO - 2024-12-10 01:41:21 --> URI Class Initialized
INFO - 2024-12-10 01:41:21 --> Router Class Initialized
INFO - 2024-12-10 01:41:21 --> Output Class Initialized
INFO - 2024-12-10 01:41:21 --> Security Class Initialized
DEBUG - 2024-12-10 01:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:41:21 --> Input Class Initialized
INFO - 2024-12-10 01:41:21 --> Language Class Initialized
INFO - 2024-12-10 01:41:21 --> Loader Class Initialized
INFO - 2024-12-10 01:41:21 --> Helper loaded: url_helper
INFO - 2024-12-10 01:41:21 --> Helper loaded: form_helper
INFO - 2024-12-10 01:41:21 --> Helper loaded: file_helper
INFO - 2024-12-10 01:41:21 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:41:21 --> Form Validation Class Initialized
INFO - 2024-12-10 01:41:21 --> Upload Class Initialized
INFO - 2024-12-10 01:41:21 --> Model "M_login" initialized
INFO - 2024-12-10 01:41:21 --> Model "M_home" initialized
INFO - 2024-12-10 01:41:21 --> Model "M_setting" initialized
INFO - 2024-12-10 01:41:21 --> Controller Class Initialized
INFO - 2024-12-10 01:41:21 --> Model "M_guru" initialized
INFO - 2024-12-10 01:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:41:21 --> Pagination Class Initialized
ERROR - 2024-12-10 01:41:21 --> Severity: error --> Exception: Unsupported operand types: array / int C:\xampp\htdocs\tugas-kelompok\web-sekolah\system\libraries\Pagination.php 413
INFO - 2024-12-10 01:41:33 --> Config Class Initialized
INFO - 2024-12-10 01:41:33 --> Hooks Class Initialized
DEBUG - 2024-12-10 01:41:33 --> UTF-8 Support Enabled
INFO - 2024-12-10 01:41:33 --> Utf8 Class Initialized
INFO - 2024-12-10 01:41:33 --> URI Class Initialized
INFO - 2024-12-10 01:41:33 --> Router Class Initialized
INFO - 2024-12-10 01:41:33 --> Output Class Initialized
INFO - 2024-12-10 01:41:33 --> Security Class Initialized
DEBUG - 2024-12-10 01:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 01:41:33 --> Input Class Initialized
INFO - 2024-12-10 01:41:33 --> Language Class Initialized
INFO - 2024-12-10 01:41:33 --> Loader Class Initialized
INFO - 2024-12-10 01:41:33 --> Helper loaded: url_helper
INFO - 2024-12-10 01:41:33 --> Helper loaded: form_helper
INFO - 2024-12-10 01:41:33 --> Helper loaded: file_helper
INFO - 2024-12-10 01:41:33 --> Database Driver Class Initialized
DEBUG - 2024-12-10 01:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 01:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 01:41:33 --> Form Validation Class Initialized
INFO - 2024-12-10 01:41:33 --> Upload Class Initialized
INFO - 2024-12-10 01:41:33 --> Model "M_login" initialized
INFO - 2024-12-10 01:41:33 --> Model "M_home" initialized
INFO - 2024-12-10 01:41:33 --> Model "M_setting" initialized
INFO - 2024-12-10 01:41:33 --> Controller Class Initialized
INFO - 2024-12-10 01:41:33 --> Model "M_guru" initialized
INFO - 2024-12-10 01:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 01:41:33 --> Pagination Class Initialized
INFO - 2024-12-10 01:41:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 01:41:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 01:41:33 --> Final output sent to browser
DEBUG - 2024-12-10 01:41:33 --> Total execution time: 0.1271
INFO - 2024-12-10 02:02:18 --> Config Class Initialized
INFO - 2024-12-10 02:02:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:02:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:02:18 --> Utf8 Class Initialized
INFO - 2024-12-10 02:02:18 --> URI Class Initialized
INFO - 2024-12-10 02:02:18 --> Router Class Initialized
INFO - 2024-12-10 02:02:18 --> Output Class Initialized
INFO - 2024-12-10 02:02:18 --> Security Class Initialized
DEBUG - 2024-12-10 02:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:02:18 --> Input Class Initialized
INFO - 2024-12-10 02:02:18 --> Language Class Initialized
ERROR - 2024-12-10 02:02:18 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\controllers\Home.php 68
INFO - 2024-12-10 02:02:19 --> Config Class Initialized
INFO - 2024-12-10 02:02:19 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:02:19 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:02:19 --> Utf8 Class Initialized
INFO - 2024-12-10 02:02:19 --> URI Class Initialized
INFO - 2024-12-10 02:02:19 --> Router Class Initialized
INFO - 2024-12-10 02:02:19 --> Output Class Initialized
INFO - 2024-12-10 02:02:19 --> Security Class Initialized
DEBUG - 2024-12-10 02:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:02:19 --> Input Class Initialized
INFO - 2024-12-10 02:02:19 --> Language Class Initialized
ERROR - 2024-12-10 02:02:19 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\controllers\Home.php 68
INFO - 2024-12-10 02:02:39 --> Config Class Initialized
INFO - 2024-12-10 02:02:39 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:02:39 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:02:39 --> Utf8 Class Initialized
INFO - 2024-12-10 02:02:39 --> URI Class Initialized
INFO - 2024-12-10 02:02:39 --> Router Class Initialized
INFO - 2024-12-10 02:02:39 --> Output Class Initialized
INFO - 2024-12-10 02:02:39 --> Security Class Initialized
DEBUG - 2024-12-10 02:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:02:39 --> Input Class Initialized
INFO - 2024-12-10 02:02:39 --> Language Class Initialized
INFO - 2024-12-10 02:02:39 --> Loader Class Initialized
INFO - 2024-12-10 02:02:39 --> Helper loaded: url_helper
INFO - 2024-12-10 02:02:39 --> Helper loaded: form_helper
INFO - 2024-12-10 02:02:39 --> Helper loaded: file_helper
INFO - 2024-12-10 02:02:39 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:02:39 --> Form Validation Class Initialized
INFO - 2024-12-10 02:02:39 --> Upload Class Initialized
INFO - 2024-12-10 02:02:39 --> Model "M_login" initialized
INFO - 2024-12-10 02:02:39 --> Model "M_home" initialized
INFO - 2024-12-10 02:02:39 --> Model "M_setting" initialized
INFO - 2024-12-10 02:02:39 --> Controller Class Initialized
INFO - 2024-12-10 02:02:39 --> Model "M_guru" initialized
INFO - 2024-12-10 02:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:02:39 --> Pagination Class Initialized
INFO - 2024-12-10 02:02:39 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:02:39 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:02:39 --> Final output sent to browser
DEBUG - 2024-12-10 02:02:39 --> Total execution time: 0.2491
INFO - 2024-12-10 02:02:47 --> Config Class Initialized
INFO - 2024-12-10 02:02:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:02:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:02:47 --> Utf8 Class Initialized
INFO - 2024-12-10 02:02:47 --> URI Class Initialized
INFO - 2024-12-10 02:02:47 --> Router Class Initialized
INFO - 2024-12-10 02:02:47 --> Output Class Initialized
INFO - 2024-12-10 02:02:47 --> Security Class Initialized
DEBUG - 2024-12-10 02:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:02:47 --> Input Class Initialized
INFO - 2024-12-10 02:02:47 --> Language Class Initialized
INFO - 2024-12-10 02:02:47 --> Loader Class Initialized
INFO - 2024-12-10 02:02:47 --> Helper loaded: url_helper
INFO - 2024-12-10 02:02:47 --> Helper loaded: form_helper
INFO - 2024-12-10 02:02:47 --> Helper loaded: file_helper
INFO - 2024-12-10 02:02:47 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:02:47 --> Form Validation Class Initialized
INFO - 2024-12-10 02:02:47 --> Upload Class Initialized
INFO - 2024-12-10 02:02:47 --> Model "M_login" initialized
INFO - 2024-12-10 02:02:47 --> Model "M_home" initialized
INFO - 2024-12-10 02:02:47 --> Model "M_setting" initialized
INFO - 2024-12-10 02:02:47 --> Controller Class Initialized
INFO - 2024-12-10 02:02:47 --> Model "M_guru" initialized
INFO - 2024-12-10 02:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:02:47 --> Pagination Class Initialized
INFO - 2024-12-10 02:02:48 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:02:48 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:02:48 --> Final output sent to browser
DEBUG - 2024-12-10 02:02:48 --> Total execution time: 0.1125
INFO - 2024-12-10 02:04:01 --> Config Class Initialized
INFO - 2024-12-10 02:04:01 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:04:01 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:04:01 --> Utf8 Class Initialized
INFO - 2024-12-10 02:04:01 --> URI Class Initialized
INFO - 2024-12-10 02:04:01 --> Router Class Initialized
INFO - 2024-12-10 02:04:01 --> Output Class Initialized
INFO - 2024-12-10 02:04:01 --> Security Class Initialized
DEBUG - 2024-12-10 02:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:04:01 --> Input Class Initialized
INFO - 2024-12-10 02:04:01 --> Language Class Initialized
INFO - 2024-12-10 02:04:01 --> Loader Class Initialized
INFO - 2024-12-10 02:04:01 --> Helper loaded: url_helper
INFO - 2024-12-10 02:04:01 --> Helper loaded: form_helper
INFO - 2024-12-10 02:04:01 --> Helper loaded: file_helper
INFO - 2024-12-10 02:04:01 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:04:01 --> Form Validation Class Initialized
INFO - 2024-12-10 02:04:01 --> Upload Class Initialized
INFO - 2024-12-10 02:04:01 --> Model "M_login" initialized
INFO - 2024-12-10 02:04:01 --> Model "M_home" initialized
INFO - 2024-12-10 02:04:01 --> Model "M_setting" initialized
INFO - 2024-12-10 02:04:01 --> Controller Class Initialized
INFO - 2024-12-10 02:04:01 --> Model "M_guru" initialized
INFO - 2024-12-10 02:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:04:01 --> Pagination Class Initialized
ERROR - 2024-12-10 02:04:01 --> Query error: Table 'web-sekolah.berita' doesn't exist - Invalid query: SELECT *
FROM `tbl_berita`, `berita`
ORDER BY `id_berita` DESC
 LIMIT 8
INFO - 2024-12-10 02:04:01 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-10 02:06:24 --> Config Class Initialized
INFO - 2024-12-10 02:06:24 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:06:24 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:06:24 --> Utf8 Class Initialized
INFO - 2024-12-10 02:06:24 --> URI Class Initialized
INFO - 2024-12-10 02:06:24 --> Router Class Initialized
INFO - 2024-12-10 02:06:24 --> Output Class Initialized
INFO - 2024-12-10 02:06:24 --> Security Class Initialized
DEBUG - 2024-12-10 02:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:06:24 --> Input Class Initialized
INFO - 2024-12-10 02:06:24 --> Language Class Initialized
INFO - 2024-12-10 02:06:24 --> Loader Class Initialized
INFO - 2024-12-10 02:06:24 --> Helper loaded: url_helper
INFO - 2024-12-10 02:06:24 --> Helper loaded: form_helper
INFO - 2024-12-10 02:06:24 --> Helper loaded: file_helper
INFO - 2024-12-10 02:06:24 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:06:24 --> Form Validation Class Initialized
INFO - 2024-12-10 02:06:24 --> Upload Class Initialized
INFO - 2024-12-10 02:06:24 --> Model "M_login" initialized
INFO - 2024-12-10 02:06:24 --> Model "M_home" initialized
INFO - 2024-12-10 02:06:24 --> Model "M_setting" initialized
INFO - 2024-12-10 02:06:24 --> Controller Class Initialized
INFO - 2024-12-10 02:06:24 --> Model "M_guru" initialized
INFO - 2024-12-10 02:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:06:24 --> Pagination Class Initialized
INFO - 2024-12-10 02:06:24 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:06:24 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:06:24 --> Final output sent to browser
DEBUG - 2024-12-10 02:06:24 --> Total execution time: 0.1350
INFO - 2024-12-10 02:06:38 --> Config Class Initialized
INFO - 2024-12-10 02:06:38 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:06:38 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:06:38 --> Utf8 Class Initialized
INFO - 2024-12-10 02:06:38 --> URI Class Initialized
INFO - 2024-12-10 02:06:38 --> Router Class Initialized
INFO - 2024-12-10 02:06:38 --> Output Class Initialized
INFO - 2024-12-10 02:06:39 --> Security Class Initialized
DEBUG - 2024-12-10 02:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:06:39 --> Input Class Initialized
INFO - 2024-12-10 02:06:39 --> Language Class Initialized
INFO - 2024-12-10 02:06:39 --> Loader Class Initialized
INFO - 2024-12-10 02:06:39 --> Helper loaded: url_helper
INFO - 2024-12-10 02:06:39 --> Helper loaded: form_helper
INFO - 2024-12-10 02:06:39 --> Helper loaded: file_helper
INFO - 2024-12-10 02:06:39 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:06:39 --> Form Validation Class Initialized
INFO - 2024-12-10 02:06:39 --> Upload Class Initialized
INFO - 2024-12-10 02:06:39 --> Model "M_login" initialized
INFO - 2024-12-10 02:06:39 --> Model "M_home" initialized
INFO - 2024-12-10 02:06:39 --> Model "M_setting" initialized
INFO - 2024-12-10 02:06:39 --> Controller Class Initialized
INFO - 2024-12-10 02:06:39 --> Model "M_guru" initialized
INFO - 2024-12-10 02:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:06:39 --> Pagination Class Initialized
INFO - 2024-12-10 02:06:39 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:06:39 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:06:39 --> Final output sent to browser
DEBUG - 2024-12-10 02:06:39 --> Total execution time: 0.1850
INFO - 2024-12-10 02:06:47 --> Config Class Initialized
INFO - 2024-12-10 02:06:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:06:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:06:47 --> Utf8 Class Initialized
INFO - 2024-12-10 02:06:47 --> URI Class Initialized
INFO - 2024-12-10 02:06:47 --> Router Class Initialized
INFO - 2024-12-10 02:06:47 --> Output Class Initialized
INFO - 2024-12-10 02:06:47 --> Security Class Initialized
DEBUG - 2024-12-10 02:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:06:47 --> Input Class Initialized
INFO - 2024-12-10 02:06:47 --> Language Class Initialized
INFO - 2024-12-10 02:06:47 --> Loader Class Initialized
INFO - 2024-12-10 02:06:47 --> Helper loaded: url_helper
INFO - 2024-12-10 02:06:47 --> Helper loaded: form_helper
INFO - 2024-12-10 02:06:47 --> Helper loaded: file_helper
INFO - 2024-12-10 02:06:47 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:06:47 --> Form Validation Class Initialized
INFO - 2024-12-10 02:06:47 --> Upload Class Initialized
INFO - 2024-12-10 02:06:47 --> Model "M_login" initialized
INFO - 2024-12-10 02:06:47 --> Model "M_home" initialized
INFO - 2024-12-10 02:06:47 --> Model "M_setting" initialized
INFO - 2024-12-10 02:06:47 --> Controller Class Initialized
INFO - 2024-12-10 02:06:47 --> Model "M_guru" initialized
INFO - 2024-12-10 02:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:06:47 --> Pagination Class Initialized
ERROR - 2024-12-10 02:06:47 --> Severity: Warning --> Undefined variable $latest_berita C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php 87
ERROR - 2024-12-10 02:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php 87
INFO - 2024-12-10 02:06:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:06:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:06:47 --> Final output sent to browser
DEBUG - 2024-12-10 02:06:47 --> Total execution time: 0.1680
INFO - 2024-12-10 02:06:53 --> Config Class Initialized
INFO - 2024-12-10 02:06:53 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:06:53 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:06:53 --> Utf8 Class Initialized
INFO - 2024-12-10 02:06:53 --> URI Class Initialized
INFO - 2024-12-10 02:06:53 --> Router Class Initialized
INFO - 2024-12-10 02:06:53 --> Output Class Initialized
INFO - 2024-12-10 02:06:53 --> Security Class Initialized
DEBUG - 2024-12-10 02:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:06:53 --> Input Class Initialized
INFO - 2024-12-10 02:06:53 --> Language Class Initialized
INFO - 2024-12-10 02:06:53 --> Loader Class Initialized
INFO - 2024-12-10 02:06:53 --> Helper loaded: url_helper
INFO - 2024-12-10 02:06:53 --> Helper loaded: form_helper
INFO - 2024-12-10 02:06:53 --> Helper loaded: file_helper
INFO - 2024-12-10 02:06:53 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:06:53 --> Form Validation Class Initialized
INFO - 2024-12-10 02:06:53 --> Upload Class Initialized
INFO - 2024-12-10 02:06:53 --> Model "M_login" initialized
INFO - 2024-12-10 02:06:53 --> Model "M_home" initialized
INFO - 2024-12-10 02:06:53 --> Model "M_setting" initialized
INFO - 2024-12-10 02:06:53 --> Controller Class Initialized
INFO - 2024-12-10 02:06:53 --> Model "M_guru" initialized
INFO - 2024-12-10 02:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:06:53 --> Pagination Class Initialized
INFO - 2024-12-10 02:06:53 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:06:53 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:06:53 --> Final output sent to browser
DEBUG - 2024-12-10 02:06:53 --> Total execution time: 0.0950
INFO - 2024-12-10 02:07:44 --> Config Class Initialized
INFO - 2024-12-10 02:07:44 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:07:44 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:07:44 --> Utf8 Class Initialized
INFO - 2024-12-10 02:07:44 --> URI Class Initialized
INFO - 2024-12-10 02:07:44 --> Router Class Initialized
INFO - 2024-12-10 02:07:44 --> Output Class Initialized
INFO - 2024-12-10 02:07:44 --> Security Class Initialized
DEBUG - 2024-12-10 02:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:07:44 --> Input Class Initialized
INFO - 2024-12-10 02:07:44 --> Language Class Initialized
INFO - 2024-12-10 02:07:44 --> Loader Class Initialized
INFO - 2024-12-10 02:07:44 --> Helper loaded: url_helper
INFO - 2024-12-10 02:07:44 --> Helper loaded: form_helper
INFO - 2024-12-10 02:07:44 --> Helper loaded: file_helper
INFO - 2024-12-10 02:07:44 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:07:44 --> Form Validation Class Initialized
INFO - 2024-12-10 02:07:44 --> Upload Class Initialized
INFO - 2024-12-10 02:07:44 --> Model "M_login" initialized
INFO - 2024-12-10 02:07:44 --> Model "M_home" initialized
INFO - 2024-12-10 02:07:44 --> Model "M_setting" initialized
INFO - 2024-12-10 02:07:44 --> Controller Class Initialized
INFO - 2024-12-10 02:07:44 --> Model "M_guru" initialized
INFO - 2024-12-10 02:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:07:44 --> Pagination Class Initialized
INFO - 2024-12-10 02:07:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:07:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:07:44 --> Final output sent to browser
DEBUG - 2024-12-10 02:07:44 --> Total execution time: 0.1101
INFO - 2024-12-10 02:07:54 --> Config Class Initialized
INFO - 2024-12-10 02:07:54 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:07:54 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:07:54 --> Utf8 Class Initialized
INFO - 2024-12-10 02:07:54 --> URI Class Initialized
INFO - 2024-12-10 02:07:54 --> Router Class Initialized
INFO - 2024-12-10 02:07:54 --> Output Class Initialized
INFO - 2024-12-10 02:07:54 --> Security Class Initialized
DEBUG - 2024-12-10 02:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:07:54 --> Input Class Initialized
INFO - 2024-12-10 02:07:54 --> Language Class Initialized
INFO - 2024-12-10 02:07:54 --> Loader Class Initialized
INFO - 2024-12-10 02:07:54 --> Helper loaded: url_helper
INFO - 2024-12-10 02:07:54 --> Helper loaded: form_helper
INFO - 2024-12-10 02:07:54 --> Helper loaded: file_helper
INFO - 2024-12-10 02:07:54 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:07:54 --> Form Validation Class Initialized
INFO - 2024-12-10 02:07:54 --> Upload Class Initialized
INFO - 2024-12-10 02:07:54 --> Model "M_login" initialized
INFO - 2024-12-10 02:07:54 --> Model "M_home" initialized
INFO - 2024-12-10 02:07:54 --> Model "M_setting" initialized
INFO - 2024-12-10 02:07:54 --> Controller Class Initialized
INFO - 2024-12-10 02:07:54 --> Model "M_guru" initialized
INFO - 2024-12-10 02:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:07:54 --> Pagination Class Initialized
INFO - 2024-12-10 02:07:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:07:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:07:54 --> Final output sent to browser
DEBUG - 2024-12-10 02:07:54 --> Total execution time: 0.1354
INFO - 2024-12-10 02:43:04 --> Config Class Initialized
INFO - 2024-12-10 02:43:04 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:04 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:04 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:04 --> URI Class Initialized
INFO - 2024-12-10 02:43:04 --> Router Class Initialized
INFO - 2024-12-10 02:43:04 --> Output Class Initialized
INFO - 2024-12-10 02:43:04 --> Security Class Initialized
DEBUG - 2024-12-10 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:04 --> Input Class Initialized
INFO - 2024-12-10 02:43:04 --> Language Class Initialized
INFO - 2024-12-10 02:43:04 --> Loader Class Initialized
INFO - 2024-12-10 02:43:04 --> Helper loaded: url_helper
INFO - 2024-12-10 02:43:04 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:04 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:04 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:04 --> Form Validation Class Initialized
INFO - 2024-12-10 02:43:04 --> Upload Class Initialized
INFO - 2024-12-10 02:43:04 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:04 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:04 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:04 --> Controller Class Initialized
INFO - 2024-12-10 02:43:04 --> Model "M_guru" initialized
INFO - 2024-12-10 02:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:43:04 --> Pagination Class Initialized
INFO - 2024-12-10 02:43:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:43:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:43:04 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:04 --> Total execution time: 0.2372
INFO - 2024-12-10 02:43:11 --> Config Class Initialized
INFO - 2024-12-10 02:43:11 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:11 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:11 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:11 --> URI Class Initialized
INFO - 2024-12-10 02:43:11 --> Router Class Initialized
INFO - 2024-12-10 02:43:11 --> Output Class Initialized
INFO - 2024-12-10 02:43:11 --> Security Class Initialized
DEBUG - 2024-12-10 02:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:11 --> Input Class Initialized
INFO - 2024-12-10 02:43:11 --> Language Class Initialized
INFO - 2024-12-10 02:43:11 --> Loader Class Initialized
INFO - 2024-12-10 02:43:11 --> Helper loaded: url_helper
INFO - 2024-12-10 02:43:11 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:11 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:11 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:11 --> Form Validation Class Initialized
INFO - 2024-12-10 02:43:11 --> Upload Class Initialized
INFO - 2024-12-10 02:43:11 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:11 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:11 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:11 --> Controller Class Initialized
INFO - 2024-12-10 02:43:11 --> Model "M_guru" initialized
INFO - 2024-12-10 02:43:11 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php
INFO - 2024-12-10 02:43:11 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:43:11 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:11 --> Total execution time: 0.1754
INFO - 2024-12-10 02:43:11 --> Config Class Initialized
INFO - 2024-12-10 02:43:11 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:11 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:11 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:11 --> URI Class Initialized
INFO - 2024-12-10 02:43:11 --> Config Class Initialized
INFO - 2024-12-10 02:43:11 --> Hooks Class Initialized
INFO - 2024-12-10 02:43:11 --> Router Class Initialized
DEBUG - 2024-12-10 02:43:11 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:11 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:11 --> Output Class Initialized
INFO - 2024-12-10 02:43:11 --> Security Class Initialized
INFO - 2024-12-10 02:43:11 --> URI Class Initialized
DEBUG - 2024-12-10 02:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:11 --> Input Class Initialized
INFO - 2024-12-10 02:43:11 --> Router Class Initialized
INFO - 2024-12-10 02:43:11 --> Language Class Initialized
INFO - 2024-12-10 02:43:11 --> Output Class Initialized
INFO - 2024-12-10 02:43:11 --> Loader Class Initialized
INFO - 2024-12-10 02:43:11 --> Security Class Initialized
INFO - 2024-12-10 02:43:11 --> Helper loaded: url_helper
DEBUG - 2024-12-10 02:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:11 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:11 --> Input Class Initialized
INFO - 2024-12-10 02:43:11 --> Language Class Initialized
INFO - 2024-12-10 02:43:11 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:11 --> Loader Class Initialized
INFO - 2024-12-10 02:43:12 --> Helper loaded: url_helper
INFO - 2024-12-10 02:43:12 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:12 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:12 --> Database Driver Class Initialized
INFO - 2024-12-10 02:43:12 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:12 --> Form Validation Class Initialized
DEBUG - 2024-12-10 02:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:12 --> Upload Class Initialized
INFO - 2024-12-10 02:43:12 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:12 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:12 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:12 --> Controller Class Initialized
INFO - 2024-12-10 02:43:12 --> Model "M_guru" initialized
ERROR - 2024-12-10 02:43:12 --> Severity: Warning --> Attempt to read property "judul_berita" on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php 28
ERROR - 2024-12-10 02:43:12 --> Severity: Warning --> Attempt to read property "tgl_berita" on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php 31
ERROR - 2024-12-10 02:43:12 --> Severity: Warning --> Attempt to read property "foto_berita" on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php 35
ERROR - 2024-12-10 02:43:12 --> Severity: Warning --> Attempt to read property "isi_berita" on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php 36
INFO - 2024-12-10 02:43:12 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php
INFO - 2024-12-10 02:43:12 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:43:12 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:12 --> Total execution time: 0.2470
INFO - 2024-12-10 02:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:12 --> Form Validation Class Initialized
INFO - 2024-12-10 02:43:12 --> Upload Class Initialized
INFO - 2024-12-10 02:43:12 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:12 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:12 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:12 --> Controller Class Initialized
INFO - 2024-12-10 02:43:12 --> Model "M_guru" initialized
ERROR - 2024-12-10 02:43:12 --> Severity: Warning --> Attempt to read property "judul_berita" on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php 28
ERROR - 2024-12-10 02:43:12 --> Severity: Warning --> Attempt to read property "tgl_berita" on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php 31
ERROR - 2024-12-10 02:43:12 --> Severity: Warning --> Attempt to read property "foto_berita" on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php 35
ERROR - 2024-12-10 02:43:12 --> Severity: Warning --> Attempt to read property "isi_berita" on null C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php 36
INFO - 2024-12-10 02:43:12 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_detail_berita.php
INFO - 2024-12-10 02:43:12 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:43:12 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:12 --> Total execution time: 0.2902
INFO - 2024-12-10 02:43:16 --> Config Class Initialized
INFO - 2024-12-10 02:43:16 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:16 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:16 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:16 --> URI Class Initialized
INFO - 2024-12-10 02:43:16 --> Router Class Initialized
INFO - 2024-12-10 02:43:16 --> Output Class Initialized
INFO - 2024-12-10 02:43:16 --> Security Class Initialized
DEBUG - 2024-12-10 02:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:17 --> Input Class Initialized
INFO - 2024-12-10 02:43:17 --> Language Class Initialized
INFO - 2024-12-10 02:43:17 --> Loader Class Initialized
INFO - 2024-12-10 02:43:17 --> Helper loaded: url_helper
INFO - 2024-12-10 02:43:17 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:17 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:17 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:17 --> Form Validation Class Initialized
INFO - 2024-12-10 02:43:17 --> Upload Class Initialized
INFO - 2024-12-10 02:43:17 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:17 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:17 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:17 --> Controller Class Initialized
INFO - 2024-12-10 02:43:17 --> Model "M_guru" initialized
INFO - 2024-12-10 02:43:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-10 02:43:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:43:17 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:17 --> Total execution time: 0.1040
INFO - 2024-12-10 02:43:23 --> Config Class Initialized
INFO - 2024-12-10 02:43:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:23 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:23 --> URI Class Initialized
INFO - 2024-12-10 02:43:23 --> Router Class Initialized
INFO - 2024-12-10 02:43:23 --> Output Class Initialized
INFO - 2024-12-10 02:43:23 --> Security Class Initialized
DEBUG - 2024-12-10 02:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:23 --> Input Class Initialized
INFO - 2024-12-10 02:43:23 --> Language Class Initialized
INFO - 2024-12-10 02:43:23 --> Loader Class Initialized
INFO - 2024-12-10 02:43:23 --> Helper loaded: url_helper
INFO - 2024-12-10 02:43:23 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:23 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:23 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:23 --> Form Validation Class Initialized
INFO - 2024-12-10 02:43:23 --> Upload Class Initialized
INFO - 2024-12-10 02:43:23 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:23 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:23 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:23 --> Controller Class Initialized
INFO - 2024-12-10 02:43:23 --> Model "M_guru" initialized
INFO - 2024-12-10 02:43:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-10 02:43:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:43:23 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:23 --> Total execution time: 0.1521
INFO - 2024-12-10 02:43:27 --> Config Class Initialized
INFO - 2024-12-10 02:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:27 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:27 --> URI Class Initialized
INFO - 2024-12-10 02:43:27 --> Router Class Initialized
INFO - 2024-12-10 02:43:27 --> Output Class Initialized
INFO - 2024-12-10 02:43:27 --> Security Class Initialized
DEBUG - 2024-12-10 02:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:27 --> Input Class Initialized
INFO - 2024-12-10 02:43:27 --> Language Class Initialized
INFO - 2024-12-10 02:43:27 --> Loader Class Initialized
INFO - 2024-12-10 02:43:27 --> Helper loaded: url_helper
INFO - 2024-12-10 02:43:27 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:27 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:27 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:27 --> Form Validation Class Initialized
INFO - 2024-12-10 02:43:27 --> Upload Class Initialized
INFO - 2024-12-10 02:43:27 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:27 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:27 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:27 --> Controller Class Initialized
INFO - 2024-12-10 02:43:27 --> Model "M_guru" initialized
INFO - 2024-12-10 02:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-10 02:43:27 --> Pagination Class Initialized
INFO - 2024-12-10 02:43:27 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-10 02:43:27 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:43:27 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:27 --> Total execution time: 0.1130
INFO - 2024-12-10 02:43:28 --> Config Class Initialized
INFO - 2024-12-10 02:43:28 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:28 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:28 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:28 --> URI Class Initialized
INFO - 2024-12-10 02:43:29 --> Router Class Initialized
INFO - 2024-12-10 02:43:29 --> Output Class Initialized
INFO - 2024-12-10 02:43:29 --> Security Class Initialized
DEBUG - 2024-12-10 02:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:29 --> Input Class Initialized
INFO - 2024-12-10 02:43:29 --> Language Class Initialized
INFO - 2024-12-10 02:43:29 --> Loader Class Initialized
INFO - 2024-12-10 02:43:29 --> Helper loaded: url_helper
INFO - 2024-12-10 02:43:29 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:29 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:29 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:29 --> Form Validation Class Initialized
INFO - 2024-12-10 02:43:29 --> Upload Class Initialized
INFO - 2024-12-10 02:43:29 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:29 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:29 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:29 --> Controller Class Initialized
INFO - 2024-12-10 02:43:29 --> Model "M_guru" initialized
INFO - 2024-12-10 02:43:29 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-10 02:43:29 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-10 02:43:29 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:29 --> Total execution time: 0.1004
INFO - 2024-12-10 02:43:29 --> Config Class Initialized
INFO - 2024-12-10 02:43:29 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:29 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:29 --> URI Class Initialized
INFO - 2024-12-10 02:43:29 --> Router Class Initialized
INFO - 2024-12-10 02:43:29 --> Output Class Initialized
INFO - 2024-12-10 02:43:29 --> Security Class Initialized
DEBUG - 2024-12-10 02:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:29 --> Input Class Initialized
INFO - 2024-12-10 02:43:29 --> Language Class Initialized
ERROR - 2024-12-10 02:43:29 --> 404 Page Not Found: Home/images
INFO - 2024-12-10 02:43:47 --> Config Class Initialized
INFO - 2024-12-10 02:43:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 02:43:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 02:43:47 --> Utf8 Class Initialized
INFO - 2024-12-10 02:43:47 --> URI Class Initialized
INFO - 2024-12-10 02:43:47 --> Router Class Initialized
INFO - 2024-12-10 02:43:47 --> Output Class Initialized
INFO - 2024-12-10 02:43:47 --> Security Class Initialized
DEBUG - 2024-12-10 02:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 02:43:47 --> Input Class Initialized
INFO - 2024-12-10 02:43:47 --> Language Class Initialized
INFO - 2024-12-10 02:43:47 --> Loader Class Initialized
INFO - 2024-12-10 02:43:47 --> Helper loaded: url_helper
INFO - 2024-12-10 02:43:47 --> Helper loaded: form_helper
INFO - 2024-12-10 02:43:47 --> Helper loaded: file_helper
INFO - 2024-12-10 02:43:47 --> Database Driver Class Initialized
DEBUG - 2024-12-10 02:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 02:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 02:43:47 --> Form Validation Class Initialized
INFO - 2024-12-10 02:43:47 --> Upload Class Initialized
INFO - 2024-12-10 02:43:47 --> Model "M_login" initialized
INFO - 2024-12-10 02:43:47 --> Model "M_home" initialized
INFO - 2024-12-10 02:43:47 --> Model "M_setting" initialized
INFO - 2024-12-10 02:43:47 --> Controller Class Initialized
INFO - 2024-12-10 02:43:47 --> Model "M_berita" initialized
INFO - 2024-12-10 02:43:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-10 02:43:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-10 02:43:47 --> Final output sent to browser
DEBUG - 2024-12-10 02:43:47 --> Total execution time: 0.2911
