<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-19 06:49:24 --> Config Class Initialized
INFO - 2024-12-19 06:49:24 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:49:25 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:49:25 --> Utf8 Class Initialized
INFO - 2024-12-19 06:49:25 --> URI Class Initialized
DEBUG - 2024-12-19 06:49:25 --> No URI present. Default controller set.
INFO - 2024-12-19 06:49:25 --> Router Class Initialized
INFO - 2024-12-19 06:49:25 --> Output Class Initialized
INFO - 2024-12-19 06:49:25 --> Security Class Initialized
DEBUG - 2024-12-19 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:49:25 --> Input Class Initialized
INFO - 2024-12-19 06:49:25 --> Language Class Initialized
INFO - 2024-12-19 06:49:26 --> Loader Class Initialized
INFO - 2024-12-19 06:49:26 --> Helper loaded: url_helper
INFO - 2024-12-19 06:49:26 --> Helper loaded: form_helper
INFO - 2024-12-19 06:49:26 --> Helper loaded: file_helper
INFO - 2024-12-19 06:49:26 --> Database Driver Class Initialized
DEBUG - 2024-12-19 06:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 06:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 06:49:27 --> Form Validation Class Initialized
INFO - 2024-12-19 06:49:27 --> Upload Class Initialized
INFO - 2024-12-19 06:49:28 --> Model "M_login" initialized
INFO - 2024-12-19 06:49:28 --> Model "M_home" initialized
INFO - 2024-12-19 06:49:28 --> Model "M_setting" initialized
INFO - 2024-12-19 06:49:28 --> Controller Class Initialized
INFO - 2024-12-19 06:49:28 --> Model "M_guru" initialized
INFO - 2024-12-19 06:49:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 06:49:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 06:49:28 --> Final output sent to browser
DEBUG - 2024-12-19 06:49:28 --> Total execution time: 4.3116
INFO - 2024-12-19 06:49:33 --> Config Class Initialized
INFO - 2024-12-19 06:49:33 --> Hooks Class Initialized
INFO - 2024-12-19 06:49:33 --> Config Class Initialized
INFO - 2024-12-19 06:49:33 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:49:33 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:49:33 --> Utf8 Class Initialized
DEBUG - 2024-12-19 06:49:33 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:49:33 --> Utf8 Class Initialized
INFO - 2024-12-19 06:49:33 --> URI Class Initialized
INFO - 2024-12-19 06:49:33 --> Router Class Initialized
INFO - 2024-12-19 06:49:33 --> Output Class Initialized
INFO - 2024-12-19 06:49:33 --> Security Class Initialized
DEBUG - 2024-12-19 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:49:33 --> Input Class Initialized
INFO - 2024-12-19 06:49:33 --> Language Class Initialized
INFO - 2024-12-19 06:49:33 --> URI Class Initialized
INFO - 2024-12-19 06:49:33 --> Config Class Initialized
INFO - 2024-12-19 06:49:33 --> Hooks Class Initialized
INFO - 2024-12-19 06:49:33 --> Router Class Initialized
DEBUG - 2024-12-19 06:49:33 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:49:33 --> Output Class Initialized
INFO - 2024-12-19 06:49:33 --> Utf8 Class Initialized
INFO - 2024-12-19 06:49:33 --> Security Class Initialized
INFO - 2024-12-19 06:49:33 --> URI Class Initialized
DEBUG - 2024-12-19 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:49:33 --> Input Class Initialized
INFO - 2024-12-19 06:49:33 --> Router Class Initialized
INFO - 2024-12-19 06:49:33 --> Language Class Initialized
ERROR - 2024-12-19 06:49:33 --> 404 Page Not Found: Images/team_background.jpg
ERROR - 2024-12-19 06:49:33 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 06:49:33 --> Output Class Initialized
INFO - 2024-12-19 06:49:33 --> Security Class Initialized
DEBUG - 2024-12-19 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:49:33 --> Input Class Initialized
INFO - 2024-12-19 06:49:33 --> Language Class Initialized
ERROR - 2024-12-19 06:49:33 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 06:56:29 --> Config Class Initialized
INFO - 2024-12-19 06:56:29 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:56:29 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:56:29 --> Utf8 Class Initialized
INFO - 2024-12-19 06:56:30 --> URI Class Initialized
INFO - 2024-12-19 06:56:30 --> Router Class Initialized
INFO - 2024-12-19 06:56:30 --> Output Class Initialized
INFO - 2024-12-19 06:56:30 --> Security Class Initialized
DEBUG - 2024-12-19 06:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:56:30 --> Input Class Initialized
INFO - 2024-12-19 06:56:30 --> Language Class Initialized
INFO - 2024-12-19 06:56:31 --> Loader Class Initialized
INFO - 2024-12-19 06:56:31 --> Helper loaded: url_helper
INFO - 2024-12-19 06:56:31 --> Helper loaded: form_helper
INFO - 2024-12-19 06:56:31 --> Helper loaded: file_helper
INFO - 2024-12-19 06:56:31 --> Database Driver Class Initialized
DEBUG - 2024-12-19 06:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 06:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 06:56:32 --> Form Validation Class Initialized
INFO - 2024-12-19 06:56:32 --> Upload Class Initialized
INFO - 2024-12-19 06:56:32 --> Model "M_login" initialized
INFO - 2024-12-19 06:56:32 --> Model "M_home" initialized
INFO - 2024-12-19 06:56:32 --> Model "M_setting" initialized
INFO - 2024-12-19 06:56:32 --> Controller Class Initialized
INFO - 2024-12-19 06:56:32 --> Model "M_guru" initialized
INFO - 2024-12-19 06:56:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 06:56:32 --> Pagination Class Initialized
INFO - 2024-12-19 06:56:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 06:56:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 06:56:33 --> Final output sent to browser
DEBUG - 2024-12-19 06:56:33 --> Total execution time: 4.1556
INFO - 2024-12-19 06:57:00 --> Config Class Initialized
INFO - 2024-12-19 06:57:00 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:57:00 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:57:00 --> Utf8 Class Initialized
INFO - 2024-12-19 06:57:00 --> URI Class Initialized
INFO - 2024-12-19 06:57:00 --> Router Class Initialized
INFO - 2024-12-19 06:57:00 --> Output Class Initialized
INFO - 2024-12-19 06:57:00 --> Security Class Initialized
DEBUG - 2024-12-19 06:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:57:00 --> Input Class Initialized
INFO - 2024-12-19 06:57:00 --> Language Class Initialized
INFO - 2024-12-19 06:57:00 --> Loader Class Initialized
INFO - 2024-12-19 06:57:00 --> Helper loaded: url_helper
INFO - 2024-12-19 06:57:00 --> Helper loaded: form_helper
INFO - 2024-12-19 06:57:00 --> Helper loaded: file_helper
INFO - 2024-12-19 06:57:00 --> Database Driver Class Initialized
DEBUG - 2024-12-19 06:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 06:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 06:57:00 --> Form Validation Class Initialized
INFO - 2024-12-19 06:57:00 --> Upload Class Initialized
INFO - 2024-12-19 06:57:00 --> Model "M_login" initialized
INFO - 2024-12-19 06:57:00 --> Model "M_home" initialized
INFO - 2024-12-19 06:57:00 --> Model "M_setting" initialized
INFO - 2024-12-19 06:57:00 --> Controller Class Initialized
INFO - 2024-12-19 06:57:00 --> Model "M_guru" initialized
INFO - 2024-12-19 06:57:00 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-19 06:57:00 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 06:57:00 --> Final output sent to browser
DEBUG - 2024-12-19 06:57:00 --> Total execution time: 0.1525
INFO - 2024-12-19 06:57:50 --> Config Class Initialized
INFO - 2024-12-19 06:57:50 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:57:50 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:57:50 --> Utf8 Class Initialized
INFO - 2024-12-19 06:57:50 --> URI Class Initialized
INFO - 2024-12-19 06:57:50 --> Router Class Initialized
INFO - 2024-12-19 06:57:50 --> Output Class Initialized
INFO - 2024-12-19 06:57:50 --> Security Class Initialized
DEBUG - 2024-12-19 06:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:57:50 --> Input Class Initialized
INFO - 2024-12-19 06:57:50 --> Language Class Initialized
INFO - 2024-12-19 06:57:50 --> Loader Class Initialized
INFO - 2024-12-19 06:57:50 --> Helper loaded: url_helper
INFO - 2024-12-19 06:57:50 --> Helper loaded: form_helper
INFO - 2024-12-19 06:57:50 --> Helper loaded: file_helper
INFO - 2024-12-19 06:57:50 --> Database Driver Class Initialized
DEBUG - 2024-12-19 06:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 06:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 06:57:50 --> Form Validation Class Initialized
INFO - 2024-12-19 06:57:50 --> Upload Class Initialized
INFO - 2024-12-19 06:57:50 --> Model "M_login" initialized
INFO - 2024-12-19 06:57:50 --> Model "M_home" initialized
INFO - 2024-12-19 06:57:50 --> Model "M_setting" initialized
INFO - 2024-12-19 06:57:50 --> Controller Class Initialized
INFO - 2024-12-19 06:57:50 --> Model "M_guru" initialized
INFO - 2024-12-19 06:57:50 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-19 06:57:50 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 06:57:50 --> Final output sent to browser
DEBUG - 2024-12-19 06:57:50 --> Total execution time: 0.1303
INFO - 2024-12-19 06:58:07 --> Config Class Initialized
INFO - 2024-12-19 06:58:07 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:58:07 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:58:07 --> Utf8 Class Initialized
INFO - 2024-12-19 06:58:07 --> URI Class Initialized
INFO - 2024-12-19 06:58:07 --> Router Class Initialized
INFO - 2024-12-19 06:58:07 --> Output Class Initialized
INFO - 2024-12-19 06:58:07 --> Security Class Initialized
DEBUG - 2024-12-19 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:58:07 --> Input Class Initialized
INFO - 2024-12-19 06:58:07 --> Language Class Initialized
INFO - 2024-12-19 06:58:07 --> Loader Class Initialized
INFO - 2024-12-19 06:58:07 --> Helper loaded: url_helper
INFO - 2024-12-19 06:58:07 --> Helper loaded: form_helper
INFO - 2024-12-19 06:58:07 --> Helper loaded: file_helper
INFO - 2024-12-19 06:58:07 --> Database Driver Class Initialized
DEBUG - 2024-12-19 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 06:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 06:58:07 --> Form Validation Class Initialized
INFO - 2024-12-19 06:58:07 --> Upload Class Initialized
INFO - 2024-12-19 06:58:07 --> Model "M_login" initialized
INFO - 2024-12-19 06:58:07 --> Model "M_home" initialized
INFO - 2024-12-19 06:58:07 --> Model "M_setting" initialized
INFO - 2024-12-19 06:58:07 --> Controller Class Initialized
INFO - 2024-12-19 06:58:07 --> Model "M_guru" initialized
INFO - 2024-12-19 06:58:07 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 06:58:07 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 06:58:07 --> Final output sent to browser
DEBUG - 2024-12-19 06:58:07 --> Total execution time: 0.1837
INFO - 2024-12-19 06:58:33 --> Config Class Initialized
INFO - 2024-12-19 06:58:33 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:58:33 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:58:33 --> Utf8 Class Initialized
INFO - 2024-12-19 06:58:33 --> URI Class Initialized
INFO - 2024-12-19 06:58:33 --> Router Class Initialized
INFO - 2024-12-19 06:58:33 --> Output Class Initialized
INFO - 2024-12-19 06:58:33 --> Security Class Initialized
DEBUG - 2024-12-19 06:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:58:33 --> Input Class Initialized
INFO - 2024-12-19 06:58:33 --> Language Class Initialized
INFO - 2024-12-19 06:58:33 --> Loader Class Initialized
INFO - 2024-12-19 06:58:33 --> Helper loaded: url_helper
INFO - 2024-12-19 06:58:33 --> Helper loaded: form_helper
INFO - 2024-12-19 06:58:33 --> Helper loaded: file_helper
INFO - 2024-12-19 06:58:33 --> Database Driver Class Initialized
DEBUG - 2024-12-19 06:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 06:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 06:58:33 --> Form Validation Class Initialized
INFO - 2024-12-19 06:58:33 --> Upload Class Initialized
INFO - 2024-12-19 06:58:33 --> Model "M_login" initialized
INFO - 2024-12-19 06:58:33 --> Model "M_home" initialized
INFO - 2024-12-19 06:58:33 --> Model "M_setting" initialized
INFO - 2024-12-19 06:58:33 --> Controller Class Initialized
INFO - 2024-12-19 06:58:33 --> Model "M_guru" initialized
INFO - 2024-12-19 06:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 06:58:33 --> Pagination Class Initialized
INFO - 2024-12-19 06:58:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 06:58:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 06:58:33 --> Final output sent to browser
DEBUG - 2024-12-19 06:58:33 --> Total execution time: 0.0992
INFO - 2024-12-19 06:59:09 --> Config Class Initialized
INFO - 2024-12-19 06:59:09 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:59:09 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:59:09 --> Utf8 Class Initialized
INFO - 2024-12-19 06:59:09 --> URI Class Initialized
INFO - 2024-12-19 06:59:09 --> Router Class Initialized
INFO - 2024-12-19 06:59:09 --> Output Class Initialized
INFO - 2024-12-19 06:59:09 --> Security Class Initialized
DEBUG - 2024-12-19 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:59:09 --> Input Class Initialized
INFO - 2024-12-19 06:59:09 --> Language Class Initialized
INFO - 2024-12-19 06:59:09 --> Loader Class Initialized
INFO - 2024-12-19 06:59:09 --> Helper loaded: url_helper
INFO - 2024-12-19 06:59:09 --> Helper loaded: form_helper
INFO - 2024-12-19 06:59:09 --> Helper loaded: file_helper
INFO - 2024-12-19 06:59:09 --> Database Driver Class Initialized
DEBUG - 2024-12-19 06:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 06:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 06:59:09 --> Form Validation Class Initialized
INFO - 2024-12-19 06:59:09 --> Upload Class Initialized
INFO - 2024-12-19 06:59:09 --> Model "M_login" initialized
INFO - 2024-12-19 06:59:09 --> Model "M_home" initialized
INFO - 2024-12-19 06:59:09 --> Model "M_setting" initialized
INFO - 2024-12-19 06:59:09 --> Controller Class Initialized
INFO - 2024-12-19 06:59:09 --> Model "M_guru" initialized
INFO - 2024-12-19 06:59:09 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 06:59:09 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 06:59:09 --> Final output sent to browser
DEBUG - 2024-12-19 06:59:09 --> Total execution time: 0.2176
INFO - 2024-12-19 06:59:10 --> Config Class Initialized
INFO - 2024-12-19 06:59:10 --> Hooks Class Initialized
DEBUG - 2024-12-19 06:59:10 --> UTF-8 Support Enabled
INFO - 2024-12-19 06:59:10 --> Utf8 Class Initialized
INFO - 2024-12-19 06:59:10 --> URI Class Initialized
INFO - 2024-12-19 06:59:10 --> Router Class Initialized
INFO - 2024-12-19 06:59:10 --> Output Class Initialized
INFO - 2024-12-19 06:59:10 --> Security Class Initialized
DEBUG - 2024-12-19 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 06:59:10 --> Input Class Initialized
INFO - 2024-12-19 06:59:10 --> Language Class Initialized
ERROR - 2024-12-19 06:59:10 --> 404 Page Not Found: Home/images
INFO - 2024-12-19 07:00:13 --> Config Class Initialized
INFO - 2024-12-19 07:00:13 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:00:13 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:13 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:13 --> URI Class Initialized
INFO - 2024-12-19 07:00:13 --> Router Class Initialized
INFO - 2024-12-19 07:00:13 --> Output Class Initialized
INFO - 2024-12-19 07:00:13 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:13 --> Input Class Initialized
INFO - 2024-12-19 07:00:13 --> Language Class Initialized
INFO - 2024-12-19 07:00:13 --> Loader Class Initialized
INFO - 2024-12-19 07:00:13 --> Helper loaded: url_helper
INFO - 2024-12-19 07:00:13 --> Helper loaded: form_helper
INFO - 2024-12-19 07:00:13 --> Helper loaded: file_helper
INFO - 2024-12-19 07:00:13 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:00:13 --> Form Validation Class Initialized
INFO - 2024-12-19 07:00:13 --> Upload Class Initialized
INFO - 2024-12-19 07:00:13 --> Model "M_login" initialized
INFO - 2024-12-19 07:00:13 --> Model "M_home" initialized
INFO - 2024-12-19 07:00:13 --> Model "M_setting" initialized
INFO - 2024-12-19 07:00:13 --> Controller Class Initialized
INFO - 2024-12-19 07:00:13 --> Model "M_guru" initialized
INFO - 2024-12-19 07:00:13 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 07:00:13 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 07:00:13 --> Final output sent to browser
DEBUG - 2024-12-19 07:00:13 --> Total execution time: 0.4600
INFO - 2024-12-19 07:00:13 --> Config Class Initialized
INFO - 2024-12-19 07:00:13 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:00:13 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:13 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:13 --> URI Class Initialized
INFO - 2024-12-19 07:00:13 --> Router Class Initialized
INFO - 2024-12-19 07:00:13 --> Output Class Initialized
INFO - 2024-12-19 07:00:13 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:13 --> Input Class Initialized
INFO - 2024-12-19 07:00:13 --> Language Class Initialized
INFO - 2024-12-19 07:00:13 --> Loader Class Initialized
INFO - 2024-12-19 07:00:13 --> Helper loaded: url_helper
INFO - 2024-12-19 07:00:13 --> Helper loaded: form_helper
INFO - 2024-12-19 07:00:14 --> Helper loaded: file_helper
INFO - 2024-12-19 07:00:14 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:00:14 --> Form Validation Class Initialized
INFO - 2024-12-19 07:00:14 --> Upload Class Initialized
INFO - 2024-12-19 07:00:14 --> Model "M_login" initialized
INFO - 2024-12-19 07:00:14 --> Model "M_home" initialized
INFO - 2024-12-19 07:00:14 --> Model "M_setting" initialized
INFO - 2024-12-19 07:00:14 --> Controller Class Initialized
INFO - 2024-12-19 07:00:14 --> Model "M_guru" initialized
INFO - 2024-12-19 07:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 07:00:14 --> Pagination Class Initialized
INFO - 2024-12-19 07:00:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 07:00:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 07:00:14 --> Final output sent to browser
DEBUG - 2024-12-19 07:00:14 --> Total execution time: 0.2729
INFO - 2024-12-19 07:00:21 --> Config Class Initialized
INFO - 2024-12-19 07:00:21 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:00:21 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:21 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:21 --> URI Class Initialized
DEBUG - 2024-12-19 07:00:21 --> No URI present. Default controller set.
INFO - 2024-12-19 07:00:21 --> Router Class Initialized
INFO - 2024-12-19 07:00:21 --> Output Class Initialized
INFO - 2024-12-19 07:00:21 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:21 --> Input Class Initialized
INFO - 2024-12-19 07:00:21 --> Language Class Initialized
INFO - 2024-12-19 07:00:21 --> Loader Class Initialized
INFO - 2024-12-19 07:00:21 --> Helper loaded: url_helper
INFO - 2024-12-19 07:00:21 --> Helper loaded: form_helper
INFO - 2024-12-19 07:00:21 --> Helper loaded: file_helper
INFO - 2024-12-19 07:00:21 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:00:21 --> Form Validation Class Initialized
INFO - 2024-12-19 07:00:21 --> Upload Class Initialized
INFO - 2024-12-19 07:00:21 --> Model "M_login" initialized
INFO - 2024-12-19 07:00:21 --> Model "M_home" initialized
INFO - 2024-12-19 07:00:21 --> Model "M_setting" initialized
INFO - 2024-12-19 07:00:21 --> Controller Class Initialized
INFO - 2024-12-19 07:00:21 --> Model "M_guru" initialized
INFO - 2024-12-19 07:00:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 07:00:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 07:00:21 --> Final output sent to browser
DEBUG - 2024-12-19 07:00:21 --> Total execution time: 0.3223
INFO - 2024-12-19 07:00:21 --> Config Class Initialized
INFO - 2024-12-19 07:00:21 --> Hooks Class Initialized
INFO - 2024-12-19 07:00:21 --> Config Class Initialized
INFO - 2024-12-19 07:00:21 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:00:21 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:21 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:21 --> URI Class Initialized
DEBUG - 2024-12-19 07:00:21 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:21 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:21 --> URI Class Initialized
INFO - 2024-12-19 07:00:21 --> Router Class Initialized
INFO - 2024-12-19 07:00:21 --> Output Class Initialized
INFO - 2024-12-19 07:00:22 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:22 --> Input Class Initialized
INFO - 2024-12-19 07:00:22 --> Language Class Initialized
ERROR - 2024-12-19 07:00:22 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 07:00:22 --> Router Class Initialized
INFO - 2024-12-19 07:00:22 --> Output Class Initialized
INFO - 2024-12-19 07:00:22 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:22 --> Input Class Initialized
INFO - 2024-12-19 07:00:22 --> Config Class Initialized
INFO - 2024-12-19 07:00:22 --> Hooks Class Initialized
INFO - 2024-12-19 07:00:22 --> Language Class Initialized
ERROR - 2024-12-19 07:00:22 --> 404 Page Not Found: Images/courses_background.jpg
DEBUG - 2024-12-19 07:00:22 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:22 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:22 --> URI Class Initialized
INFO - 2024-12-19 07:00:22 --> Router Class Initialized
INFO - 2024-12-19 07:00:22 --> Output Class Initialized
INFO - 2024-12-19 07:00:22 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:22 --> Input Class Initialized
INFO - 2024-12-19 07:00:22 --> Language Class Initialized
ERROR - 2024-12-19 07:00:22 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 07:00:33 --> Config Class Initialized
INFO - 2024-12-19 07:00:33 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:00:33 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:33 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:33 --> URI Class Initialized
INFO - 2024-12-19 07:00:33 --> Router Class Initialized
INFO - 2024-12-19 07:00:33 --> Output Class Initialized
INFO - 2024-12-19 07:00:33 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:33 --> Input Class Initialized
INFO - 2024-12-19 07:00:33 --> Language Class Initialized
INFO - 2024-12-19 07:00:33 --> Loader Class Initialized
INFO - 2024-12-19 07:00:33 --> Helper loaded: url_helper
INFO - 2024-12-19 07:00:33 --> Helper loaded: form_helper
INFO - 2024-12-19 07:00:33 --> Helper loaded: file_helper
INFO - 2024-12-19 07:00:33 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:00:33 --> Form Validation Class Initialized
INFO - 2024-12-19 07:00:33 --> Upload Class Initialized
INFO - 2024-12-19 07:00:33 --> Model "M_login" initialized
INFO - 2024-12-19 07:00:33 --> Model "M_home" initialized
INFO - 2024-12-19 07:00:33 --> Model "M_setting" initialized
INFO - 2024-12-19 07:00:33 --> Controller Class Initialized
INFO - 2024-12-19 07:00:33 --> Config Class Initialized
INFO - 2024-12-19 07:00:33 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:00:34 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:34 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:34 --> URI Class Initialized
INFO - 2024-12-19 07:00:34 --> Router Class Initialized
INFO - 2024-12-19 07:00:34 --> Output Class Initialized
INFO - 2024-12-19 07:00:34 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:34 --> Input Class Initialized
INFO - 2024-12-19 07:00:34 --> Language Class Initialized
INFO - 2024-12-19 07:00:34 --> Loader Class Initialized
INFO - 2024-12-19 07:00:34 --> Helper loaded: url_helper
INFO - 2024-12-19 07:00:34 --> Helper loaded: form_helper
INFO - 2024-12-19 07:00:34 --> Helper loaded: file_helper
INFO - 2024-12-19 07:00:34 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:00:34 --> Form Validation Class Initialized
INFO - 2024-12-19 07:00:34 --> Upload Class Initialized
INFO - 2024-12-19 07:00:34 --> Model "M_login" initialized
INFO - 2024-12-19 07:00:34 --> Model "M_home" initialized
INFO - 2024-12-19 07:00:34 --> Model "M_setting" initialized
INFO - 2024-12-19 07:00:34 --> Controller Class Initialized
INFO - 2024-12-19 07:00:34 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_login.php
INFO - 2024-12-19 07:00:34 --> Final output sent to browser
DEBUG - 2024-12-19 07:00:34 --> Total execution time: 0.1616
INFO - 2024-12-19 07:00:41 --> Config Class Initialized
INFO - 2024-12-19 07:00:41 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:00:41 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:41 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:41 --> URI Class Initialized
INFO - 2024-12-19 07:00:41 --> Router Class Initialized
INFO - 2024-12-19 07:00:41 --> Output Class Initialized
INFO - 2024-12-19 07:00:41 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:41 --> Input Class Initialized
INFO - 2024-12-19 07:00:41 --> Language Class Initialized
INFO - 2024-12-19 07:00:41 --> Loader Class Initialized
INFO - 2024-12-19 07:00:41 --> Helper loaded: url_helper
INFO - 2024-12-19 07:00:41 --> Helper loaded: form_helper
INFO - 2024-12-19 07:00:41 --> Helper loaded: file_helper
INFO - 2024-12-19 07:00:41 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:00:41 --> Form Validation Class Initialized
INFO - 2024-12-19 07:00:41 --> Upload Class Initialized
INFO - 2024-12-19 07:00:41 --> Model "M_login" initialized
INFO - 2024-12-19 07:00:41 --> Model "M_home" initialized
INFO - 2024-12-19 07:00:41 --> Model "M_setting" initialized
INFO - 2024-12-19 07:00:41 --> Controller Class Initialized
INFO - 2024-12-19 07:00:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-19 07:00:41 --> Config Class Initialized
INFO - 2024-12-19 07:00:41 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:00:41 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:00:41 --> Utf8 Class Initialized
INFO - 2024-12-19 07:00:41 --> URI Class Initialized
INFO - 2024-12-19 07:00:41 --> Router Class Initialized
INFO - 2024-12-19 07:00:41 --> Output Class Initialized
INFO - 2024-12-19 07:00:41 --> Security Class Initialized
DEBUG - 2024-12-19 07:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:00:41 --> Input Class Initialized
INFO - 2024-12-19 07:00:41 --> Language Class Initialized
INFO - 2024-12-19 07:00:41 --> Loader Class Initialized
INFO - 2024-12-19 07:00:41 --> Helper loaded: url_helper
INFO - 2024-12-19 07:00:41 --> Helper loaded: form_helper
INFO - 2024-12-19 07:00:41 --> Helper loaded: file_helper
INFO - 2024-12-19 07:00:41 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:00:41 --> Form Validation Class Initialized
INFO - 2024-12-19 07:00:41 --> Upload Class Initialized
INFO - 2024-12-19 07:00:41 --> Model "M_login" initialized
INFO - 2024-12-19 07:00:41 --> Model "M_home" initialized
INFO - 2024-12-19 07:00:41 --> Model "M_setting" initialized
INFO - 2024-12-19 07:00:41 --> Controller Class Initialized
INFO - 2024-12-19 07:00:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\Admin/v_dashboard.php
INFO - 2024-12-19 07:00:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-19 07:00:41 --> Final output sent to browser
DEBUG - 2024-12-19 07:00:41 --> Total execution time: 0.3211
INFO - 2024-12-19 07:01:22 --> Config Class Initialized
INFO - 2024-12-19 07:01:22 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:01:22 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:01:22 --> Utf8 Class Initialized
INFO - 2024-12-19 07:01:22 --> URI Class Initialized
INFO - 2024-12-19 07:01:22 --> Router Class Initialized
INFO - 2024-12-19 07:01:22 --> Output Class Initialized
INFO - 2024-12-19 07:01:22 --> Security Class Initialized
DEBUG - 2024-12-19 07:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:01:22 --> Input Class Initialized
INFO - 2024-12-19 07:01:22 --> Language Class Initialized
INFO - 2024-12-19 07:01:22 --> Loader Class Initialized
INFO - 2024-12-19 07:01:22 --> Helper loaded: url_helper
INFO - 2024-12-19 07:01:22 --> Helper loaded: form_helper
INFO - 2024-12-19 07:01:22 --> Helper loaded: file_helper
INFO - 2024-12-19 07:01:22 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:01:22 --> Form Validation Class Initialized
INFO - 2024-12-19 07:01:22 --> Upload Class Initialized
INFO - 2024-12-19 07:01:22 --> Model "M_login" initialized
INFO - 2024-12-19 07:01:22 --> Model "M_home" initialized
INFO - 2024-12-19 07:01:22 --> Model "M_setting" initialized
INFO - 2024-12-19 07:01:22 --> Controller Class Initialized
INFO - 2024-12-19 07:01:22 --> Model "M_guru" initialized
INFO - 2024-12-19 07:01:22 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-19 07:01:22 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-19 07:01:23 --> Final output sent to browser
DEBUG - 2024-12-19 07:01:23 --> Total execution time: 0.2887
INFO - 2024-12-19 07:01:55 --> Config Class Initialized
INFO - 2024-12-19 07:01:55 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:01:55 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:01:55 --> Utf8 Class Initialized
INFO - 2024-12-19 07:01:55 --> URI Class Initialized
INFO - 2024-12-19 07:01:55 --> Router Class Initialized
INFO - 2024-12-19 07:01:55 --> Output Class Initialized
INFO - 2024-12-19 07:01:55 --> Security Class Initialized
DEBUG - 2024-12-19 07:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:01:55 --> Input Class Initialized
INFO - 2024-12-19 07:01:55 --> Language Class Initialized
INFO - 2024-12-19 07:01:55 --> Loader Class Initialized
INFO - 2024-12-19 07:01:55 --> Helper loaded: url_helper
INFO - 2024-12-19 07:01:55 --> Helper loaded: form_helper
INFO - 2024-12-19 07:01:55 --> Helper loaded: file_helper
INFO - 2024-12-19 07:01:55 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:01:55 --> Form Validation Class Initialized
INFO - 2024-12-19 07:01:55 --> Upload Class Initialized
INFO - 2024-12-19 07:01:55 --> Model "M_login" initialized
INFO - 2024-12-19 07:01:55 --> Model "M_home" initialized
INFO - 2024-12-19 07:01:55 --> Model "M_setting" initialized
INFO - 2024-12-19 07:01:55 --> Controller Class Initialized
INFO - 2024-12-19 07:01:55 --> Model "M_guru" initialized
INFO - 2024-12-19 07:01:55 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_add.php
INFO - 2024-12-19 07:01:55 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-19 07:01:55 --> Final output sent to browser
DEBUG - 2024-12-19 07:01:55 --> Total execution time: 0.2049
INFO - 2024-12-19 07:02:11 --> Config Class Initialized
INFO - 2024-12-19 07:02:11 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:02:11 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:02:11 --> Utf8 Class Initialized
INFO - 2024-12-19 07:02:11 --> URI Class Initialized
INFO - 2024-12-19 07:02:11 --> Router Class Initialized
INFO - 2024-12-19 07:02:11 --> Output Class Initialized
INFO - 2024-12-19 07:02:11 --> Security Class Initialized
DEBUG - 2024-12-19 07:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:02:11 --> Input Class Initialized
INFO - 2024-12-19 07:02:11 --> Language Class Initialized
INFO - 2024-12-19 07:02:11 --> Loader Class Initialized
INFO - 2024-12-19 07:02:11 --> Helper loaded: url_helper
INFO - 2024-12-19 07:02:11 --> Helper loaded: form_helper
INFO - 2024-12-19 07:02:11 --> Helper loaded: file_helper
INFO - 2024-12-19 07:02:11 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:02:11 --> Form Validation Class Initialized
INFO - 2024-12-19 07:02:11 --> Upload Class Initialized
INFO - 2024-12-19 07:02:11 --> Model "M_login" initialized
INFO - 2024-12-19 07:02:11 --> Model "M_home" initialized
INFO - 2024-12-19 07:02:11 --> Model "M_setting" initialized
INFO - 2024-12-19 07:02:11 --> Controller Class Initialized
INFO - 2024-12-19 07:02:11 --> Model "M_guru" initialized
INFO - 2024-12-19 07:02:11 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-19 07:02:11 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-19 07:02:11 --> Final output sent to browser
DEBUG - 2024-12-19 07:02:11 --> Total execution time: 0.1171
INFO - 2024-12-19 07:02:31 --> Config Class Initialized
INFO - 2024-12-19 07:02:31 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:02:31 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:02:31 --> Utf8 Class Initialized
INFO - 2024-12-19 07:02:31 --> URI Class Initialized
INFO - 2024-12-19 07:02:31 --> Router Class Initialized
INFO - 2024-12-19 07:02:31 --> Output Class Initialized
INFO - 2024-12-19 07:02:31 --> Security Class Initialized
DEBUG - 2024-12-19 07:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:02:31 --> Input Class Initialized
INFO - 2024-12-19 07:02:31 --> Language Class Initialized
INFO - 2024-12-19 07:02:31 --> Loader Class Initialized
INFO - 2024-12-19 07:02:31 --> Helper loaded: url_helper
INFO - 2024-12-19 07:02:31 --> Helper loaded: form_helper
INFO - 2024-12-19 07:02:31 --> Helper loaded: file_helper
INFO - 2024-12-19 07:02:31 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:02:31 --> Form Validation Class Initialized
INFO - 2024-12-19 07:02:31 --> Upload Class Initialized
INFO - 2024-12-19 07:02:31 --> Model "M_login" initialized
INFO - 2024-12-19 07:02:31 --> Model "M_home" initialized
INFO - 2024-12-19 07:02:31 --> Model "M_setting" initialized
INFO - 2024-12-19 07:02:31 --> Controller Class Initialized
INFO - 2024-12-19 07:02:31 --> Model "M_berita" initialized
INFO - 2024-12-19 07:02:31 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-19 07:02:31 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-19 07:02:31 --> Final output sent to browser
DEBUG - 2024-12-19 07:02:31 --> Total execution time: 0.2953
INFO - 2024-12-19 07:03:03 --> Config Class Initialized
INFO - 2024-12-19 07:03:03 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:03:03 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:03:03 --> Utf8 Class Initialized
INFO - 2024-12-19 07:03:03 --> URI Class Initialized
INFO - 2024-12-19 07:03:03 --> Router Class Initialized
INFO - 2024-12-19 07:03:03 --> Output Class Initialized
INFO - 2024-12-19 07:03:03 --> Security Class Initialized
DEBUG - 2024-12-19 07:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:03:03 --> Input Class Initialized
INFO - 2024-12-19 07:03:03 --> Language Class Initialized
INFO - 2024-12-19 07:03:03 --> Loader Class Initialized
INFO - 2024-12-19 07:03:03 --> Helper loaded: url_helper
INFO - 2024-12-19 07:03:03 --> Helper loaded: form_helper
INFO - 2024-12-19 07:03:03 --> Helper loaded: file_helper
INFO - 2024-12-19 07:03:03 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:03:03 --> Form Validation Class Initialized
INFO - 2024-12-19 07:03:03 --> Upload Class Initialized
INFO - 2024-12-19 07:03:03 --> Model "M_login" initialized
INFO - 2024-12-19 07:03:03 --> Model "M_home" initialized
INFO - 2024-12-19 07:03:03 --> Model "M_setting" initialized
INFO - 2024-12-19 07:03:03 --> Controller Class Initialized
INFO - 2024-12-19 07:03:03 --> Model "M_gallery" initialized
INFO - 2024-12-19 07:03:03 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/gallery/v_list.php
INFO - 2024-12-19 07:03:03 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-19 07:03:03 --> Final output sent to browser
DEBUG - 2024-12-19 07:03:03 --> Total execution time: 0.3693
INFO - 2024-12-19 07:03:22 --> Config Class Initialized
INFO - 2024-12-19 07:03:22 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:03:22 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:03:22 --> Utf8 Class Initialized
INFO - 2024-12-19 07:03:22 --> URI Class Initialized
INFO - 2024-12-19 07:03:22 --> Router Class Initialized
INFO - 2024-12-19 07:03:22 --> Output Class Initialized
INFO - 2024-12-19 07:03:22 --> Security Class Initialized
DEBUG - 2024-12-19 07:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:03:22 --> Input Class Initialized
INFO - 2024-12-19 07:03:22 --> Language Class Initialized
INFO - 2024-12-19 07:03:22 --> Loader Class Initialized
INFO - 2024-12-19 07:03:22 --> Helper loaded: url_helper
INFO - 2024-12-19 07:03:22 --> Helper loaded: form_helper
INFO - 2024-12-19 07:03:22 --> Helper loaded: file_helper
INFO - 2024-12-19 07:03:22 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:03:22 --> Form Validation Class Initialized
INFO - 2024-12-19 07:03:22 --> Upload Class Initialized
INFO - 2024-12-19 07:03:22 --> Model "M_login" initialized
INFO - 2024-12-19 07:03:22 --> Model "M_home" initialized
INFO - 2024-12-19 07:03:22 --> Model "M_setting" initialized
INFO - 2024-12-19 07:03:22 --> Controller Class Initialized
INFO - 2024-12-19 07:03:22 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/v_setting.php
INFO - 2024-12-19 07:03:22 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-19 07:03:22 --> Final output sent to browser
DEBUG - 2024-12-19 07:03:22 --> Total execution time: 0.2154
INFO - 2024-12-19 07:03:51 --> Config Class Initialized
INFO - 2024-12-19 07:03:51 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:03:51 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:03:51 --> Utf8 Class Initialized
INFO - 2024-12-19 07:03:51 --> URI Class Initialized
INFO - 2024-12-19 07:03:51 --> Router Class Initialized
INFO - 2024-12-19 07:03:51 --> Output Class Initialized
INFO - 2024-12-19 07:03:51 --> Security Class Initialized
DEBUG - 2024-12-19 07:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:03:51 --> Input Class Initialized
INFO - 2024-12-19 07:03:51 --> Language Class Initialized
INFO - 2024-12-19 07:03:51 --> Loader Class Initialized
INFO - 2024-12-19 07:03:51 --> Helper loaded: url_helper
INFO - 2024-12-19 07:03:51 --> Helper loaded: form_helper
INFO - 2024-12-19 07:03:51 --> Helper loaded: file_helper
INFO - 2024-12-19 07:03:51 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:03:51 --> Form Validation Class Initialized
INFO - 2024-12-19 07:03:51 --> Upload Class Initialized
INFO - 2024-12-19 07:03:51 --> Model "M_login" initialized
INFO - 2024-12-19 07:03:51 --> Model "M_home" initialized
INFO - 2024-12-19 07:03:51 --> Model "M_setting" initialized
INFO - 2024-12-19 07:03:51 --> Controller Class Initialized
INFO - 2024-12-19 07:03:51 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\Admin/v_dashboard.php
INFO - 2024-12-19 07:03:51 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-19 07:03:51 --> Final output sent to browser
DEBUG - 2024-12-19 07:03:51 --> Total execution time: 0.1081
INFO - 2024-12-19 07:03:55 --> Config Class Initialized
INFO - 2024-12-19 07:03:55 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:03:55 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:03:55 --> Utf8 Class Initialized
INFO - 2024-12-19 07:03:55 --> URI Class Initialized
DEBUG - 2024-12-19 07:03:55 --> No URI present. Default controller set.
INFO - 2024-12-19 07:03:55 --> Router Class Initialized
INFO - 2024-12-19 07:03:55 --> Output Class Initialized
INFO - 2024-12-19 07:03:55 --> Security Class Initialized
DEBUG - 2024-12-19 07:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:03:55 --> Input Class Initialized
INFO - 2024-12-19 07:03:55 --> Language Class Initialized
INFO - 2024-12-19 07:03:56 --> Loader Class Initialized
INFO - 2024-12-19 07:03:56 --> Helper loaded: url_helper
INFO - 2024-12-19 07:03:56 --> Helper loaded: form_helper
INFO - 2024-12-19 07:03:56 --> Helper loaded: file_helper
INFO - 2024-12-19 07:03:56 --> Database Driver Class Initialized
DEBUG - 2024-12-19 07:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 07:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 07:03:56 --> Form Validation Class Initialized
INFO - 2024-12-19 07:03:56 --> Upload Class Initialized
INFO - 2024-12-19 07:03:56 --> Model "M_login" initialized
INFO - 2024-12-19 07:03:56 --> Model "M_home" initialized
INFO - 2024-12-19 07:03:56 --> Model "M_setting" initialized
INFO - 2024-12-19 07:03:56 --> Controller Class Initialized
INFO - 2024-12-19 07:03:56 --> Model "M_guru" initialized
INFO - 2024-12-19 07:03:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 07:03:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 07:03:56 --> Final output sent to browser
DEBUG - 2024-12-19 07:03:56 --> Total execution time: 0.1712
INFO - 2024-12-19 07:03:57 --> Config Class Initialized
INFO - 2024-12-19 07:03:57 --> Hooks Class Initialized
INFO - 2024-12-19 07:03:57 --> Config Class Initialized
INFO - 2024-12-19 07:03:57 --> Hooks Class Initialized
DEBUG - 2024-12-19 07:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-12-19 07:03:57 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:03:57 --> Utf8 Class Initialized
INFO - 2024-12-19 07:03:57 --> Utf8 Class Initialized
INFO - 2024-12-19 07:03:57 --> URI Class Initialized
INFO - 2024-12-19 07:03:57 --> URI Class Initialized
INFO - 2024-12-19 07:03:57 --> Config Class Initialized
INFO - 2024-12-19 07:03:57 --> Router Class Initialized
INFO - 2024-12-19 07:03:57 --> Router Class Initialized
INFO - 2024-12-19 07:03:57 --> Hooks Class Initialized
INFO - 2024-12-19 07:03:57 --> Output Class Initialized
INFO - 2024-12-19 07:03:57 --> Output Class Initialized
INFO - 2024-12-19 07:03:57 --> Security Class Initialized
INFO - 2024-12-19 07:03:57 --> Security Class Initialized
DEBUG - 2024-12-19 07:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-19 07:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:03:57 --> Input Class Initialized
INFO - 2024-12-19 07:03:57 --> Input Class Initialized
DEBUG - 2024-12-19 07:03:57 --> UTF-8 Support Enabled
INFO - 2024-12-19 07:03:57 --> Language Class Initialized
INFO - 2024-12-19 07:03:57 --> Language Class Initialized
INFO - 2024-12-19 07:03:57 --> Utf8 Class Initialized
INFO - 2024-12-19 07:03:57 --> URI Class Initialized
ERROR - 2024-12-19 07:03:57 --> 404 Page Not Found: Images/courses_background.jpg
ERROR - 2024-12-19 07:03:57 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 07:03:57 --> Router Class Initialized
INFO - 2024-12-19 07:03:57 --> Output Class Initialized
INFO - 2024-12-19 07:03:57 --> Security Class Initialized
DEBUG - 2024-12-19 07:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 07:03:57 --> Input Class Initialized
INFO - 2024-12-19 07:03:57 --> Language Class Initialized
ERROR - 2024-12-19 07:03:57 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 13:30:43 --> Config Class Initialized
INFO - 2024-12-19 13:30:43 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:30:43 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:30:43 --> Utf8 Class Initialized
INFO - 2024-12-19 13:30:43 --> URI Class Initialized
DEBUG - 2024-12-19 13:30:43 --> No URI present. Default controller set.
INFO - 2024-12-19 13:30:43 --> Router Class Initialized
INFO - 2024-12-19 13:30:43 --> Output Class Initialized
INFO - 2024-12-19 13:30:43 --> Security Class Initialized
DEBUG - 2024-12-19 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:30:43 --> Input Class Initialized
INFO - 2024-12-19 13:30:43 --> Language Class Initialized
INFO - 2024-12-19 13:30:43 --> Loader Class Initialized
INFO - 2024-12-19 13:30:43 --> Helper loaded: url_helper
INFO - 2024-12-19 13:30:43 --> Helper loaded: form_helper
INFO - 2024-12-19 13:30:43 --> Helper loaded: file_helper
INFO - 2024-12-19 13:30:43 --> Database Driver Class Initialized
DEBUG - 2024-12-19 13:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 13:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 13:30:43 --> Form Validation Class Initialized
INFO - 2024-12-19 13:30:43 --> Upload Class Initialized
INFO - 2024-12-19 13:30:43 --> Model "M_login" initialized
INFO - 2024-12-19 13:30:43 --> Model "M_home" initialized
INFO - 2024-12-19 13:30:43 --> Model "M_setting" initialized
INFO - 2024-12-19 13:30:43 --> Controller Class Initialized
INFO - 2024-12-19 13:30:43 --> Model "M_guru" initialized
INFO - 2024-12-19 13:30:43 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 13:30:43 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 13:30:43 --> Final output sent to browser
DEBUG - 2024-12-19 13:30:43 --> Total execution time: 0.0800
INFO - 2024-12-19 13:30:43 --> Config Class Initialized
INFO - 2024-12-19 13:30:43 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:30:43 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:30:43 --> Utf8 Class Initialized
INFO - 2024-12-19 13:30:43 --> URI Class Initialized
INFO - 2024-12-19 13:30:43 --> Router Class Initialized
INFO - 2024-12-19 13:30:43 --> Output Class Initialized
INFO - 2024-12-19 13:30:43 --> Security Class Initialized
DEBUG - 2024-12-19 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:30:43 --> Input Class Initialized
INFO - 2024-12-19 13:30:43 --> Language Class Initialized
ERROR - 2024-12-19 13:30:43 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 13:30:44 --> Config Class Initialized
INFO - 2024-12-19 13:30:44 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:30:44 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:30:44 --> Utf8 Class Initialized
INFO - 2024-12-19 13:30:44 --> URI Class Initialized
INFO - 2024-12-19 13:30:44 --> Router Class Initialized
INFO - 2024-12-19 13:30:44 --> Output Class Initialized
INFO - 2024-12-19 13:30:44 --> Security Class Initialized
DEBUG - 2024-12-19 13:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:30:44 --> Input Class Initialized
INFO - 2024-12-19 13:30:44 --> Language Class Initialized
ERROR - 2024-12-19 13:30:44 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 13:30:44 --> Config Class Initialized
INFO - 2024-12-19 13:30:44 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:30:44 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:30:44 --> Utf8 Class Initialized
INFO - 2024-12-19 13:30:44 --> URI Class Initialized
INFO - 2024-12-19 13:30:44 --> Router Class Initialized
INFO - 2024-12-19 13:30:44 --> Output Class Initialized
INFO - 2024-12-19 13:30:44 --> Security Class Initialized
DEBUG - 2024-12-19 13:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:30:44 --> Input Class Initialized
INFO - 2024-12-19 13:30:44 --> Language Class Initialized
ERROR - 2024-12-19 13:30:44 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 13:30:56 --> Config Class Initialized
INFO - 2024-12-19 13:30:56 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:30:56 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:30:56 --> Utf8 Class Initialized
INFO - 2024-12-19 13:30:56 --> URI Class Initialized
DEBUG - 2024-12-19 13:30:56 --> No URI present. Default controller set.
INFO - 2024-12-19 13:30:56 --> Router Class Initialized
INFO - 2024-12-19 13:30:56 --> Output Class Initialized
INFO - 2024-12-19 13:30:56 --> Security Class Initialized
DEBUG - 2024-12-19 13:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:30:56 --> Input Class Initialized
INFO - 2024-12-19 13:30:56 --> Language Class Initialized
INFO - 2024-12-19 13:30:56 --> Loader Class Initialized
INFO - 2024-12-19 13:30:56 --> Helper loaded: url_helper
INFO - 2024-12-19 13:30:56 --> Helper loaded: form_helper
INFO - 2024-12-19 13:30:56 --> Helper loaded: file_helper
INFO - 2024-12-19 13:30:56 --> Database Driver Class Initialized
DEBUG - 2024-12-19 13:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 13:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 13:30:56 --> Form Validation Class Initialized
INFO - 2024-12-19 13:30:56 --> Upload Class Initialized
INFO - 2024-12-19 13:30:56 --> Model "M_login" initialized
INFO - 2024-12-19 13:30:56 --> Model "M_home" initialized
INFO - 2024-12-19 13:30:56 --> Model "M_setting" initialized
INFO - 2024-12-19 13:30:56 --> Controller Class Initialized
INFO - 2024-12-19 13:30:56 --> Model "M_guru" initialized
INFO - 2024-12-19 13:30:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 13:30:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 13:30:56 --> Final output sent to browser
DEBUG - 2024-12-19 13:30:56 --> Total execution time: 0.0817
INFO - 2024-12-19 13:30:57 --> Config Class Initialized
INFO - 2024-12-19 13:30:57 --> Hooks Class Initialized
INFO - 2024-12-19 13:30:57 --> Config Class Initialized
INFO - 2024-12-19 13:30:57 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:30:57 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:30:57 --> Utf8 Class Initialized
DEBUG - 2024-12-19 13:30:57 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:30:57 --> Utf8 Class Initialized
INFO - 2024-12-19 13:30:57 --> URI Class Initialized
INFO - 2024-12-19 13:30:57 --> URI Class Initialized
INFO - 2024-12-19 13:30:57 --> Router Class Initialized
INFO - 2024-12-19 13:30:57 --> Router Class Initialized
INFO - 2024-12-19 13:30:57 --> Output Class Initialized
INFO - 2024-12-19 13:30:57 --> Output Class Initialized
INFO - 2024-12-19 13:30:57 --> Security Class Initialized
INFO - 2024-12-19 13:30:57 --> Config Class Initialized
DEBUG - 2024-12-19 13:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:30:57 --> Security Class Initialized
INFO - 2024-12-19 13:30:57 --> Input Class Initialized
INFO - 2024-12-19 13:30:57 --> Hooks Class Initialized
INFO - 2024-12-19 13:30:57 --> Language Class Initialized
DEBUG - 2024-12-19 13:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:30:57 --> Input Class Initialized
INFO - 2024-12-19 13:30:57 --> Language Class Initialized
ERROR - 2024-12-19 13:30:57 --> 404 Page Not Found: Images/courses_background.jpg
DEBUG - 2024-12-19 13:30:57 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:30:57 --> Utf8 Class Initialized
ERROR - 2024-12-19 13:30:57 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 13:30:57 --> URI Class Initialized
INFO - 2024-12-19 13:30:57 --> Router Class Initialized
INFO - 2024-12-19 13:30:57 --> Output Class Initialized
INFO - 2024-12-19 13:30:57 --> Security Class Initialized
DEBUG - 2024-12-19 13:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:30:57 --> Input Class Initialized
INFO - 2024-12-19 13:30:57 --> Language Class Initialized
ERROR - 2024-12-19 13:30:57 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 13:49:01 --> Config Class Initialized
INFO - 2024-12-19 13:49:01 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:49:01 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:49:01 --> Utf8 Class Initialized
INFO - 2024-12-19 13:49:01 --> URI Class Initialized
INFO - 2024-12-19 13:49:01 --> Router Class Initialized
INFO - 2024-12-19 13:49:01 --> Output Class Initialized
INFO - 2024-12-19 13:49:01 --> Security Class Initialized
DEBUG - 2024-12-19 13:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:49:01 --> Input Class Initialized
INFO - 2024-12-19 13:49:01 --> Language Class Initialized
INFO - 2024-12-19 13:49:01 --> Loader Class Initialized
INFO - 2024-12-19 13:49:01 --> Helper loaded: url_helper
INFO - 2024-12-19 13:49:01 --> Helper loaded: form_helper
INFO - 2024-12-19 13:49:01 --> Helper loaded: file_helper
INFO - 2024-12-19 13:49:01 --> Database Driver Class Initialized
DEBUG - 2024-12-19 13:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 13:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 13:49:01 --> Form Validation Class Initialized
INFO - 2024-12-19 13:49:01 --> Upload Class Initialized
INFO - 2024-12-19 13:49:01 --> Model "M_login" initialized
INFO - 2024-12-19 13:49:01 --> Model "M_home" initialized
INFO - 2024-12-19 13:49:01 --> Model "M_setting" initialized
INFO - 2024-12-19 13:49:01 --> Controller Class Initialized
INFO - 2024-12-19 13:49:01 --> Model "M_guru" initialized
INFO - 2024-12-19 13:49:01 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-19 13:49:01 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 13:49:01 --> Final output sent to browser
DEBUG - 2024-12-19 13:49:01 --> Total execution time: 0.0546
INFO - 2024-12-19 13:49:03 --> Config Class Initialized
INFO - 2024-12-19 13:49:03 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:49:03 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:49:03 --> Utf8 Class Initialized
INFO - 2024-12-19 13:49:03 --> URI Class Initialized
INFO - 2024-12-19 13:49:03 --> Router Class Initialized
INFO - 2024-12-19 13:49:03 --> Output Class Initialized
INFO - 2024-12-19 13:49:03 --> Security Class Initialized
DEBUG - 2024-12-19 13:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:49:03 --> Input Class Initialized
INFO - 2024-12-19 13:49:03 --> Language Class Initialized
INFO - 2024-12-19 13:49:03 --> Loader Class Initialized
INFO - 2024-12-19 13:49:03 --> Helper loaded: url_helper
INFO - 2024-12-19 13:49:03 --> Helper loaded: form_helper
INFO - 2024-12-19 13:49:03 --> Helper loaded: file_helper
INFO - 2024-12-19 13:49:03 --> Database Driver Class Initialized
DEBUG - 2024-12-19 13:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 13:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 13:49:03 --> Form Validation Class Initialized
INFO - 2024-12-19 13:49:03 --> Upload Class Initialized
INFO - 2024-12-19 13:49:03 --> Model "M_login" initialized
INFO - 2024-12-19 13:49:03 --> Model "M_home" initialized
INFO - 2024-12-19 13:49:03 --> Model "M_setting" initialized
INFO - 2024-12-19 13:49:03 --> Controller Class Initialized
INFO - 2024-12-19 13:49:03 --> Model "M_guru" initialized
INFO - 2024-12-19 13:49:03 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 13:49:03 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 13:49:03 --> Final output sent to browser
DEBUG - 2024-12-19 13:49:03 --> Total execution time: 0.0757
INFO - 2024-12-19 13:49:04 --> Config Class Initialized
INFO - 2024-12-19 13:49:04 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:49:04 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:49:04 --> Utf8 Class Initialized
INFO - 2024-12-19 13:49:04 --> URI Class Initialized
INFO - 2024-12-19 13:49:04 --> Router Class Initialized
INFO - 2024-12-19 13:49:04 --> Output Class Initialized
INFO - 2024-12-19 13:49:04 --> Security Class Initialized
DEBUG - 2024-12-19 13:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:49:04 --> Input Class Initialized
INFO - 2024-12-19 13:49:04 --> Language Class Initialized
INFO - 2024-12-19 13:49:04 --> Loader Class Initialized
INFO - 2024-12-19 13:49:04 --> Helper loaded: url_helper
INFO - 2024-12-19 13:49:04 --> Helper loaded: form_helper
INFO - 2024-12-19 13:49:04 --> Helper loaded: file_helper
INFO - 2024-12-19 13:49:04 --> Database Driver Class Initialized
DEBUG - 2024-12-19 13:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 13:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 13:49:04 --> Form Validation Class Initialized
INFO - 2024-12-19 13:49:04 --> Upload Class Initialized
INFO - 2024-12-19 13:49:04 --> Model "M_login" initialized
INFO - 2024-12-19 13:49:04 --> Model "M_home" initialized
INFO - 2024-12-19 13:49:04 --> Model "M_setting" initialized
INFO - 2024-12-19 13:49:04 --> Controller Class Initialized
INFO - 2024-12-19 13:49:04 --> Model "M_guru" initialized
INFO - 2024-12-19 13:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 13:49:04 --> Pagination Class Initialized
INFO - 2024-12-19 13:49:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 13:49:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 13:49:04 --> Final output sent to browser
DEBUG - 2024-12-19 13:49:04 --> Total execution time: 0.0558
INFO - 2024-12-19 13:49:06 --> Config Class Initialized
INFO - 2024-12-19 13:49:06 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:49:06 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:49:06 --> Utf8 Class Initialized
INFO - 2024-12-19 13:49:06 --> URI Class Initialized
INFO - 2024-12-19 13:49:06 --> Router Class Initialized
INFO - 2024-12-19 13:49:06 --> Output Class Initialized
INFO - 2024-12-19 13:49:06 --> Security Class Initialized
DEBUG - 2024-12-19 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:49:06 --> Input Class Initialized
INFO - 2024-12-19 13:49:06 --> Language Class Initialized
INFO - 2024-12-19 13:49:06 --> Loader Class Initialized
INFO - 2024-12-19 13:49:06 --> Helper loaded: url_helper
INFO - 2024-12-19 13:49:06 --> Helper loaded: form_helper
INFO - 2024-12-19 13:49:06 --> Helper loaded: file_helper
INFO - 2024-12-19 13:49:06 --> Database Driver Class Initialized
DEBUG - 2024-12-19 13:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 13:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 13:49:06 --> Form Validation Class Initialized
INFO - 2024-12-19 13:49:06 --> Upload Class Initialized
INFO - 2024-12-19 13:49:06 --> Model "M_login" initialized
INFO - 2024-12-19 13:49:06 --> Model "M_home" initialized
INFO - 2024-12-19 13:49:06 --> Model "M_setting" initialized
INFO - 2024-12-19 13:49:06 --> Controller Class Initialized
INFO - 2024-12-19 13:49:06 --> Model "M_guru" initialized
INFO - 2024-12-19 13:49:06 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 13:49:06 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 13:49:06 --> Final output sent to browser
DEBUG - 2024-12-19 13:49:06 --> Total execution time: 0.0464
INFO - 2024-12-19 13:49:06 --> Config Class Initialized
INFO - 2024-12-19 13:49:06 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:49:06 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:49:06 --> Utf8 Class Initialized
INFO - 2024-12-19 13:49:06 --> URI Class Initialized
INFO - 2024-12-19 13:49:06 --> Router Class Initialized
INFO - 2024-12-19 13:49:06 --> Output Class Initialized
INFO - 2024-12-19 13:49:06 --> Security Class Initialized
DEBUG - 2024-12-19 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:49:06 --> Input Class Initialized
INFO - 2024-12-19 13:49:06 --> Language Class Initialized
ERROR - 2024-12-19 13:49:06 --> 404 Page Not Found: Home/images
INFO - 2024-12-19 13:59:41 --> Config Class Initialized
INFO - 2024-12-19 13:59:41 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:59:41 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:59:41 --> Utf8 Class Initialized
INFO - 2024-12-19 13:59:41 --> URI Class Initialized
DEBUG - 2024-12-19 13:59:41 --> No URI present. Default controller set.
INFO - 2024-12-19 13:59:41 --> Router Class Initialized
INFO - 2024-12-19 13:59:41 --> Output Class Initialized
INFO - 2024-12-19 13:59:41 --> Security Class Initialized
DEBUG - 2024-12-19 13:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:59:41 --> Input Class Initialized
INFO - 2024-12-19 13:59:41 --> Language Class Initialized
INFO - 2024-12-19 13:59:41 --> Loader Class Initialized
INFO - 2024-12-19 13:59:41 --> Helper loaded: url_helper
INFO - 2024-12-19 13:59:41 --> Helper loaded: form_helper
INFO - 2024-12-19 13:59:41 --> Helper loaded: file_helper
INFO - 2024-12-19 13:59:41 --> Database Driver Class Initialized
DEBUG - 2024-12-19 13:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 13:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 13:59:41 --> Form Validation Class Initialized
INFO - 2024-12-19 13:59:41 --> Upload Class Initialized
INFO - 2024-12-19 13:59:41 --> Model "M_login" initialized
INFO - 2024-12-19 13:59:41 --> Model "M_home" initialized
INFO - 2024-12-19 13:59:41 --> Model "M_setting" initialized
INFO - 2024-12-19 13:59:41 --> Controller Class Initialized
INFO - 2024-12-19 13:59:41 --> Model "M_guru" initialized
INFO - 2024-12-19 13:59:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 13:59:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 13:59:41 --> Final output sent to browser
DEBUG - 2024-12-19 13:59:41 --> Total execution time: 0.0664
INFO - 2024-12-19 13:59:41 --> Config Class Initialized
INFO - 2024-12-19 13:59:41 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:59:41 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:59:41 --> Utf8 Class Initialized
INFO - 2024-12-19 13:59:41 --> URI Class Initialized
INFO - 2024-12-19 13:59:41 --> Config Class Initialized
INFO - 2024-12-19 13:59:41 --> Hooks Class Initialized
INFO - 2024-12-19 13:59:41 --> Router Class Initialized
INFO - 2024-12-19 13:59:41 --> Output Class Initialized
DEBUG - 2024-12-19 13:59:41 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:59:41 --> Utf8 Class Initialized
INFO - 2024-12-19 13:59:41 --> URI Class Initialized
INFO - 2024-12-19 13:59:41 --> Security Class Initialized
DEBUG - 2024-12-19 13:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:59:41 --> Input Class Initialized
INFO - 2024-12-19 13:59:41 --> Router Class Initialized
INFO - 2024-12-19 13:59:41 --> Language Class Initialized
INFO - 2024-12-19 13:59:41 --> Output Class Initialized
ERROR - 2024-12-19 13:59:41 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 13:59:41 --> Security Class Initialized
DEBUG - 2024-12-19 13:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:59:41 --> Input Class Initialized
INFO - 2024-12-19 13:59:41 --> Language Class Initialized
ERROR - 2024-12-19 13:59:41 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 13:59:41 --> Config Class Initialized
INFO - 2024-12-19 13:59:41 --> Hooks Class Initialized
DEBUG - 2024-12-19 13:59:41 --> UTF-8 Support Enabled
INFO - 2024-12-19 13:59:41 --> Utf8 Class Initialized
INFO - 2024-12-19 13:59:41 --> URI Class Initialized
INFO - 2024-12-19 13:59:41 --> Router Class Initialized
INFO - 2024-12-19 13:59:41 --> Output Class Initialized
INFO - 2024-12-19 13:59:41 --> Security Class Initialized
DEBUG - 2024-12-19 13:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 13:59:41 --> Input Class Initialized
INFO - 2024-12-19 13:59:41 --> Language Class Initialized
ERROR - 2024-12-19 13:59:41 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 14:12:58 --> Config Class Initialized
INFO - 2024-12-19 14:12:58 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:12:58 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:12:58 --> Utf8 Class Initialized
INFO - 2024-12-19 14:12:58 --> URI Class Initialized
INFO - 2024-12-19 14:12:58 --> Router Class Initialized
INFO - 2024-12-19 14:12:58 --> Output Class Initialized
INFO - 2024-12-19 14:12:58 --> Security Class Initialized
DEBUG - 2024-12-19 14:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:12:58 --> Input Class Initialized
INFO - 2024-12-19 14:12:58 --> Language Class Initialized
INFO - 2024-12-19 14:12:58 --> Loader Class Initialized
INFO - 2024-12-19 14:12:58 --> Helper loaded: url_helper
INFO - 2024-12-19 14:12:58 --> Helper loaded: form_helper
INFO - 2024-12-19 14:12:58 --> Helper loaded: file_helper
INFO - 2024-12-19 14:12:58 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:12:58 --> Form Validation Class Initialized
INFO - 2024-12-19 14:12:58 --> Upload Class Initialized
INFO - 2024-12-19 14:12:58 --> Model "M_login" initialized
INFO - 2024-12-19 14:12:58 --> Model "M_home" initialized
INFO - 2024-12-19 14:12:58 --> Model "M_setting" initialized
INFO - 2024-12-19 14:12:58 --> Controller Class Initialized
INFO - 2024-12-19 14:12:58 --> Model "M_guru" initialized
INFO - 2024-12-19 14:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 14:12:58 --> Pagination Class Initialized
INFO - 2024-12-19 14:12:58 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 14:12:58 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:12:58 --> Final output sent to browser
DEBUG - 2024-12-19 14:12:58 --> Total execution time: 0.0606
INFO - 2024-12-19 14:12:59 --> Config Class Initialized
INFO - 2024-12-19 14:12:59 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:12:59 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:12:59 --> Utf8 Class Initialized
INFO - 2024-12-19 14:12:59 --> URI Class Initialized
INFO - 2024-12-19 14:12:59 --> Router Class Initialized
INFO - 2024-12-19 14:12:59 --> Output Class Initialized
INFO - 2024-12-19 14:12:59 --> Security Class Initialized
DEBUG - 2024-12-19 14:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:12:59 --> Input Class Initialized
INFO - 2024-12-19 14:12:59 --> Language Class Initialized
INFO - 2024-12-19 14:12:59 --> Loader Class Initialized
INFO - 2024-12-19 14:12:59 --> Helper loaded: url_helper
INFO - 2024-12-19 14:12:59 --> Helper loaded: form_helper
INFO - 2024-12-19 14:12:59 --> Helper loaded: file_helper
INFO - 2024-12-19 14:12:59 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:12:59 --> Form Validation Class Initialized
INFO - 2024-12-19 14:12:59 --> Upload Class Initialized
INFO - 2024-12-19 14:12:59 --> Model "M_login" initialized
INFO - 2024-12-19 14:12:59 --> Model "M_home" initialized
INFO - 2024-12-19 14:12:59 --> Model "M_setting" initialized
INFO - 2024-12-19 14:12:59 --> Controller Class Initialized
INFO - 2024-12-19 14:12:59 --> Model "M_guru" initialized
INFO - 2024-12-19 14:12:59 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 14:12:59 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:12:59 --> Final output sent to browser
DEBUG - 2024-12-19 14:12:59 --> Total execution time: 0.0498
INFO - 2024-12-19 14:12:59 --> Config Class Initialized
INFO - 2024-12-19 14:12:59 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:12:59 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:12:59 --> Utf8 Class Initialized
INFO - 2024-12-19 14:12:59 --> URI Class Initialized
INFO - 2024-12-19 14:12:59 --> Router Class Initialized
INFO - 2024-12-19 14:12:59 --> Output Class Initialized
INFO - 2024-12-19 14:12:59 --> Security Class Initialized
DEBUG - 2024-12-19 14:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:12:59 --> Input Class Initialized
INFO - 2024-12-19 14:12:59 --> Language Class Initialized
ERROR - 2024-12-19 14:12:59 --> 404 Page Not Found: Home/images
INFO - 2024-12-19 14:13:04 --> Config Class Initialized
INFO - 2024-12-19 14:13:04 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:13:04 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:13:04 --> Utf8 Class Initialized
INFO - 2024-12-19 14:13:04 --> URI Class Initialized
INFO - 2024-12-19 14:13:04 --> Router Class Initialized
INFO - 2024-12-19 14:13:04 --> Output Class Initialized
INFO - 2024-12-19 14:13:04 --> Security Class Initialized
DEBUG - 2024-12-19 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:13:04 --> Input Class Initialized
INFO - 2024-12-19 14:13:04 --> Language Class Initialized
ERROR - 2024-12-19 14:13:04 --> 404 Page Not Found: Home/index.html
INFO - 2024-12-19 14:13:07 --> Config Class Initialized
INFO - 2024-12-19 14:13:07 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:13:07 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:13:07 --> Utf8 Class Initialized
INFO - 2024-12-19 14:13:07 --> URI Class Initialized
INFO - 2024-12-19 14:13:07 --> Router Class Initialized
INFO - 2024-12-19 14:13:07 --> Output Class Initialized
INFO - 2024-12-19 14:13:07 --> Security Class Initialized
DEBUG - 2024-12-19 14:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:13:07 --> Input Class Initialized
INFO - 2024-12-19 14:13:07 --> Language Class Initialized
INFO - 2024-12-19 14:13:07 --> Loader Class Initialized
INFO - 2024-12-19 14:13:07 --> Helper loaded: url_helper
INFO - 2024-12-19 14:13:07 --> Helper loaded: form_helper
INFO - 2024-12-19 14:13:07 --> Helper loaded: file_helper
INFO - 2024-12-19 14:13:07 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:13:07 --> Form Validation Class Initialized
INFO - 2024-12-19 14:13:07 --> Upload Class Initialized
INFO - 2024-12-19 14:13:07 --> Model "M_login" initialized
INFO - 2024-12-19 14:13:07 --> Model "M_home" initialized
INFO - 2024-12-19 14:13:07 --> Model "M_setting" initialized
INFO - 2024-12-19 14:13:07 --> Controller Class Initialized
INFO - 2024-12-19 14:13:07 --> Model "M_guru" initialized
INFO - 2024-12-19 14:13:07 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 14:13:07 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:13:07 --> Final output sent to browser
DEBUG - 2024-12-19 14:13:07 --> Total execution time: 0.0508
INFO - 2024-12-19 14:14:12 --> Config Class Initialized
INFO - 2024-12-19 14:14:12 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:14:12 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:14:12 --> Utf8 Class Initialized
INFO - 2024-12-19 14:14:12 --> URI Class Initialized
INFO - 2024-12-19 14:14:12 --> Router Class Initialized
INFO - 2024-12-19 14:14:12 --> Output Class Initialized
INFO - 2024-12-19 14:14:12 --> Security Class Initialized
DEBUG - 2024-12-19 14:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:14:12 --> Input Class Initialized
INFO - 2024-12-19 14:14:12 --> Language Class Initialized
ERROR - 2024-12-19 14:14:12 --> 404 Page Not Found: Home/index.html
INFO - 2024-12-19 14:14:14 --> Config Class Initialized
INFO - 2024-12-19 14:14:14 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:14:14 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:14:14 --> Utf8 Class Initialized
INFO - 2024-12-19 14:14:14 --> URI Class Initialized
INFO - 2024-12-19 14:14:14 --> Router Class Initialized
INFO - 2024-12-19 14:14:14 --> Output Class Initialized
INFO - 2024-12-19 14:14:14 --> Security Class Initialized
DEBUG - 2024-12-19 14:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:14:14 --> Input Class Initialized
INFO - 2024-12-19 14:14:14 --> Language Class Initialized
INFO - 2024-12-19 14:14:14 --> Loader Class Initialized
INFO - 2024-12-19 14:14:14 --> Helper loaded: url_helper
INFO - 2024-12-19 14:14:14 --> Helper loaded: form_helper
INFO - 2024-12-19 14:14:14 --> Helper loaded: file_helper
INFO - 2024-12-19 14:14:14 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:14:14 --> Form Validation Class Initialized
INFO - 2024-12-19 14:14:14 --> Upload Class Initialized
INFO - 2024-12-19 14:14:14 --> Model "M_login" initialized
INFO - 2024-12-19 14:14:14 --> Model "M_home" initialized
INFO - 2024-12-19 14:14:14 --> Model "M_setting" initialized
INFO - 2024-12-19 14:14:14 --> Controller Class Initialized
INFO - 2024-12-19 14:14:14 --> Model "M_guru" initialized
INFO - 2024-12-19 14:14:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 14:14:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:14:14 --> Final output sent to browser
DEBUG - 2024-12-19 14:14:14 --> Total execution time: 0.0505
INFO - 2024-12-19 14:15:39 --> Config Class Initialized
INFO - 2024-12-19 14:15:39 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:15:39 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:15:39 --> Utf8 Class Initialized
INFO - 2024-12-19 14:15:39 --> URI Class Initialized
INFO - 2024-12-19 14:15:39 --> Router Class Initialized
INFO - 2024-12-19 14:15:39 --> Output Class Initialized
INFO - 2024-12-19 14:15:39 --> Security Class Initialized
DEBUG - 2024-12-19 14:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:15:39 --> Input Class Initialized
INFO - 2024-12-19 14:15:39 --> Language Class Initialized
INFO - 2024-12-19 14:15:39 --> Loader Class Initialized
INFO - 2024-12-19 14:15:39 --> Helper loaded: url_helper
INFO - 2024-12-19 14:15:39 --> Helper loaded: form_helper
INFO - 2024-12-19 14:15:39 --> Helper loaded: file_helper
INFO - 2024-12-19 14:15:39 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:15:39 --> Form Validation Class Initialized
INFO - 2024-12-19 14:15:39 --> Upload Class Initialized
INFO - 2024-12-19 14:15:39 --> Model "M_login" initialized
INFO - 2024-12-19 14:15:39 --> Model "M_home" initialized
INFO - 2024-12-19 14:15:39 --> Model "M_setting" initialized
INFO - 2024-12-19 14:15:39 --> Controller Class Initialized
INFO - 2024-12-19 14:15:39 --> Model "M_guru" initialized
INFO - 2024-12-19 14:15:39 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 14:15:39 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:15:39 --> Final output sent to browser
DEBUG - 2024-12-19 14:15:39 --> Total execution time: 0.0460
INFO - 2024-12-19 14:15:40 --> Config Class Initialized
INFO - 2024-12-19 14:15:40 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:15:40 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:15:40 --> Utf8 Class Initialized
INFO - 2024-12-19 14:15:40 --> URI Class Initialized
INFO - 2024-12-19 14:15:40 --> Router Class Initialized
INFO - 2024-12-19 14:15:40 --> Output Class Initialized
INFO - 2024-12-19 14:15:40 --> Security Class Initialized
DEBUG - 2024-12-19 14:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:15:40 --> Input Class Initialized
INFO - 2024-12-19 14:15:40 --> Language Class Initialized
ERROR - 2024-12-19 14:15:40 --> 404 Page Not Found: Home/images
INFO - 2024-12-19 14:15:47 --> Config Class Initialized
INFO - 2024-12-19 14:15:47 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:15:47 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:15:47 --> Utf8 Class Initialized
INFO - 2024-12-19 14:15:47 --> URI Class Initialized
INFO - 2024-12-19 14:15:47 --> Router Class Initialized
INFO - 2024-12-19 14:15:47 --> Output Class Initialized
INFO - 2024-12-19 14:15:47 --> Security Class Initialized
DEBUG - 2024-12-19 14:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:15:47 --> Input Class Initialized
INFO - 2024-12-19 14:15:47 --> Language Class Initialized
ERROR - 2024-12-19 14:15:47 --> 404 Page Not Found: Home/index.html
INFO - 2024-12-19 14:15:49 --> Config Class Initialized
INFO - 2024-12-19 14:15:49 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:15:49 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:15:49 --> Utf8 Class Initialized
INFO - 2024-12-19 14:15:49 --> URI Class Initialized
INFO - 2024-12-19 14:15:49 --> Router Class Initialized
INFO - 2024-12-19 14:15:49 --> Output Class Initialized
INFO - 2024-12-19 14:15:49 --> Security Class Initialized
DEBUG - 2024-12-19 14:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:15:49 --> Input Class Initialized
INFO - 2024-12-19 14:15:49 --> Language Class Initialized
INFO - 2024-12-19 14:15:49 --> Loader Class Initialized
INFO - 2024-12-19 14:15:49 --> Helper loaded: url_helper
INFO - 2024-12-19 14:15:49 --> Helper loaded: form_helper
INFO - 2024-12-19 14:15:49 --> Helper loaded: file_helper
INFO - 2024-12-19 14:15:49 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:15:49 --> Form Validation Class Initialized
INFO - 2024-12-19 14:15:49 --> Upload Class Initialized
INFO - 2024-12-19 14:15:49 --> Model "M_login" initialized
INFO - 2024-12-19 14:15:49 --> Model "M_home" initialized
INFO - 2024-12-19 14:15:49 --> Model "M_setting" initialized
INFO - 2024-12-19 14:15:49 --> Controller Class Initialized
INFO - 2024-12-19 14:15:49 --> Model "M_guru" initialized
INFO - 2024-12-19 14:15:49 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 14:15:49 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:15:49 --> Final output sent to browser
DEBUG - 2024-12-19 14:15:49 --> Total execution time: 0.0430
INFO - 2024-12-19 14:17:22 --> Config Class Initialized
INFO - 2024-12-19 14:17:22 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:17:22 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:17:22 --> Utf8 Class Initialized
INFO - 2024-12-19 14:17:22 --> URI Class Initialized
INFO - 2024-12-19 14:17:22 --> Router Class Initialized
INFO - 2024-12-19 14:17:22 --> Output Class Initialized
INFO - 2024-12-19 14:17:22 --> Security Class Initialized
DEBUG - 2024-12-19 14:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:17:22 --> Input Class Initialized
INFO - 2024-12-19 14:17:22 --> Language Class Initialized
INFO - 2024-12-19 14:17:22 --> Loader Class Initialized
INFO - 2024-12-19 14:17:22 --> Helper loaded: url_helper
INFO - 2024-12-19 14:17:22 --> Helper loaded: form_helper
INFO - 2024-12-19 14:17:22 --> Helper loaded: file_helper
INFO - 2024-12-19 14:17:22 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:17:22 --> Form Validation Class Initialized
INFO - 2024-12-19 14:17:22 --> Upload Class Initialized
INFO - 2024-12-19 14:17:22 --> Model "M_login" initialized
INFO - 2024-12-19 14:17:22 --> Model "M_home" initialized
INFO - 2024-12-19 14:17:22 --> Model "M_setting" initialized
INFO - 2024-12-19 14:17:22 --> Controller Class Initialized
INFO - 2024-12-19 14:17:22 --> Model "M_guru" initialized
INFO - 2024-12-19 14:17:22 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 14:17:22 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:17:22 --> Final output sent to browser
DEBUG - 2024-12-19 14:17:22 --> Total execution time: 0.0424
INFO - 2024-12-19 14:17:22 --> Config Class Initialized
INFO - 2024-12-19 14:17:22 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:17:22 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:17:22 --> Utf8 Class Initialized
INFO - 2024-12-19 14:17:22 --> URI Class Initialized
INFO - 2024-12-19 14:17:22 --> Router Class Initialized
INFO - 2024-12-19 14:17:22 --> Output Class Initialized
INFO - 2024-12-19 14:17:22 --> Security Class Initialized
DEBUG - 2024-12-19 14:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:17:22 --> Input Class Initialized
INFO - 2024-12-19 14:17:22 --> Language Class Initialized
ERROR - 2024-12-19 14:17:22 --> 404 Page Not Found: Home/images
INFO - 2024-12-19 14:17:25 --> Config Class Initialized
INFO - 2024-12-19 14:17:25 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:17:25 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:17:25 --> Utf8 Class Initialized
INFO - 2024-12-19 14:17:25 --> URI Class Initialized
INFO - 2024-12-19 14:17:25 --> Router Class Initialized
INFO - 2024-12-19 14:17:25 --> Output Class Initialized
INFO - 2024-12-19 14:17:25 --> Security Class Initialized
DEBUG - 2024-12-19 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:17:25 --> Input Class Initialized
INFO - 2024-12-19 14:17:25 --> Language Class Initialized
INFO - 2024-12-19 14:17:25 --> Loader Class Initialized
INFO - 2024-12-19 14:17:25 --> Helper loaded: url_helper
INFO - 2024-12-19 14:17:25 --> Helper loaded: form_helper
INFO - 2024-12-19 14:17:25 --> Helper loaded: file_helper
INFO - 2024-12-19 14:17:25 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:17:25 --> Form Validation Class Initialized
INFO - 2024-12-19 14:17:25 --> Upload Class Initialized
INFO - 2024-12-19 14:17:25 --> Model "M_login" initialized
INFO - 2024-12-19 14:17:25 --> Model "M_home" initialized
INFO - 2024-12-19 14:17:25 --> Model "M_setting" initialized
INFO - 2024-12-19 14:17:25 --> Controller Class Initialized
INFO - 2024-12-19 14:17:25 --> Model "M_guru" initialized
INFO - 2024-12-19 14:17:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:17:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:17:25 --> Final output sent to browser
DEBUG - 2024-12-19 14:17:25 --> Total execution time: 0.0455
INFO - 2024-12-19 14:17:25 --> Config Class Initialized
INFO - 2024-12-19 14:17:25 --> Hooks Class Initialized
INFO - 2024-12-19 14:17:25 --> Config Class Initialized
DEBUG - 2024-12-19 14:17:25 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:17:25 --> Utf8 Class Initialized
INFO - 2024-12-19 14:17:25 --> URI Class Initialized
INFO - 2024-12-19 14:17:25 --> Hooks Class Initialized
INFO - 2024-12-19 14:17:25 --> Router Class Initialized
INFO - 2024-12-19 14:17:25 --> Config Class Initialized
INFO - 2024-12-19 14:17:25 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:17:25 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:17:25 --> Output Class Initialized
INFO - 2024-12-19 14:17:25 --> Utf8 Class Initialized
INFO - 2024-12-19 14:17:25 --> URI Class Initialized
INFO - 2024-12-19 14:17:25 --> Security Class Initialized
DEBUG - 2024-12-19 14:17:25 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:17:25 --> Utf8 Class Initialized
INFO - 2024-12-19 14:17:25 --> Router Class Initialized
DEBUG - 2024-12-19 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:17:25 --> Input Class Initialized
INFO - 2024-12-19 14:17:25 --> URI Class Initialized
INFO - 2024-12-19 14:17:25 --> Output Class Initialized
INFO - 2024-12-19 14:17:25 --> Language Class Initialized
INFO - 2024-12-19 14:17:25 --> Router Class Initialized
INFO - 2024-12-19 14:17:25 --> Security Class Initialized
ERROR - 2024-12-19 14:17:25 --> 404 Page Not Found: Images/team_background.jpg
DEBUG - 2024-12-19 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:17:25 --> Input Class Initialized
INFO - 2024-12-19 14:17:25 --> Output Class Initialized
INFO - 2024-12-19 14:17:25 --> Language Class Initialized
INFO - 2024-12-19 14:17:25 --> Security Class Initialized
ERROR - 2024-12-19 14:17:25 --> 404 Page Not Found: Images/courses_background.jpg
DEBUG - 2024-12-19 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:17:25 --> Input Class Initialized
INFO - 2024-12-19 14:17:25 --> Language Class Initialized
ERROR - 2024-12-19 14:17:25 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 14:19:47 --> Config Class Initialized
INFO - 2024-12-19 14:19:47 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:19:47 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:19:47 --> Utf8 Class Initialized
INFO - 2024-12-19 14:19:47 --> URI Class Initialized
INFO - 2024-12-19 14:19:47 --> Router Class Initialized
INFO - 2024-12-19 14:19:47 --> Output Class Initialized
INFO - 2024-12-19 14:19:47 --> Security Class Initialized
DEBUG - 2024-12-19 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:19:47 --> Input Class Initialized
INFO - 2024-12-19 14:19:47 --> Language Class Initialized
INFO - 2024-12-19 14:19:47 --> Loader Class Initialized
INFO - 2024-12-19 14:19:47 --> Helper loaded: url_helper
INFO - 2024-12-19 14:19:47 --> Helper loaded: form_helper
INFO - 2024-12-19 14:19:47 --> Helper loaded: file_helper
INFO - 2024-12-19 14:19:47 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:19:47 --> Form Validation Class Initialized
INFO - 2024-12-19 14:19:47 --> Upload Class Initialized
INFO - 2024-12-19 14:19:47 --> Model "M_login" initialized
INFO - 2024-12-19 14:19:47 --> Model "M_home" initialized
INFO - 2024-12-19 14:19:47 --> Model "M_setting" initialized
INFO - 2024-12-19 14:19:47 --> Controller Class Initialized
INFO - 2024-12-19 14:19:47 --> Model "M_guru" initialized
INFO - 2024-12-19 14:19:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:19:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:19:47 --> Final output sent to browser
DEBUG - 2024-12-19 14:19:47 --> Total execution time: 0.0628
INFO - 2024-12-19 14:19:48 --> Config Class Initialized
INFO - 2024-12-19 14:19:48 --> Hooks Class Initialized
INFO - 2024-12-19 14:19:48 --> Config Class Initialized
INFO - 2024-12-19 14:19:48 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:19:48 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:19:48 --> Utf8 Class Initialized
DEBUG - 2024-12-19 14:19:48 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:19:48 --> Utf8 Class Initialized
INFO - 2024-12-19 14:19:48 --> URI Class Initialized
INFO - 2024-12-19 14:19:48 --> URI Class Initialized
INFO - 2024-12-19 14:19:48 --> Router Class Initialized
INFO - 2024-12-19 14:19:48 --> Router Class Initialized
INFO - 2024-12-19 14:19:48 --> Output Class Initialized
INFO - 2024-12-19 14:19:48 --> Output Class Initialized
INFO - 2024-12-19 14:19:48 --> Security Class Initialized
INFO - 2024-12-19 14:19:48 --> Security Class Initialized
DEBUG - 2024-12-19 14:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-19 14:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:19:48 --> Input Class Initialized
INFO - 2024-12-19 14:19:48 --> Input Class Initialized
INFO - 2024-12-19 14:19:48 --> Language Class Initialized
INFO - 2024-12-19 14:19:48 --> Language Class Initialized
ERROR - 2024-12-19 14:19:48 --> 404 Page Not Found: Images/courses_background.jpg
ERROR - 2024-12-19 14:19:48 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 14:19:48 --> Config Class Initialized
INFO - 2024-12-19 14:19:48 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:19:48 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:19:48 --> Utf8 Class Initialized
INFO - 2024-12-19 14:19:48 --> URI Class Initialized
INFO - 2024-12-19 14:19:48 --> Router Class Initialized
INFO - 2024-12-19 14:19:48 --> Output Class Initialized
INFO - 2024-12-19 14:19:48 --> Security Class Initialized
DEBUG - 2024-12-19 14:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:19:48 --> Input Class Initialized
INFO - 2024-12-19 14:19:48 --> Language Class Initialized
ERROR - 2024-12-19 14:19:48 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 14:19:51 --> Config Class Initialized
INFO - 2024-12-19 14:19:51 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:19:51 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:19:51 --> Utf8 Class Initialized
INFO - 2024-12-19 14:19:51 --> URI Class Initialized
INFO - 2024-12-19 14:19:51 --> Router Class Initialized
INFO - 2024-12-19 14:19:51 --> Output Class Initialized
INFO - 2024-12-19 14:19:51 --> Security Class Initialized
DEBUG - 2024-12-19 14:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:19:51 --> Input Class Initialized
INFO - 2024-12-19 14:19:51 --> Language Class Initialized
ERROR - 2024-12-19 14:19:51 --> 404 Page Not Found: Tentang/index
INFO - 2024-12-19 14:19:54 --> Config Class Initialized
INFO - 2024-12-19 14:19:54 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:19:54 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:19:54 --> Utf8 Class Initialized
INFO - 2024-12-19 14:19:54 --> URI Class Initialized
INFO - 2024-12-19 14:19:54 --> Router Class Initialized
INFO - 2024-12-19 14:19:54 --> Output Class Initialized
INFO - 2024-12-19 14:19:54 --> Security Class Initialized
DEBUG - 2024-12-19 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:19:54 --> Input Class Initialized
INFO - 2024-12-19 14:19:54 --> Language Class Initialized
INFO - 2024-12-19 14:19:54 --> Loader Class Initialized
INFO - 2024-12-19 14:19:54 --> Helper loaded: url_helper
INFO - 2024-12-19 14:19:54 --> Helper loaded: form_helper
INFO - 2024-12-19 14:19:54 --> Helper loaded: file_helper
INFO - 2024-12-19 14:19:54 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:19:54 --> Form Validation Class Initialized
INFO - 2024-12-19 14:19:54 --> Upload Class Initialized
INFO - 2024-12-19 14:19:54 --> Model "M_login" initialized
INFO - 2024-12-19 14:19:54 --> Model "M_home" initialized
INFO - 2024-12-19 14:19:54 --> Model "M_setting" initialized
INFO - 2024-12-19 14:19:54 --> Controller Class Initialized
INFO - 2024-12-19 14:19:54 --> Model "M_guru" initialized
INFO - 2024-12-19 14:19:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:19:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:19:54 --> Final output sent to browser
DEBUG - 2024-12-19 14:19:54 --> Total execution time: 0.0432
INFO - 2024-12-19 14:21:03 --> Config Class Initialized
INFO - 2024-12-19 14:21:03 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:21:03 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:21:03 --> Utf8 Class Initialized
INFO - 2024-12-19 14:21:03 --> URI Class Initialized
INFO - 2024-12-19 14:21:03 --> Router Class Initialized
INFO - 2024-12-19 14:21:03 --> Output Class Initialized
INFO - 2024-12-19 14:21:03 --> Security Class Initialized
DEBUG - 2024-12-19 14:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:21:03 --> Input Class Initialized
INFO - 2024-12-19 14:21:03 --> Language Class Initialized
INFO - 2024-12-19 14:21:03 --> Loader Class Initialized
INFO - 2024-12-19 14:21:03 --> Helper loaded: url_helper
INFO - 2024-12-19 14:21:03 --> Helper loaded: form_helper
INFO - 2024-12-19 14:21:03 --> Helper loaded: file_helper
INFO - 2024-12-19 14:21:03 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:21:03 --> Form Validation Class Initialized
INFO - 2024-12-19 14:21:03 --> Upload Class Initialized
INFO - 2024-12-19 14:21:03 --> Model "M_login" initialized
INFO - 2024-12-19 14:21:03 --> Model "M_home" initialized
INFO - 2024-12-19 14:21:03 --> Model "M_setting" initialized
INFO - 2024-12-19 14:21:03 --> Controller Class Initialized
INFO - 2024-12-19 14:21:03 --> Model "M_guru" initialized
INFO - 2024-12-19 14:21:03 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:21:03 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:21:03 --> Final output sent to browser
DEBUG - 2024-12-19 14:21:03 --> Total execution time: 0.0496
INFO - 2024-12-19 14:21:04 --> Config Class Initialized
INFO - 2024-12-19 14:21:04 --> Hooks Class Initialized
INFO - 2024-12-19 14:21:04 --> Config Class Initialized
INFO - 2024-12-19 14:21:04 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:21:04 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:21:04 --> Utf8 Class Initialized
DEBUG - 2024-12-19 14:21:04 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:21:04 --> Utf8 Class Initialized
INFO - 2024-12-19 14:21:04 --> URI Class Initialized
INFO - 2024-12-19 14:21:04 --> URI Class Initialized
INFO - 2024-12-19 14:21:04 --> Router Class Initialized
INFO - 2024-12-19 14:21:04 --> Router Class Initialized
INFO - 2024-12-19 14:21:04 --> Output Class Initialized
INFO - 2024-12-19 14:21:04 --> Output Class Initialized
INFO - 2024-12-19 14:21:04 --> Config Class Initialized
INFO - 2024-12-19 14:21:04 --> Security Class Initialized
INFO - 2024-12-19 14:21:04 --> Security Class Initialized
INFO - 2024-12-19 14:21:04 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:21:04 --> Input Class Initialized
DEBUG - 2024-12-19 14:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:21:04 --> Input Class Initialized
INFO - 2024-12-19 14:21:04 --> Language Class Initialized
INFO - 2024-12-19 14:21:04 --> Language Class Initialized
DEBUG - 2024-12-19 14:21:04 --> UTF-8 Support Enabled
ERROR - 2024-12-19 14:21:04 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 14:21:04 --> Utf8 Class Initialized
ERROR - 2024-12-19 14:21:04 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 14:21:04 --> URI Class Initialized
INFO - 2024-12-19 14:21:04 --> Router Class Initialized
INFO - 2024-12-19 14:21:04 --> Output Class Initialized
INFO - 2024-12-19 14:21:04 --> Security Class Initialized
DEBUG - 2024-12-19 14:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:21:04 --> Input Class Initialized
INFO - 2024-12-19 14:21:04 --> Language Class Initialized
ERROR - 2024-12-19 14:21:04 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 14:21:07 --> Config Class Initialized
INFO - 2024-12-19 14:21:07 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:21:07 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:21:07 --> Utf8 Class Initialized
INFO - 2024-12-19 14:21:08 --> URI Class Initialized
INFO - 2024-12-19 14:21:08 --> Router Class Initialized
INFO - 2024-12-19 14:21:08 --> Output Class Initialized
INFO - 2024-12-19 14:21:08 --> Security Class Initialized
DEBUG - 2024-12-19 14:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:21:08 --> Input Class Initialized
INFO - 2024-12-19 14:21:08 --> Language Class Initialized
ERROR - 2024-12-19 14:21:08 --> 404 Page Not Found: Galeri/index
INFO - 2024-12-19 14:22:09 --> Config Class Initialized
INFO - 2024-12-19 14:22:09 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:22:09 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:22:09 --> Utf8 Class Initialized
INFO - 2024-12-19 14:22:09 --> URI Class Initialized
DEBUG - 2024-12-19 14:22:09 --> No URI present. Default controller set.
INFO - 2024-12-19 14:22:09 --> Router Class Initialized
INFO - 2024-12-19 14:22:09 --> Output Class Initialized
INFO - 2024-12-19 14:22:09 --> Security Class Initialized
DEBUG - 2024-12-19 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:22:09 --> Input Class Initialized
INFO - 2024-12-19 14:22:09 --> Language Class Initialized
INFO - 2024-12-19 14:22:09 --> Loader Class Initialized
INFO - 2024-12-19 14:22:09 --> Helper loaded: url_helper
INFO - 2024-12-19 14:22:09 --> Helper loaded: form_helper
INFO - 2024-12-19 14:22:09 --> Helper loaded: file_helper
INFO - 2024-12-19 14:22:09 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:22:09 --> Form Validation Class Initialized
INFO - 2024-12-19 14:22:09 --> Upload Class Initialized
INFO - 2024-12-19 14:22:09 --> Model "M_login" initialized
INFO - 2024-12-19 14:22:09 --> Model "M_home" initialized
INFO - 2024-12-19 14:22:09 --> Model "M_setting" initialized
INFO - 2024-12-19 14:22:09 --> Controller Class Initialized
INFO - 2024-12-19 14:22:09 --> Model "M_guru" initialized
INFO - 2024-12-19 14:22:09 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:22:09 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:22:09 --> Final output sent to browser
DEBUG - 2024-12-19 14:22:09 --> Total execution time: 0.0496
INFO - 2024-12-19 14:22:09 --> Config Class Initialized
INFO - 2024-12-19 14:22:09 --> Hooks Class Initialized
INFO - 2024-12-19 14:22:09 --> Config Class Initialized
INFO - 2024-12-19 14:22:09 --> Hooks Class Initialized
INFO - 2024-12-19 14:22:09 --> Config Class Initialized
INFO - 2024-12-19 14:22:09 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:22:09 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:22:09 --> Utf8 Class Initialized
DEBUG - 2024-12-19 14:22:09 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:22:09 --> URI Class Initialized
INFO - 2024-12-19 14:22:09 --> Utf8 Class Initialized
DEBUG - 2024-12-19 14:22:09 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:22:09 --> Utf8 Class Initialized
INFO - 2024-12-19 14:22:09 --> URI Class Initialized
INFO - 2024-12-19 14:22:09 --> URI Class Initialized
INFO - 2024-12-19 14:22:09 --> Router Class Initialized
INFO - 2024-12-19 14:22:09 --> Router Class Initialized
INFO - 2024-12-19 14:22:09 --> Output Class Initialized
INFO - 2024-12-19 14:22:09 --> Router Class Initialized
INFO - 2024-12-19 14:22:09 --> Output Class Initialized
INFO - 2024-12-19 14:22:09 --> Security Class Initialized
INFO - 2024-12-19 14:22:09 --> Output Class Initialized
INFO - 2024-12-19 14:22:09 --> Security Class Initialized
DEBUG - 2024-12-19 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:22:09 --> Input Class Initialized
INFO - 2024-12-19 14:22:09 --> Security Class Initialized
DEBUG - 2024-12-19 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:22:09 --> Input Class Initialized
INFO - 2024-12-19 14:22:09 --> Language Class Initialized
INFO - 2024-12-19 14:22:09 --> Language Class Initialized
DEBUG - 2024-12-19 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:22:09 --> Input Class Initialized
ERROR - 2024-12-19 14:22:09 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 14:22:09 --> Language Class Initialized
ERROR - 2024-12-19 14:22:09 --> 404 Page Not Found: Images/newsletter.jpg
ERROR - 2024-12-19 14:22:09 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 14:22:34 --> Config Class Initialized
INFO - 2024-12-19 14:22:34 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:22:34 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:22:34 --> Utf8 Class Initialized
INFO - 2024-12-19 14:22:34 --> URI Class Initialized
INFO - 2024-12-19 14:22:34 --> Router Class Initialized
INFO - 2024-12-19 14:22:34 --> Output Class Initialized
INFO - 2024-12-19 14:22:34 --> Security Class Initialized
DEBUG - 2024-12-19 14:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:22:34 --> Input Class Initialized
INFO - 2024-12-19 14:22:34 --> Language Class Initialized
ERROR - 2024-12-19 14:22:34 --> 404 Page Not Found: Template/front-end
INFO - 2024-12-19 14:25:49 --> Config Class Initialized
INFO - 2024-12-19 14:25:49 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:25:49 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:25:49 --> Utf8 Class Initialized
INFO - 2024-12-19 14:25:49 --> URI Class Initialized
INFO - 2024-12-19 14:25:49 --> Router Class Initialized
INFO - 2024-12-19 14:25:49 --> Output Class Initialized
INFO - 2024-12-19 14:25:49 --> Security Class Initialized
DEBUG - 2024-12-19 14:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:25:49 --> Input Class Initialized
INFO - 2024-12-19 14:25:49 --> Language Class Initialized
INFO - 2024-12-19 14:25:49 --> Loader Class Initialized
INFO - 2024-12-19 14:25:49 --> Helper loaded: url_helper
INFO - 2024-12-19 14:25:49 --> Helper loaded: form_helper
INFO - 2024-12-19 14:25:49 --> Helper loaded: file_helper
INFO - 2024-12-19 14:25:49 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:25:49 --> Form Validation Class Initialized
INFO - 2024-12-19 14:25:49 --> Upload Class Initialized
INFO - 2024-12-19 14:25:49 --> Model "M_login" initialized
INFO - 2024-12-19 14:25:49 --> Model "M_home" initialized
INFO - 2024-12-19 14:25:49 --> Model "M_setting" initialized
INFO - 2024-12-19 14:25:49 --> Controller Class Initialized
INFO - 2024-12-19 14:25:49 --> Model "M_guru" initialized
INFO - 2024-12-19 14:25:49 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:25:49 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:25:49 --> Final output sent to browser
DEBUG - 2024-12-19 14:25:49 --> Total execution time: 0.1265
INFO - 2024-12-19 14:25:53 --> Config Class Initialized
INFO - 2024-12-19 14:25:53 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:25:53 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:25:53 --> Utf8 Class Initialized
INFO - 2024-12-19 14:25:53 --> URI Class Initialized
INFO - 2024-12-19 14:25:53 --> Router Class Initialized
INFO - 2024-12-19 14:25:53 --> Output Class Initialized
INFO - 2024-12-19 14:25:53 --> Security Class Initialized
DEBUG - 2024-12-19 14:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:25:53 --> Input Class Initialized
INFO - 2024-12-19 14:25:53 --> Language Class Initialized
INFO - 2024-12-19 14:25:53 --> Loader Class Initialized
INFO - 2024-12-19 14:25:53 --> Helper loaded: url_helper
INFO - 2024-12-19 14:25:53 --> Helper loaded: form_helper
INFO - 2024-12-19 14:25:53 --> Helper loaded: file_helper
INFO - 2024-12-19 14:25:53 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:25:53 --> Form Validation Class Initialized
INFO - 2024-12-19 14:25:53 --> Upload Class Initialized
INFO - 2024-12-19 14:25:53 --> Model "M_login" initialized
INFO - 2024-12-19 14:25:53 --> Model "M_home" initialized
INFO - 2024-12-19 14:25:53 --> Model "M_setting" initialized
INFO - 2024-12-19 14:25:53 --> Controller Class Initialized
INFO - 2024-12-19 14:25:53 --> Model "M_guru" initialized
INFO - 2024-12-19 14:25:53 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:25:53 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:25:53 --> Final output sent to browser
DEBUG - 2024-12-19 14:25:53 --> Total execution time: 0.0617
INFO - 2024-12-19 14:25:53 --> Config Class Initialized
INFO - 2024-12-19 14:25:53 --> Hooks Class Initialized
INFO - 2024-12-19 14:25:53 --> Config Class Initialized
INFO - 2024-12-19 14:25:53 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:25:53 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:25:53 --> Utf8 Class Initialized
DEBUG - 2024-12-19 14:25:53 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:25:53 --> Utf8 Class Initialized
INFO - 2024-12-19 14:25:53 --> Config Class Initialized
INFO - 2024-12-19 14:25:53 --> URI Class Initialized
INFO - 2024-12-19 14:25:53 --> Hooks Class Initialized
INFO - 2024-12-19 14:25:53 --> URI Class Initialized
INFO - 2024-12-19 14:25:53 --> Router Class Initialized
INFO - 2024-12-19 14:25:53 --> Router Class Initialized
DEBUG - 2024-12-19 14:25:53 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:25:53 --> Output Class Initialized
INFO - 2024-12-19 14:25:53 --> Utf8 Class Initialized
INFO - 2024-12-19 14:25:53 --> Output Class Initialized
INFO - 2024-12-19 14:25:53 --> URI Class Initialized
INFO - 2024-12-19 14:25:53 --> Security Class Initialized
INFO - 2024-12-19 14:25:53 --> Security Class Initialized
DEBUG - 2024-12-19 14:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:25:53 --> Input Class Initialized
DEBUG - 2024-12-19 14:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:25:53 --> Input Class Initialized
INFO - 2024-12-19 14:25:53 --> Language Class Initialized
INFO - 2024-12-19 14:25:53 --> Language Class Initialized
INFO - 2024-12-19 14:25:53 --> Router Class Initialized
ERROR - 2024-12-19 14:25:53 --> 404 Page Not Found: Images/courses_background.jpg
ERROR - 2024-12-19 14:25:53 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 14:25:53 --> Output Class Initialized
INFO - 2024-12-19 14:25:53 --> Security Class Initialized
DEBUG - 2024-12-19 14:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:25:53 --> Input Class Initialized
INFO - 2024-12-19 14:25:53 --> Language Class Initialized
ERROR - 2024-12-19 14:25:53 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 14:25:56 --> Config Class Initialized
INFO - 2024-12-19 14:25:56 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:25:56 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:25:56 --> Utf8 Class Initialized
INFO - 2024-12-19 14:25:56 --> URI Class Initialized
INFO - 2024-12-19 14:25:56 --> Router Class Initialized
INFO - 2024-12-19 14:25:56 --> Output Class Initialized
INFO - 2024-12-19 14:25:56 --> Security Class Initialized
DEBUG - 2024-12-19 14:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:25:56 --> Input Class Initialized
INFO - 2024-12-19 14:25:56 --> Language Class Initialized
INFO - 2024-12-19 14:25:56 --> Loader Class Initialized
INFO - 2024-12-19 14:25:56 --> Helper loaded: url_helper
INFO - 2024-12-19 14:25:56 --> Helper loaded: form_helper
INFO - 2024-12-19 14:25:56 --> Helper loaded: file_helper
INFO - 2024-12-19 14:25:56 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:25:56 --> Form Validation Class Initialized
INFO - 2024-12-19 14:25:56 --> Upload Class Initialized
INFO - 2024-12-19 14:25:56 --> Model "M_login" initialized
INFO - 2024-12-19 14:25:56 --> Model "M_home" initialized
INFO - 2024-12-19 14:25:56 --> Model "M_setting" initialized
INFO - 2024-12-19 14:25:56 --> Controller Class Initialized
INFO - 2024-12-19 14:25:56 --> Model "M_guru" initialized
INFO - 2024-12-19 14:25:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-19 14:25:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:25:56 --> Final output sent to browser
DEBUG - 2024-12-19 14:25:56 --> Total execution time: 0.0716
INFO - 2024-12-19 14:25:58 --> Config Class Initialized
INFO - 2024-12-19 14:25:58 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:25:58 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:25:58 --> Utf8 Class Initialized
INFO - 2024-12-19 14:25:58 --> URI Class Initialized
INFO - 2024-12-19 14:25:58 --> Router Class Initialized
INFO - 2024-12-19 14:25:58 --> Output Class Initialized
INFO - 2024-12-19 14:25:58 --> Security Class Initialized
DEBUG - 2024-12-19 14:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:25:58 --> Input Class Initialized
INFO - 2024-12-19 14:25:58 --> Language Class Initialized
INFO - 2024-12-19 14:25:58 --> Loader Class Initialized
INFO - 2024-12-19 14:25:58 --> Helper loaded: url_helper
INFO - 2024-12-19 14:25:58 --> Helper loaded: form_helper
INFO - 2024-12-19 14:25:58 --> Helper loaded: file_helper
INFO - 2024-12-19 14:25:58 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:25:58 --> Form Validation Class Initialized
INFO - 2024-12-19 14:25:58 --> Upload Class Initialized
INFO - 2024-12-19 14:25:58 --> Model "M_login" initialized
INFO - 2024-12-19 14:25:58 --> Model "M_home" initialized
INFO - 2024-12-19 14:25:58 --> Model "M_setting" initialized
INFO - 2024-12-19 14:25:58 --> Controller Class Initialized
INFO - 2024-12-19 14:25:58 --> Model "M_guru" initialized
INFO - 2024-12-19 14:25:58 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:25:58 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:25:58 --> Final output sent to browser
DEBUG - 2024-12-19 14:25:58 --> Total execution time: 0.1242
INFO - 2024-12-19 14:26:06 --> Config Class Initialized
INFO - 2024-12-19 14:26:06 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:26:06 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:26:06 --> Utf8 Class Initialized
INFO - 2024-12-19 14:26:06 --> URI Class Initialized
INFO - 2024-12-19 14:26:06 --> Router Class Initialized
INFO - 2024-12-19 14:26:06 --> Output Class Initialized
INFO - 2024-12-19 14:26:06 --> Security Class Initialized
DEBUG - 2024-12-19 14:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:26:06 --> Input Class Initialized
INFO - 2024-12-19 14:26:06 --> Language Class Initialized
INFO - 2024-12-19 14:26:06 --> Loader Class Initialized
INFO - 2024-12-19 14:26:06 --> Helper loaded: url_helper
INFO - 2024-12-19 14:26:06 --> Helper loaded: form_helper
INFO - 2024-12-19 14:26:06 --> Helper loaded: file_helper
INFO - 2024-12-19 14:26:06 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:26:06 --> Form Validation Class Initialized
INFO - 2024-12-19 14:26:06 --> Upload Class Initialized
INFO - 2024-12-19 14:26:06 --> Model "M_login" initialized
INFO - 2024-12-19 14:26:06 --> Model "M_home" initialized
INFO - 2024-12-19 14:26:06 --> Model "M_setting" initialized
INFO - 2024-12-19 14:26:06 --> Controller Class Initialized
INFO - 2024-12-19 14:26:06 --> Model "M_guru" initialized
INFO - 2024-12-19 14:26:06 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-19 14:26:06 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:26:06 --> Final output sent to browser
DEBUG - 2024-12-19 14:26:06 --> Total execution time: 0.1039
INFO - 2024-12-19 14:26:09 --> Config Class Initialized
INFO - 2024-12-19 14:26:09 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:26:09 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:26:09 --> Utf8 Class Initialized
INFO - 2024-12-19 14:26:09 --> URI Class Initialized
INFO - 2024-12-19 14:26:09 --> Router Class Initialized
INFO - 2024-12-19 14:26:09 --> Output Class Initialized
INFO - 2024-12-19 14:26:09 --> Security Class Initialized
DEBUG - 2024-12-19 14:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:26:09 --> Input Class Initialized
INFO - 2024-12-19 14:26:09 --> Language Class Initialized
INFO - 2024-12-19 14:26:09 --> Loader Class Initialized
INFO - 2024-12-19 14:26:09 --> Helper loaded: url_helper
INFO - 2024-12-19 14:26:09 --> Helper loaded: form_helper
INFO - 2024-12-19 14:26:09 --> Helper loaded: file_helper
INFO - 2024-12-19 14:26:09 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:26:09 --> Form Validation Class Initialized
INFO - 2024-12-19 14:26:09 --> Upload Class Initialized
INFO - 2024-12-19 14:26:09 --> Model "M_login" initialized
INFO - 2024-12-19 14:26:09 --> Model "M_home" initialized
INFO - 2024-12-19 14:26:09 --> Model "M_setting" initialized
INFO - 2024-12-19 14:26:09 --> Controller Class Initialized
INFO - 2024-12-19 14:26:09 --> Model "M_guru" initialized
INFO - 2024-12-19 14:26:09 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-19 14:26:09 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:26:09 --> Final output sent to browser
DEBUG - 2024-12-19 14:26:09 --> Total execution time: 0.1001
INFO - 2024-12-19 14:27:05 --> Config Class Initialized
INFO - 2024-12-19 14:27:05 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:27:05 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:27:05 --> Utf8 Class Initialized
INFO - 2024-12-19 14:27:05 --> URI Class Initialized
INFO - 2024-12-19 14:27:05 --> Router Class Initialized
INFO - 2024-12-19 14:27:05 --> Output Class Initialized
INFO - 2024-12-19 14:27:05 --> Security Class Initialized
DEBUG - 2024-12-19 14:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:27:05 --> Input Class Initialized
INFO - 2024-12-19 14:27:05 --> Language Class Initialized
INFO - 2024-12-19 14:27:05 --> Loader Class Initialized
INFO - 2024-12-19 14:27:05 --> Helper loaded: url_helper
INFO - 2024-12-19 14:27:05 --> Helper loaded: form_helper
INFO - 2024-12-19 14:27:05 --> Helper loaded: file_helper
INFO - 2024-12-19 14:27:05 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:27:05 --> Form Validation Class Initialized
INFO - 2024-12-19 14:27:05 --> Upload Class Initialized
INFO - 2024-12-19 14:27:05 --> Model "M_login" initialized
INFO - 2024-12-19 14:27:05 --> Model "M_home" initialized
INFO - 2024-12-19 14:27:05 --> Model "M_setting" initialized
INFO - 2024-12-19 14:27:05 --> Controller Class Initialized
INFO - 2024-12-19 14:27:05 --> Model "M_guru" initialized
INFO - 2024-12-19 14:27:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-19 14:27:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:27:05 --> Final output sent to browser
DEBUG - 2024-12-19 14:27:05 --> Total execution time: 0.1184
INFO - 2024-12-19 14:27:10 --> Config Class Initialized
INFO - 2024-12-19 14:27:10 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:27:10 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:27:10 --> Utf8 Class Initialized
INFO - 2024-12-19 14:27:10 --> URI Class Initialized
INFO - 2024-12-19 14:27:10 --> Router Class Initialized
INFO - 2024-12-19 14:27:10 --> Output Class Initialized
INFO - 2024-12-19 14:27:10 --> Security Class Initialized
DEBUG - 2024-12-19 14:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:27:10 --> Input Class Initialized
INFO - 2024-12-19 14:27:10 --> Language Class Initialized
INFO - 2024-12-19 14:27:10 --> Loader Class Initialized
INFO - 2024-12-19 14:27:10 --> Helper loaded: url_helper
INFO - 2024-12-19 14:27:10 --> Helper loaded: form_helper
INFO - 2024-12-19 14:27:10 --> Helper loaded: file_helper
INFO - 2024-12-19 14:27:10 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:27:10 --> Form Validation Class Initialized
INFO - 2024-12-19 14:27:10 --> Upload Class Initialized
INFO - 2024-12-19 14:27:10 --> Model "M_login" initialized
INFO - 2024-12-19 14:27:10 --> Model "M_home" initialized
INFO - 2024-12-19 14:27:10 --> Model "M_setting" initialized
INFO - 2024-12-19 14:27:10 --> Controller Class Initialized
INFO - 2024-12-19 14:27:10 --> Model "M_guru" initialized
INFO - 2024-12-19 14:27:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:27:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:27:10 --> Final output sent to browser
DEBUG - 2024-12-19 14:27:10 --> Total execution time: 0.1356
INFO - 2024-12-19 14:27:26 --> Config Class Initialized
INFO - 2024-12-19 14:27:26 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:27:26 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:27:26 --> Utf8 Class Initialized
INFO - 2024-12-19 14:27:26 --> URI Class Initialized
INFO - 2024-12-19 14:27:26 --> Router Class Initialized
INFO - 2024-12-19 14:27:26 --> Output Class Initialized
INFO - 2024-12-19 14:27:26 --> Security Class Initialized
DEBUG - 2024-12-19 14:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:27:26 --> Input Class Initialized
INFO - 2024-12-19 14:27:26 --> Language Class Initialized
INFO - 2024-12-19 14:27:26 --> Loader Class Initialized
INFO - 2024-12-19 14:27:26 --> Helper loaded: url_helper
INFO - 2024-12-19 14:27:26 --> Helper loaded: form_helper
INFO - 2024-12-19 14:27:26 --> Helper loaded: file_helper
INFO - 2024-12-19 14:27:26 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:27:26 --> Form Validation Class Initialized
INFO - 2024-12-19 14:27:26 --> Upload Class Initialized
INFO - 2024-12-19 14:27:26 --> Model "M_login" initialized
INFO - 2024-12-19 14:27:26 --> Model "M_home" initialized
INFO - 2024-12-19 14:27:26 --> Model "M_setting" initialized
INFO - 2024-12-19 14:27:26 --> Controller Class Initialized
INFO - 2024-12-19 14:27:26 --> Model "M_guru" initialized
INFO - 2024-12-19 14:27:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-19 14:27:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:27:26 --> Final output sent to browser
DEBUG - 2024-12-19 14:27:26 --> Total execution time: 0.1232
INFO - 2024-12-19 14:27:33 --> Config Class Initialized
INFO - 2024-12-19 14:27:33 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:27:33 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:27:33 --> Utf8 Class Initialized
INFO - 2024-12-19 14:27:33 --> URI Class Initialized
INFO - 2024-12-19 14:27:33 --> Router Class Initialized
INFO - 2024-12-19 14:27:33 --> Output Class Initialized
INFO - 2024-12-19 14:27:33 --> Security Class Initialized
DEBUG - 2024-12-19 14:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:27:33 --> Input Class Initialized
INFO - 2024-12-19 14:27:33 --> Language Class Initialized
INFO - 2024-12-19 14:27:33 --> Loader Class Initialized
INFO - 2024-12-19 14:27:33 --> Helper loaded: url_helper
INFO - 2024-12-19 14:27:33 --> Helper loaded: form_helper
INFO - 2024-12-19 14:27:33 --> Helper loaded: file_helper
INFO - 2024-12-19 14:27:33 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:27:33 --> Form Validation Class Initialized
INFO - 2024-12-19 14:27:33 --> Upload Class Initialized
INFO - 2024-12-19 14:27:33 --> Model "M_login" initialized
INFO - 2024-12-19 14:27:33 --> Model "M_home" initialized
INFO - 2024-12-19 14:27:33 --> Model "M_setting" initialized
INFO - 2024-12-19 14:27:33 --> Controller Class Initialized
INFO - 2024-12-19 14:27:33 --> Model "M_guru" initialized
INFO - 2024-12-19 14:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 14:27:33 --> Pagination Class Initialized
INFO - 2024-12-19 14:27:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 14:27:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:27:33 --> Final output sent to browser
DEBUG - 2024-12-19 14:27:33 --> Total execution time: 0.1169
INFO - 2024-12-19 14:28:16 --> Config Class Initialized
INFO - 2024-12-19 14:28:16 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:28:16 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:28:16 --> Utf8 Class Initialized
INFO - 2024-12-19 14:28:17 --> URI Class Initialized
INFO - 2024-12-19 14:28:17 --> Router Class Initialized
INFO - 2024-12-19 14:28:17 --> Output Class Initialized
INFO - 2024-12-19 14:28:17 --> Security Class Initialized
DEBUG - 2024-12-19 14:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:28:17 --> Input Class Initialized
INFO - 2024-12-19 14:28:17 --> Language Class Initialized
ERROR - 2024-12-19 14:28:17 --> 404 Page Not Found: Home/index.html
INFO - 2024-12-19 14:29:23 --> Config Class Initialized
INFO - 2024-12-19 14:29:23 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:29:23 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:29:23 --> Utf8 Class Initialized
INFO - 2024-12-19 14:29:23 --> URI Class Initialized
INFO - 2024-12-19 14:29:23 --> Router Class Initialized
INFO - 2024-12-19 14:29:23 --> Output Class Initialized
INFO - 2024-12-19 14:29:23 --> Security Class Initialized
DEBUG - 2024-12-19 14:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:29:23 --> Input Class Initialized
INFO - 2024-12-19 14:29:23 --> Language Class Initialized
INFO - 2024-12-19 14:29:23 --> Loader Class Initialized
INFO - 2024-12-19 14:29:23 --> Helper loaded: url_helper
INFO - 2024-12-19 14:29:23 --> Helper loaded: form_helper
INFO - 2024-12-19 14:29:23 --> Helper loaded: file_helper
INFO - 2024-12-19 14:29:23 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:29:23 --> Form Validation Class Initialized
INFO - 2024-12-19 14:29:23 --> Upload Class Initialized
INFO - 2024-12-19 14:29:23 --> Model "M_login" initialized
INFO - 2024-12-19 14:29:23 --> Model "M_home" initialized
INFO - 2024-12-19 14:29:23 --> Model "M_setting" initialized
INFO - 2024-12-19 14:29:23 --> Controller Class Initialized
INFO - 2024-12-19 14:29:23 --> Model "M_guru" initialized
INFO - 2024-12-19 14:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 14:29:23 --> Pagination Class Initialized
INFO - 2024-12-19 14:29:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 14:29:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:29:23 --> Final output sent to browser
DEBUG - 2024-12-19 14:29:23 --> Total execution time: 0.1567
INFO - 2024-12-19 14:29:25 --> Config Class Initialized
INFO - 2024-12-19 14:29:25 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:29:25 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:29:25 --> Utf8 Class Initialized
INFO - 2024-12-19 14:29:25 --> URI Class Initialized
INFO - 2024-12-19 14:29:25 --> Router Class Initialized
INFO - 2024-12-19 14:29:25 --> Output Class Initialized
INFO - 2024-12-19 14:29:25 --> Security Class Initialized
DEBUG - 2024-12-19 14:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:29:25 --> Input Class Initialized
INFO - 2024-12-19 14:29:25 --> Language Class Initialized
INFO - 2024-12-19 14:29:25 --> Loader Class Initialized
INFO - 2024-12-19 14:29:25 --> Helper loaded: url_helper
INFO - 2024-12-19 14:29:25 --> Helper loaded: form_helper
INFO - 2024-12-19 14:29:25 --> Helper loaded: file_helper
INFO - 2024-12-19 14:29:25 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:29:25 --> Form Validation Class Initialized
INFO - 2024-12-19 14:29:25 --> Upload Class Initialized
INFO - 2024-12-19 14:29:25 --> Model "M_login" initialized
INFO - 2024-12-19 14:29:25 --> Model "M_home" initialized
INFO - 2024-12-19 14:29:25 --> Model "M_setting" initialized
INFO - 2024-12-19 14:29:25 --> Controller Class Initialized
INFO - 2024-12-19 14:29:25 --> Model "M_guru" initialized
INFO - 2024-12-19 14:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 14:29:25 --> Pagination Class Initialized
INFO - 2024-12-19 14:29:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 14:29:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:29:25 --> Final output sent to browser
DEBUG - 2024-12-19 14:29:25 --> Total execution time: 0.0728
INFO - 2024-12-19 14:30:21 --> Config Class Initialized
INFO - 2024-12-19 14:30:21 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:30:21 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:30:21 --> Utf8 Class Initialized
INFO - 2024-12-19 14:30:21 --> URI Class Initialized
INFO - 2024-12-19 14:30:21 --> Router Class Initialized
INFO - 2024-12-19 14:30:21 --> Output Class Initialized
INFO - 2024-12-19 14:30:21 --> Security Class Initialized
DEBUG - 2024-12-19 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:30:21 --> Input Class Initialized
INFO - 2024-12-19 14:30:21 --> Language Class Initialized
INFO - 2024-12-19 14:30:21 --> Loader Class Initialized
INFO - 2024-12-19 14:30:21 --> Helper loaded: url_helper
INFO - 2024-12-19 14:30:21 --> Helper loaded: form_helper
INFO - 2024-12-19 14:30:21 --> Helper loaded: file_helper
INFO - 2024-12-19 14:30:21 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:30:21 --> Form Validation Class Initialized
INFO - 2024-12-19 14:30:21 --> Upload Class Initialized
INFO - 2024-12-19 14:30:21 --> Model "M_login" initialized
INFO - 2024-12-19 14:30:21 --> Model "M_home" initialized
INFO - 2024-12-19 14:30:21 --> Model "M_setting" initialized
INFO - 2024-12-19 14:30:21 --> Controller Class Initialized
INFO - 2024-12-19 14:30:21 --> Model "M_guru" initialized
INFO - 2024-12-19 14:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 14:30:21 --> Pagination Class Initialized
INFO - 2024-12-19 14:30:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 14:30:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:30:21 --> Final output sent to browser
DEBUG - 2024-12-19 14:30:21 --> Total execution time: 0.1089
INFO - 2024-12-19 14:30:23 --> Config Class Initialized
INFO - 2024-12-19 14:30:23 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:30:23 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:30:23 --> Utf8 Class Initialized
INFO - 2024-12-19 14:30:23 --> URI Class Initialized
INFO - 2024-12-19 14:30:23 --> Router Class Initialized
INFO - 2024-12-19 14:30:23 --> Output Class Initialized
INFO - 2024-12-19 14:30:23 --> Security Class Initialized
DEBUG - 2024-12-19 14:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:30:23 --> Input Class Initialized
INFO - 2024-12-19 14:30:23 --> Language Class Initialized
INFO - 2024-12-19 14:30:23 --> Loader Class Initialized
INFO - 2024-12-19 14:30:23 --> Helper loaded: url_helper
INFO - 2024-12-19 14:30:23 --> Helper loaded: form_helper
INFO - 2024-12-19 14:30:23 --> Helper loaded: file_helper
INFO - 2024-12-19 14:30:23 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:30:23 --> Form Validation Class Initialized
INFO - 2024-12-19 14:30:23 --> Upload Class Initialized
INFO - 2024-12-19 14:30:23 --> Model "M_login" initialized
INFO - 2024-12-19 14:30:23 --> Model "M_home" initialized
INFO - 2024-12-19 14:30:23 --> Model "M_setting" initialized
INFO - 2024-12-19 14:30:23 --> Controller Class Initialized
INFO - 2024-12-19 14:30:23 --> Model "M_guru" initialized
INFO - 2024-12-19 14:30:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:30:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:30:23 --> Final output sent to browser
DEBUG - 2024-12-19 14:30:23 --> Total execution time: 0.0571
INFO - 2024-12-19 14:30:25 --> Config Class Initialized
INFO - 2024-12-19 14:30:25 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:30:25 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:30:25 --> Utf8 Class Initialized
INFO - 2024-12-19 14:30:25 --> URI Class Initialized
INFO - 2024-12-19 14:30:25 --> Router Class Initialized
INFO - 2024-12-19 14:30:25 --> Output Class Initialized
INFO - 2024-12-19 14:30:25 --> Security Class Initialized
DEBUG - 2024-12-19 14:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:30:25 --> Input Class Initialized
INFO - 2024-12-19 14:30:25 --> Language Class Initialized
ERROR - 2024-12-19 14:30:25 --> 404 Page Not Found: Home/tentang
INFO - 2024-12-19 14:31:06 --> Config Class Initialized
INFO - 2024-12-19 14:31:06 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:31:06 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:31:06 --> Utf8 Class Initialized
INFO - 2024-12-19 14:31:06 --> URI Class Initialized
INFO - 2024-12-19 14:31:06 --> Router Class Initialized
INFO - 2024-12-19 14:31:06 --> Output Class Initialized
INFO - 2024-12-19 14:31:06 --> Security Class Initialized
DEBUG - 2024-12-19 14:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:31:06 --> Input Class Initialized
INFO - 2024-12-19 14:31:06 --> Language Class Initialized
ERROR - 2024-12-19 14:31:06 --> 404 Page Not Found: Home/tentang
INFO - 2024-12-19 14:31:32 --> Config Class Initialized
INFO - 2024-12-19 14:31:32 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:31:32 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:31:32 --> Utf8 Class Initialized
INFO - 2024-12-19 14:31:32 --> URI Class Initialized
INFO - 2024-12-19 14:31:32 --> Router Class Initialized
INFO - 2024-12-19 14:31:32 --> Output Class Initialized
INFO - 2024-12-19 14:31:32 --> Security Class Initialized
DEBUG - 2024-12-19 14:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:31:32 --> Input Class Initialized
INFO - 2024-12-19 14:31:32 --> Language Class Initialized
INFO - 2024-12-19 14:31:32 --> Loader Class Initialized
INFO - 2024-12-19 14:31:32 --> Helper loaded: url_helper
INFO - 2024-12-19 14:31:32 --> Helper loaded: form_helper
INFO - 2024-12-19 14:31:32 --> Helper loaded: file_helper
INFO - 2024-12-19 14:31:32 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:31:32 --> Form Validation Class Initialized
INFO - 2024-12-19 14:31:32 --> Upload Class Initialized
INFO - 2024-12-19 14:31:32 --> Model "M_login" initialized
INFO - 2024-12-19 14:31:32 --> Model "M_home" initialized
INFO - 2024-12-19 14:31:32 --> Model "M_setting" initialized
INFO - 2024-12-19 14:31:32 --> Controller Class Initialized
INFO - 2024-12-19 14:31:32 --> Model "M_guru" initialized
INFO - 2024-12-19 14:31:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:31:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:31:32 --> Final output sent to browser
DEBUG - 2024-12-19 14:31:32 --> Total execution time: 0.1227
INFO - 2024-12-19 14:32:14 --> Config Class Initialized
INFO - 2024-12-19 14:32:14 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:32:14 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:32:14 --> Utf8 Class Initialized
INFO - 2024-12-19 14:32:14 --> URI Class Initialized
INFO - 2024-12-19 14:32:14 --> Router Class Initialized
INFO - 2024-12-19 14:32:14 --> Output Class Initialized
INFO - 2024-12-19 14:32:14 --> Security Class Initialized
DEBUG - 2024-12-19 14:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:32:14 --> Input Class Initialized
INFO - 2024-12-19 14:32:14 --> Language Class Initialized
INFO - 2024-12-19 14:32:14 --> Loader Class Initialized
INFO - 2024-12-19 14:32:14 --> Helper loaded: url_helper
INFO - 2024-12-19 14:32:14 --> Helper loaded: form_helper
INFO - 2024-12-19 14:32:14 --> Helper loaded: file_helper
INFO - 2024-12-19 14:32:14 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:32:14 --> Form Validation Class Initialized
INFO - 2024-12-19 14:32:14 --> Upload Class Initialized
INFO - 2024-12-19 14:32:14 --> Model "M_login" initialized
INFO - 2024-12-19 14:32:14 --> Model "M_home" initialized
INFO - 2024-12-19 14:32:14 --> Model "M_setting" initialized
INFO - 2024-12-19 14:32:14 --> Controller Class Initialized
INFO - 2024-12-19 14:32:14 --> Model "M_guru" initialized
INFO - 2024-12-19 14:32:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:32:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:32:14 --> Final output sent to browser
DEBUG - 2024-12-19 14:32:14 --> Total execution time: 0.0897
INFO - 2024-12-19 14:32:56 --> Config Class Initialized
INFO - 2024-12-19 14:32:56 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:32:56 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:32:56 --> Utf8 Class Initialized
INFO - 2024-12-19 14:32:56 --> URI Class Initialized
INFO - 2024-12-19 14:32:56 --> Router Class Initialized
INFO - 2024-12-19 14:32:56 --> Output Class Initialized
INFO - 2024-12-19 14:32:56 --> Security Class Initialized
DEBUG - 2024-12-19 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:32:56 --> Input Class Initialized
INFO - 2024-12-19 14:32:56 --> Language Class Initialized
INFO - 2024-12-19 14:32:56 --> Loader Class Initialized
INFO - 2024-12-19 14:32:56 --> Helper loaded: url_helper
INFO - 2024-12-19 14:32:56 --> Helper loaded: form_helper
INFO - 2024-12-19 14:32:56 --> Helper loaded: file_helper
INFO - 2024-12-19 14:32:56 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:32:56 --> Form Validation Class Initialized
INFO - 2024-12-19 14:32:56 --> Upload Class Initialized
INFO - 2024-12-19 14:32:56 --> Model "M_login" initialized
INFO - 2024-12-19 14:32:56 --> Model "M_home" initialized
INFO - 2024-12-19 14:32:56 --> Model "M_setting" initialized
INFO - 2024-12-19 14:32:56 --> Controller Class Initialized
INFO - 2024-12-19 14:32:56 --> Model "M_guru" initialized
INFO - 2024-12-19 14:32:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:32:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:32:56 --> Final output sent to browser
DEBUG - 2024-12-19 14:32:56 --> Total execution time: 0.1294
INFO - 2024-12-19 14:33:21 --> Config Class Initialized
INFO - 2024-12-19 14:33:21 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:33:21 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:21 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:21 --> URI Class Initialized
INFO - 2024-12-19 14:33:21 --> Router Class Initialized
INFO - 2024-12-19 14:33:21 --> Output Class Initialized
INFO - 2024-12-19 14:33:21 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:21 --> Input Class Initialized
INFO - 2024-12-19 14:33:21 --> Language Class Initialized
INFO - 2024-12-19 14:33:21 --> Loader Class Initialized
INFO - 2024-12-19 14:33:21 --> Helper loaded: url_helper
INFO - 2024-12-19 14:33:21 --> Helper loaded: form_helper
INFO - 2024-12-19 14:33:21 --> Helper loaded: file_helper
INFO - 2024-12-19 14:33:21 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:33:21 --> Form Validation Class Initialized
INFO - 2024-12-19 14:33:21 --> Upload Class Initialized
INFO - 2024-12-19 14:33:21 --> Model "M_login" initialized
INFO - 2024-12-19 14:33:21 --> Model "M_home" initialized
INFO - 2024-12-19 14:33:21 --> Model "M_setting" initialized
INFO - 2024-12-19 14:33:21 --> Controller Class Initialized
INFO - 2024-12-19 14:33:21 --> Model "M_guru" initialized
INFO - 2024-12-19 14:33:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:33:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:33:21 --> Final output sent to browser
DEBUG - 2024-12-19 14:33:21 --> Total execution time: 0.0904
INFO - 2024-12-19 14:33:26 --> Config Class Initialized
INFO - 2024-12-19 14:33:26 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:33:26 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:26 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:26 --> URI Class Initialized
INFO - 2024-12-19 14:33:26 --> Router Class Initialized
INFO - 2024-12-19 14:33:26 --> Output Class Initialized
INFO - 2024-12-19 14:33:26 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:26 --> Input Class Initialized
INFO - 2024-12-19 14:33:26 --> Language Class Initialized
INFO - 2024-12-19 14:33:26 --> Loader Class Initialized
INFO - 2024-12-19 14:33:26 --> Helper loaded: url_helper
INFO - 2024-12-19 14:33:26 --> Helper loaded: form_helper
INFO - 2024-12-19 14:33:26 --> Helper loaded: file_helper
INFO - 2024-12-19 14:33:26 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:33:26 --> Form Validation Class Initialized
INFO - 2024-12-19 14:33:26 --> Upload Class Initialized
INFO - 2024-12-19 14:33:26 --> Model "M_login" initialized
INFO - 2024-12-19 14:33:26 --> Model "M_home" initialized
INFO - 2024-12-19 14:33:26 --> Model "M_setting" initialized
INFO - 2024-12-19 14:33:26 --> Controller Class Initialized
INFO - 2024-12-19 14:33:26 --> Model "M_guru" initialized
INFO - 2024-12-19 14:33:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:33:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:33:26 --> Final output sent to browser
DEBUG - 2024-12-19 14:33:26 --> Total execution time: 0.1271
INFO - 2024-12-19 14:33:27 --> Config Class Initialized
INFO - 2024-12-19 14:33:27 --> Config Class Initialized
INFO - 2024-12-19 14:33:27 --> Hooks Class Initialized
INFO - 2024-12-19 14:33:27 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:33:27 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:27 --> Utf8 Class Initialized
DEBUG - 2024-12-19 14:33:27 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:27 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:27 --> URI Class Initialized
INFO - 2024-12-19 14:33:27 --> URI Class Initialized
INFO - 2024-12-19 14:33:27 --> Router Class Initialized
INFO - 2024-12-19 14:33:27 --> Router Class Initialized
INFO - 2024-12-19 14:33:27 --> Config Class Initialized
INFO - 2024-12-19 14:33:27 --> Hooks Class Initialized
INFO - 2024-12-19 14:33:27 --> Output Class Initialized
INFO - 2024-12-19 14:33:27 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-19 14:33:27 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:27 --> Input Class Initialized
INFO - 2024-12-19 14:33:27 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:27 --> Language Class Initialized
ERROR - 2024-12-19 14:33:27 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 14:33:27 --> URI Class Initialized
INFO - 2024-12-19 14:33:27 --> Router Class Initialized
INFO - 2024-12-19 14:33:27 --> Output Class Initialized
INFO - 2024-12-19 14:33:27 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:27 --> Input Class Initialized
INFO - 2024-12-19 14:33:27 --> Language Class Initialized
ERROR - 2024-12-19 14:33:27 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 14:33:27 --> Output Class Initialized
INFO - 2024-12-19 14:33:27 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:27 --> Input Class Initialized
INFO - 2024-12-19 14:33:27 --> Language Class Initialized
ERROR - 2024-12-19 14:33:27 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 14:33:30 --> Config Class Initialized
INFO - 2024-12-19 14:33:30 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:33:30 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:30 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:30 --> URI Class Initialized
INFO - 2024-12-19 14:33:30 --> Router Class Initialized
INFO - 2024-12-19 14:33:30 --> Output Class Initialized
INFO - 2024-12-19 14:33:30 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:30 --> Input Class Initialized
INFO - 2024-12-19 14:33:30 --> Language Class Initialized
INFO - 2024-12-19 14:33:30 --> Loader Class Initialized
INFO - 2024-12-19 14:33:30 --> Helper loaded: url_helper
INFO - 2024-12-19 14:33:30 --> Helper loaded: form_helper
INFO - 2024-12-19 14:33:30 --> Helper loaded: file_helper
INFO - 2024-12-19 14:33:30 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:33:30 --> Form Validation Class Initialized
INFO - 2024-12-19 14:33:30 --> Upload Class Initialized
INFO - 2024-12-19 14:33:30 --> Model "M_login" initialized
INFO - 2024-12-19 14:33:30 --> Model "M_home" initialized
INFO - 2024-12-19 14:33:30 --> Model "M_setting" initialized
INFO - 2024-12-19 14:33:30 --> Controller Class Initialized
INFO - 2024-12-19 14:33:30 --> Model "M_guru" initialized
INFO - 2024-12-19 14:33:30 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:33:30 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:33:30 --> Final output sent to browser
DEBUG - 2024-12-19 14:33:30 --> Total execution time: 0.1232
INFO - 2024-12-19 14:33:37 --> Config Class Initialized
INFO - 2024-12-19 14:33:37 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:33:37 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:37 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:37 --> URI Class Initialized
INFO - 2024-12-19 14:33:37 --> Router Class Initialized
INFO - 2024-12-19 14:33:37 --> Output Class Initialized
INFO - 2024-12-19 14:33:37 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:37 --> Input Class Initialized
INFO - 2024-12-19 14:33:37 --> Language Class Initialized
INFO - 2024-12-19 14:33:37 --> Loader Class Initialized
INFO - 2024-12-19 14:33:37 --> Helper loaded: url_helper
INFO - 2024-12-19 14:33:37 --> Helper loaded: form_helper
INFO - 2024-12-19 14:33:37 --> Helper loaded: file_helper
INFO - 2024-12-19 14:33:37 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:33:37 --> Form Validation Class Initialized
INFO - 2024-12-19 14:33:37 --> Upload Class Initialized
INFO - 2024-12-19 14:33:37 --> Model "M_login" initialized
INFO - 2024-12-19 14:33:37 --> Model "M_home" initialized
INFO - 2024-12-19 14:33:37 --> Model "M_setting" initialized
INFO - 2024-12-19 14:33:37 --> Controller Class Initialized
INFO - 2024-12-19 14:33:37 --> Model "M_guru" initialized
INFO - 2024-12-19 14:33:37 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:33:37 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:33:37 --> Final output sent to browser
DEBUG - 2024-12-19 14:33:37 --> Total execution time: 0.1231
INFO - 2024-12-19 14:33:42 --> Config Class Initialized
INFO - 2024-12-19 14:33:42 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:33:42 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:42 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:42 --> URI Class Initialized
INFO - 2024-12-19 14:33:42 --> Router Class Initialized
INFO - 2024-12-19 14:33:42 --> Output Class Initialized
INFO - 2024-12-19 14:33:42 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:42 --> Input Class Initialized
INFO - 2024-12-19 14:33:42 --> Language Class Initialized
INFO - 2024-12-19 14:33:42 --> Loader Class Initialized
INFO - 2024-12-19 14:33:42 --> Helper loaded: url_helper
INFO - 2024-12-19 14:33:42 --> Helper loaded: form_helper
INFO - 2024-12-19 14:33:42 --> Helper loaded: file_helper
INFO - 2024-12-19 14:33:42 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:33:42 --> Form Validation Class Initialized
INFO - 2024-12-19 14:33:42 --> Upload Class Initialized
INFO - 2024-12-19 14:33:42 --> Model "M_login" initialized
INFO - 2024-12-19 14:33:42 --> Model "M_home" initialized
INFO - 2024-12-19 14:33:42 --> Model "M_setting" initialized
INFO - 2024-12-19 14:33:42 --> Controller Class Initialized
INFO - 2024-12-19 14:33:42 --> Model "M_guru" initialized
INFO - 2024-12-19 14:33:42 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:33:42 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:33:42 --> Final output sent to browser
DEBUG - 2024-12-19 14:33:42 --> Total execution time: 0.1234
INFO - 2024-12-19 14:33:55 --> Config Class Initialized
INFO - 2024-12-19 14:33:55 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:33:55 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:55 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:55 --> URI Class Initialized
INFO - 2024-12-19 14:33:55 --> Router Class Initialized
INFO - 2024-12-19 14:33:55 --> Output Class Initialized
INFO - 2024-12-19 14:33:55 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:55 --> Input Class Initialized
INFO - 2024-12-19 14:33:55 --> Language Class Initialized
INFO - 2024-12-19 14:33:55 --> Loader Class Initialized
INFO - 2024-12-19 14:33:55 --> Helper loaded: url_helper
INFO - 2024-12-19 14:33:55 --> Helper loaded: form_helper
INFO - 2024-12-19 14:33:55 --> Helper loaded: file_helper
INFO - 2024-12-19 14:33:55 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:33:55 --> Form Validation Class Initialized
INFO - 2024-12-19 14:33:55 --> Upload Class Initialized
INFO - 2024-12-19 14:33:55 --> Model "M_login" initialized
INFO - 2024-12-19 14:33:55 --> Model "M_home" initialized
INFO - 2024-12-19 14:33:55 --> Model "M_setting" initialized
INFO - 2024-12-19 14:33:55 --> Controller Class Initialized
INFO - 2024-12-19 14:33:55 --> Model "M_guru" initialized
INFO - 2024-12-19 14:33:55 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:33:55 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:33:55 --> Final output sent to browser
DEBUG - 2024-12-19 14:33:55 --> Total execution time: 0.1105
INFO - 2024-12-19 14:33:59 --> Config Class Initialized
INFO - 2024-12-19 14:33:59 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:33:59 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:33:59 --> Utf8 Class Initialized
INFO - 2024-12-19 14:33:59 --> URI Class Initialized
INFO - 2024-12-19 14:33:59 --> Router Class Initialized
INFO - 2024-12-19 14:33:59 --> Output Class Initialized
INFO - 2024-12-19 14:33:59 --> Security Class Initialized
DEBUG - 2024-12-19 14:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:33:59 --> Input Class Initialized
INFO - 2024-12-19 14:33:59 --> Language Class Initialized
ERROR - 2024-12-19 14:33:59 --> 404 Page Not Found: Home/tentang
INFO - 2024-12-19 14:34:10 --> Config Class Initialized
INFO - 2024-12-19 14:34:10 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:34:10 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:34:10 --> Utf8 Class Initialized
INFO - 2024-12-19 14:34:10 --> URI Class Initialized
INFO - 2024-12-19 14:34:10 --> Router Class Initialized
INFO - 2024-12-19 14:34:10 --> Output Class Initialized
INFO - 2024-12-19 14:34:10 --> Security Class Initialized
DEBUG - 2024-12-19 14:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:34:10 --> Input Class Initialized
INFO - 2024-12-19 14:34:10 --> Language Class Initialized
INFO - 2024-12-19 14:34:10 --> Loader Class Initialized
INFO - 2024-12-19 14:34:10 --> Helper loaded: url_helper
INFO - 2024-12-19 14:34:10 --> Helper loaded: form_helper
INFO - 2024-12-19 14:34:10 --> Helper loaded: file_helper
INFO - 2024-12-19 14:34:10 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:34:10 --> Form Validation Class Initialized
INFO - 2024-12-19 14:34:10 --> Upload Class Initialized
INFO - 2024-12-19 14:34:10 --> Model "M_login" initialized
INFO - 2024-12-19 14:34:10 --> Model "M_home" initialized
INFO - 2024-12-19 14:34:10 --> Model "M_setting" initialized
INFO - 2024-12-19 14:34:10 --> Controller Class Initialized
INFO - 2024-12-19 14:34:10 --> Model "M_guru" initialized
INFO - 2024-12-19 14:34:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:34:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:34:10 --> Final output sent to browser
DEBUG - 2024-12-19 14:34:10 --> Total execution time: 0.1351
INFO - 2024-12-19 14:35:16 --> Config Class Initialized
INFO - 2024-12-19 14:35:16 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:35:16 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:35:16 --> Utf8 Class Initialized
INFO - 2024-12-19 14:35:16 --> URI Class Initialized
INFO - 2024-12-19 14:35:16 --> Router Class Initialized
INFO - 2024-12-19 14:35:16 --> Output Class Initialized
INFO - 2024-12-19 14:35:16 --> Security Class Initialized
DEBUG - 2024-12-19 14:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:35:16 --> Input Class Initialized
INFO - 2024-12-19 14:35:16 --> Language Class Initialized
INFO - 2024-12-19 14:35:16 --> Loader Class Initialized
INFO - 2024-12-19 14:35:16 --> Helper loaded: url_helper
INFO - 2024-12-19 14:35:16 --> Helper loaded: form_helper
INFO - 2024-12-19 14:35:16 --> Helper loaded: file_helper
INFO - 2024-12-19 14:35:16 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:35:16 --> Form Validation Class Initialized
INFO - 2024-12-19 14:35:16 --> Upload Class Initialized
INFO - 2024-12-19 14:35:16 --> Model "M_login" initialized
INFO - 2024-12-19 14:35:16 --> Model "M_home" initialized
INFO - 2024-12-19 14:35:16 --> Model "M_setting" initialized
INFO - 2024-12-19 14:35:16 --> Controller Class Initialized
INFO - 2024-12-19 14:35:16 --> Model "M_guru" initialized
INFO - 2024-12-19 14:35:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:35:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:35:16 --> Final output sent to browser
DEBUG - 2024-12-19 14:35:16 --> Total execution time: 0.1008
INFO - 2024-12-19 14:35:24 --> Config Class Initialized
INFO - 2024-12-19 14:35:24 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:35:24 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:35:24 --> Utf8 Class Initialized
INFO - 2024-12-19 14:35:24 --> URI Class Initialized
INFO - 2024-12-19 14:35:24 --> Router Class Initialized
INFO - 2024-12-19 14:35:24 --> Output Class Initialized
INFO - 2024-12-19 14:35:24 --> Security Class Initialized
DEBUG - 2024-12-19 14:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:35:24 --> Input Class Initialized
INFO - 2024-12-19 14:35:24 --> Language Class Initialized
ERROR - 2024-12-19 14:35:24 --> 404 Page Not Found: Home/tentang
INFO - 2024-12-19 14:35:26 --> Config Class Initialized
INFO - 2024-12-19 14:35:26 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:35:26 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:35:26 --> Utf8 Class Initialized
INFO - 2024-12-19 14:35:26 --> URI Class Initialized
INFO - 2024-12-19 14:35:26 --> Router Class Initialized
INFO - 2024-12-19 14:35:26 --> Output Class Initialized
INFO - 2024-12-19 14:35:26 --> Security Class Initialized
DEBUG - 2024-12-19 14:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:35:26 --> Input Class Initialized
INFO - 2024-12-19 14:35:26 --> Language Class Initialized
INFO - 2024-12-19 14:35:26 --> Loader Class Initialized
INFO - 2024-12-19 14:35:26 --> Helper loaded: url_helper
INFO - 2024-12-19 14:35:26 --> Helper loaded: form_helper
INFO - 2024-12-19 14:35:26 --> Helper loaded: file_helper
INFO - 2024-12-19 14:35:26 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:35:26 --> Form Validation Class Initialized
INFO - 2024-12-19 14:35:26 --> Upload Class Initialized
INFO - 2024-12-19 14:35:26 --> Model "M_login" initialized
INFO - 2024-12-19 14:35:26 --> Model "M_home" initialized
INFO - 2024-12-19 14:35:26 --> Model "M_setting" initialized
INFO - 2024-12-19 14:35:26 --> Controller Class Initialized
INFO - 2024-12-19 14:35:26 --> Model "M_guru" initialized
INFO - 2024-12-19 14:35:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:35:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:35:26 --> Final output sent to browser
DEBUG - 2024-12-19 14:35:26 --> Total execution time: 0.1208
INFO - 2024-12-19 14:35:33 --> Config Class Initialized
INFO - 2024-12-19 14:35:33 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:35:33 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:35:33 --> Utf8 Class Initialized
INFO - 2024-12-19 14:35:33 --> URI Class Initialized
INFO - 2024-12-19 14:35:33 --> Router Class Initialized
INFO - 2024-12-19 14:35:33 --> Output Class Initialized
INFO - 2024-12-19 14:35:33 --> Security Class Initialized
DEBUG - 2024-12-19 14:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:35:33 --> Input Class Initialized
INFO - 2024-12-19 14:35:33 --> Language Class Initialized
INFO - 2024-12-19 14:35:33 --> Loader Class Initialized
INFO - 2024-12-19 14:35:33 --> Helper loaded: url_helper
INFO - 2024-12-19 14:35:33 --> Helper loaded: form_helper
INFO - 2024-12-19 14:35:33 --> Helper loaded: file_helper
INFO - 2024-12-19 14:35:33 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:35:33 --> Form Validation Class Initialized
INFO - 2024-12-19 14:35:33 --> Upload Class Initialized
INFO - 2024-12-19 14:35:33 --> Model "M_login" initialized
INFO - 2024-12-19 14:35:33 --> Model "M_home" initialized
INFO - 2024-12-19 14:35:33 --> Model "M_setting" initialized
INFO - 2024-12-19 14:35:33 --> Controller Class Initialized
INFO - 2024-12-19 14:35:33 --> Model "M_guru" initialized
INFO - 2024-12-19 14:35:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:35:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:35:33 --> Final output sent to browser
DEBUG - 2024-12-19 14:35:33 --> Total execution time: 0.1531
INFO - 2024-12-19 14:35:59 --> Config Class Initialized
INFO - 2024-12-19 14:35:59 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:35:59 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:35:59 --> Utf8 Class Initialized
INFO - 2024-12-19 14:35:59 --> URI Class Initialized
INFO - 2024-12-19 14:35:59 --> Router Class Initialized
INFO - 2024-12-19 14:35:59 --> Output Class Initialized
INFO - 2024-12-19 14:35:59 --> Security Class Initialized
DEBUG - 2024-12-19 14:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:35:59 --> Input Class Initialized
INFO - 2024-12-19 14:35:59 --> Language Class Initialized
ERROR - 2024-12-19 14:35:59 --> 404 Page Not Found: Home/tentang
INFO - 2024-12-19 14:36:02 --> Config Class Initialized
INFO - 2024-12-19 14:36:02 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:36:02 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:36:02 --> Utf8 Class Initialized
INFO - 2024-12-19 14:36:02 --> URI Class Initialized
INFO - 2024-12-19 14:36:02 --> Router Class Initialized
INFO - 2024-12-19 14:36:02 --> Output Class Initialized
INFO - 2024-12-19 14:36:02 --> Security Class Initialized
DEBUG - 2024-12-19 14:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:36:02 --> Input Class Initialized
INFO - 2024-12-19 14:36:02 --> Language Class Initialized
INFO - 2024-12-19 14:36:02 --> Loader Class Initialized
INFO - 2024-12-19 14:36:02 --> Helper loaded: url_helper
INFO - 2024-12-19 14:36:02 --> Helper loaded: form_helper
INFO - 2024-12-19 14:36:02 --> Helper loaded: file_helper
INFO - 2024-12-19 14:36:02 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:36:02 --> Form Validation Class Initialized
INFO - 2024-12-19 14:36:02 --> Upload Class Initialized
INFO - 2024-12-19 14:36:02 --> Model "M_login" initialized
INFO - 2024-12-19 14:36:02 --> Model "M_home" initialized
INFO - 2024-12-19 14:36:02 --> Model "M_setting" initialized
INFO - 2024-12-19 14:36:02 --> Controller Class Initialized
INFO - 2024-12-19 14:36:02 --> Model "M_guru" initialized
INFO - 2024-12-19 14:36:02 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:36:02 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:36:02 --> Final output sent to browser
DEBUG - 2024-12-19 14:36:02 --> Total execution time: 0.1416
INFO - 2024-12-19 14:36:17 --> Config Class Initialized
INFO - 2024-12-19 14:36:17 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:36:17 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:36:17 --> Utf8 Class Initialized
INFO - 2024-12-19 14:36:17 --> URI Class Initialized
INFO - 2024-12-19 14:36:17 --> Router Class Initialized
INFO - 2024-12-19 14:36:17 --> Output Class Initialized
INFO - 2024-12-19 14:36:17 --> Security Class Initialized
DEBUG - 2024-12-19 14:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:36:17 --> Input Class Initialized
INFO - 2024-12-19 14:36:17 --> Language Class Initialized
INFO - 2024-12-19 14:36:17 --> Loader Class Initialized
INFO - 2024-12-19 14:36:17 --> Helper loaded: url_helper
INFO - 2024-12-19 14:36:17 --> Helper loaded: form_helper
INFO - 2024-12-19 14:36:17 --> Helper loaded: file_helper
INFO - 2024-12-19 14:36:17 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:36:17 --> Form Validation Class Initialized
INFO - 2024-12-19 14:36:17 --> Upload Class Initialized
INFO - 2024-12-19 14:36:17 --> Model "M_login" initialized
INFO - 2024-12-19 14:36:17 --> Model "M_home" initialized
INFO - 2024-12-19 14:36:17 --> Model "M_setting" initialized
INFO - 2024-12-19 14:36:17 --> Controller Class Initialized
INFO - 2024-12-19 14:36:17 --> Model "M_guru" initialized
INFO - 2024-12-19 14:36:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:36:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:36:17 --> Final output sent to browser
DEBUG - 2024-12-19 14:36:17 --> Total execution time: 0.1240
INFO - 2024-12-19 14:36:21 --> Config Class Initialized
INFO - 2024-12-19 14:36:21 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:36:21 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:36:21 --> Utf8 Class Initialized
INFO - 2024-12-19 14:36:21 --> URI Class Initialized
INFO - 2024-12-19 14:36:21 --> Router Class Initialized
INFO - 2024-12-19 14:36:21 --> Output Class Initialized
INFO - 2024-12-19 14:36:21 --> Security Class Initialized
DEBUG - 2024-12-19 14:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:36:21 --> Input Class Initialized
INFO - 2024-12-19 14:36:21 --> Language Class Initialized
ERROR - 2024-12-19 14:36:21 --> 404 Page Not Found: Home/tentang
INFO - 2024-12-19 14:36:25 --> Config Class Initialized
INFO - 2024-12-19 14:36:25 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:36:25 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:36:25 --> Utf8 Class Initialized
INFO - 2024-12-19 14:36:25 --> URI Class Initialized
INFO - 2024-12-19 14:36:25 --> Router Class Initialized
INFO - 2024-12-19 14:36:25 --> Output Class Initialized
INFO - 2024-12-19 14:36:25 --> Security Class Initialized
DEBUG - 2024-12-19 14:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:36:25 --> Input Class Initialized
INFO - 2024-12-19 14:36:25 --> Language Class Initialized
INFO - 2024-12-19 14:36:25 --> Loader Class Initialized
INFO - 2024-12-19 14:36:25 --> Helper loaded: url_helper
INFO - 2024-12-19 14:36:25 --> Helper loaded: form_helper
INFO - 2024-12-19 14:36:25 --> Helper loaded: file_helper
INFO - 2024-12-19 14:36:25 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:36:25 --> Form Validation Class Initialized
INFO - 2024-12-19 14:36:25 --> Upload Class Initialized
INFO - 2024-12-19 14:36:25 --> Model "M_login" initialized
INFO - 2024-12-19 14:36:25 --> Model "M_home" initialized
INFO - 2024-12-19 14:36:25 --> Model "M_setting" initialized
INFO - 2024-12-19 14:36:25 --> Controller Class Initialized
INFO - 2024-12-19 14:36:25 --> Model "M_guru" initialized
INFO - 2024-12-19 14:36:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:36:25 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:36:25 --> Final output sent to browser
DEBUG - 2024-12-19 14:36:25 --> Total execution time: 0.1268
INFO - 2024-12-19 14:36:31 --> Config Class Initialized
INFO - 2024-12-19 14:36:31 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:36:31 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:36:31 --> Utf8 Class Initialized
INFO - 2024-12-19 14:36:31 --> URI Class Initialized
INFO - 2024-12-19 14:36:31 --> Router Class Initialized
INFO - 2024-12-19 14:36:31 --> Output Class Initialized
INFO - 2024-12-19 14:36:31 --> Security Class Initialized
DEBUG - 2024-12-19 14:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:36:31 --> Input Class Initialized
INFO - 2024-12-19 14:36:31 --> Language Class Initialized
INFO - 2024-12-19 14:36:31 --> Loader Class Initialized
INFO - 2024-12-19 14:36:31 --> Helper loaded: url_helper
INFO - 2024-12-19 14:36:31 --> Helper loaded: form_helper
INFO - 2024-12-19 14:36:31 --> Helper loaded: file_helper
INFO - 2024-12-19 14:36:31 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:36:31 --> Form Validation Class Initialized
INFO - 2024-12-19 14:36:31 --> Upload Class Initialized
INFO - 2024-12-19 14:36:31 --> Model "M_login" initialized
INFO - 2024-12-19 14:36:31 --> Model "M_home" initialized
INFO - 2024-12-19 14:36:31 --> Model "M_setting" initialized
INFO - 2024-12-19 14:36:31 --> Controller Class Initialized
INFO - 2024-12-19 14:36:31 --> Model "M_guru" initialized
INFO - 2024-12-19 14:36:31 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:36:31 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:36:31 --> Final output sent to browser
DEBUG - 2024-12-19 14:36:31 --> Total execution time: 0.1339
INFO - 2024-12-19 14:36:35 --> Config Class Initialized
INFO - 2024-12-19 14:36:35 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:36:35 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:36:35 --> Utf8 Class Initialized
INFO - 2024-12-19 14:36:35 --> URI Class Initialized
INFO - 2024-12-19 14:36:35 --> Router Class Initialized
INFO - 2024-12-19 14:36:35 --> Output Class Initialized
INFO - 2024-12-19 14:36:35 --> Security Class Initialized
DEBUG - 2024-12-19 14:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:36:35 --> Input Class Initialized
INFO - 2024-12-19 14:36:35 --> Language Class Initialized
INFO - 2024-12-19 14:36:35 --> Loader Class Initialized
INFO - 2024-12-19 14:36:35 --> Helper loaded: url_helper
INFO - 2024-12-19 14:36:35 --> Helper loaded: form_helper
INFO - 2024-12-19 14:36:35 --> Helper loaded: file_helper
INFO - 2024-12-19 14:36:35 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:36:35 --> Form Validation Class Initialized
INFO - 2024-12-19 14:36:35 --> Upload Class Initialized
INFO - 2024-12-19 14:36:35 --> Model "M_login" initialized
INFO - 2024-12-19 14:36:35 --> Model "M_home" initialized
INFO - 2024-12-19 14:36:35 --> Model "M_setting" initialized
INFO - 2024-12-19 14:36:35 --> Controller Class Initialized
INFO - 2024-12-19 14:36:35 --> Model "M_guru" initialized
INFO - 2024-12-19 14:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 14:36:35 --> Pagination Class Initialized
INFO - 2024-12-19 14:36:35 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 14:36:35 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:36:35 --> Final output sent to browser
DEBUG - 2024-12-19 14:36:35 --> Total execution time: 0.1408
INFO - 2024-12-19 14:37:41 --> Config Class Initialized
INFO - 2024-12-19 14:37:41 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:37:41 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:37:41 --> Utf8 Class Initialized
INFO - 2024-12-19 14:37:41 --> URI Class Initialized
INFO - 2024-12-19 14:37:41 --> Router Class Initialized
INFO - 2024-12-19 14:37:41 --> Output Class Initialized
INFO - 2024-12-19 14:37:41 --> Security Class Initialized
DEBUG - 2024-12-19 14:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:37:41 --> Input Class Initialized
INFO - 2024-12-19 14:37:41 --> Language Class Initialized
INFO - 2024-12-19 14:37:41 --> Loader Class Initialized
INFO - 2024-12-19 14:37:41 --> Helper loaded: url_helper
INFO - 2024-12-19 14:37:41 --> Helper loaded: form_helper
INFO - 2024-12-19 14:37:41 --> Helper loaded: file_helper
INFO - 2024-12-19 14:37:41 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:37:41 --> Form Validation Class Initialized
INFO - 2024-12-19 14:37:41 --> Upload Class Initialized
INFO - 2024-12-19 14:37:41 --> Model "M_login" initialized
INFO - 2024-12-19 14:37:41 --> Model "M_home" initialized
INFO - 2024-12-19 14:37:41 --> Model "M_setting" initialized
INFO - 2024-12-19 14:37:41 --> Controller Class Initialized
INFO - 2024-12-19 14:37:41 --> Model "M_guru" initialized
INFO - 2024-12-19 14:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-19 14:37:41 --> Pagination Class Initialized
INFO - 2024-12-19 14:37:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-19 14:37:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:37:41 --> Final output sent to browser
DEBUG - 2024-12-19 14:37:41 --> Total execution time: 0.1373
INFO - 2024-12-19 14:38:19 --> Config Class Initialized
INFO - 2024-12-19 14:38:19 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:38:19 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:38:19 --> Utf8 Class Initialized
INFO - 2024-12-19 14:38:19 --> URI Class Initialized
INFO - 2024-12-19 14:38:19 --> Router Class Initialized
INFO - 2024-12-19 14:38:19 --> Output Class Initialized
INFO - 2024-12-19 14:38:19 --> Security Class Initialized
DEBUG - 2024-12-19 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:38:19 --> Input Class Initialized
INFO - 2024-12-19 14:38:19 --> Language Class Initialized
INFO - 2024-12-19 14:38:19 --> Loader Class Initialized
INFO - 2024-12-19 14:38:19 --> Helper loaded: url_helper
INFO - 2024-12-19 14:38:19 --> Helper loaded: form_helper
INFO - 2024-12-19 14:38:19 --> Helper loaded: file_helper
INFO - 2024-12-19 14:38:19 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:38:19 --> Form Validation Class Initialized
INFO - 2024-12-19 14:38:19 --> Upload Class Initialized
INFO - 2024-12-19 14:38:19 --> Model "M_login" initialized
INFO - 2024-12-19 14:38:19 --> Model "M_home" initialized
INFO - 2024-12-19 14:38:19 --> Model "M_setting" initialized
INFO - 2024-12-19 14:38:19 --> Controller Class Initialized
INFO - 2024-12-19 14:38:19 --> Model "M_guru" initialized
INFO - 2024-12-19 14:38:19 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:38:19 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:38:19 --> Final output sent to browser
DEBUG - 2024-12-19 14:38:19 --> Total execution time: 0.0879
INFO - 2024-12-19 14:38:19 --> Config Class Initialized
INFO - 2024-12-19 14:38:19 --> Hooks Class Initialized
INFO - 2024-12-19 14:38:19 --> Config Class Initialized
INFO - 2024-12-19 14:38:19 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:38:19 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:38:19 --> Utf8 Class Initialized
DEBUG - 2024-12-19 14:38:19 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:38:19 --> Utf8 Class Initialized
INFO - 2024-12-19 14:38:19 --> URI Class Initialized
INFO - 2024-12-19 14:38:19 --> URI Class Initialized
INFO - 2024-12-19 14:38:19 --> Router Class Initialized
INFO - 2024-12-19 14:38:19 --> Router Class Initialized
INFO - 2024-12-19 14:38:19 --> Output Class Initialized
INFO - 2024-12-19 14:38:19 --> Output Class Initialized
INFO - 2024-12-19 14:38:19 --> Security Class Initialized
INFO - 2024-12-19 14:38:19 --> Security Class Initialized
DEBUG - 2024-12-19 14:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-19 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:38:19 --> Input Class Initialized
INFO - 2024-12-19 14:38:19 --> Input Class Initialized
INFO - 2024-12-19 14:38:19 --> Language Class Initialized
INFO - 2024-12-19 14:38:19 --> Language Class Initialized
ERROR - 2024-12-19 14:38:19 --> 404 Page Not Found: Images/team_background.jpg
ERROR - 2024-12-19 14:38:19 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 14:38:19 --> Config Class Initialized
INFO - 2024-12-19 14:38:19 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:38:19 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:38:19 --> Utf8 Class Initialized
INFO - 2024-12-19 14:38:19 --> URI Class Initialized
INFO - 2024-12-19 14:38:19 --> Router Class Initialized
INFO - 2024-12-19 14:38:19 --> Output Class Initialized
INFO - 2024-12-19 14:38:19 --> Security Class Initialized
DEBUG - 2024-12-19 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:38:19 --> Input Class Initialized
INFO - 2024-12-19 14:38:19 --> Language Class Initialized
ERROR - 2024-12-19 14:38:19 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 14:38:36 --> Config Class Initialized
INFO - 2024-12-19 14:38:36 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:38:36 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:38:36 --> Utf8 Class Initialized
INFO - 2024-12-19 14:38:36 --> URI Class Initialized
INFO - 2024-12-19 14:38:36 --> Router Class Initialized
INFO - 2024-12-19 14:38:36 --> Output Class Initialized
INFO - 2024-12-19 14:38:36 --> Security Class Initialized
DEBUG - 2024-12-19 14:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:38:36 --> Input Class Initialized
INFO - 2024-12-19 14:38:36 --> Language Class Initialized
INFO - 2024-12-19 14:38:36 --> Loader Class Initialized
INFO - 2024-12-19 14:38:36 --> Helper loaded: url_helper
INFO - 2024-12-19 14:38:36 --> Helper loaded: form_helper
INFO - 2024-12-19 14:38:36 --> Helper loaded: file_helper
INFO - 2024-12-19 14:38:36 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:38:36 --> Form Validation Class Initialized
INFO - 2024-12-19 14:38:36 --> Upload Class Initialized
INFO - 2024-12-19 14:38:36 --> Model "M_login" initialized
INFO - 2024-12-19 14:38:36 --> Model "M_home" initialized
INFO - 2024-12-19 14:38:36 --> Model "M_setting" initialized
INFO - 2024-12-19 14:38:36 --> Controller Class Initialized
INFO - 2024-12-19 14:38:36 --> Model "M_guru" initialized
INFO - 2024-12-19 14:38:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-19 14:38:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:38:36 --> Final output sent to browser
DEBUG - 2024-12-19 14:38:36 --> Total execution time: 0.1378
INFO - 2024-12-19 14:38:42 --> Config Class Initialized
INFO - 2024-12-19 14:38:42 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:38:42 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:38:42 --> Utf8 Class Initialized
INFO - 2024-12-19 14:38:42 --> URI Class Initialized
INFO - 2024-12-19 14:38:42 --> Router Class Initialized
INFO - 2024-12-19 14:38:42 --> Output Class Initialized
INFO - 2024-12-19 14:38:42 --> Security Class Initialized
DEBUG - 2024-12-19 14:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:38:42 --> Input Class Initialized
INFO - 2024-12-19 14:38:42 --> Language Class Initialized
INFO - 2024-12-19 14:38:42 --> Loader Class Initialized
INFO - 2024-12-19 14:38:42 --> Helper loaded: url_helper
INFO - 2024-12-19 14:38:42 --> Helper loaded: form_helper
INFO - 2024-12-19 14:38:42 --> Helper loaded: file_helper
INFO - 2024-12-19 14:38:42 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:38:42 --> Form Validation Class Initialized
INFO - 2024-12-19 14:38:42 --> Upload Class Initialized
INFO - 2024-12-19 14:38:42 --> Model "M_login" initialized
INFO - 2024-12-19 14:38:42 --> Model "M_home" initialized
INFO - 2024-12-19 14:38:42 --> Model "M_setting" initialized
INFO - 2024-12-19 14:38:42 --> Controller Class Initialized
INFO - 2024-12-19 14:38:42 --> Model "M_guru" initialized
INFO - 2024-12-19 14:38:42 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-19 14:38:42 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:38:42 --> Final output sent to browser
DEBUG - 2024-12-19 14:38:42 --> Total execution time: 0.1143
INFO - 2024-12-19 14:40:34 --> Config Class Initialized
INFO - 2024-12-19 14:40:34 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:40:34 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:40:34 --> Utf8 Class Initialized
INFO - 2024-12-19 14:40:34 --> URI Class Initialized
DEBUG - 2024-12-19 14:40:34 --> No URI present. Default controller set.
INFO - 2024-12-19 14:40:34 --> Router Class Initialized
INFO - 2024-12-19 14:40:34 --> Output Class Initialized
INFO - 2024-12-19 14:40:34 --> Security Class Initialized
DEBUG - 2024-12-19 14:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:40:34 --> Input Class Initialized
INFO - 2024-12-19 14:40:34 --> Language Class Initialized
INFO - 2024-12-19 14:40:34 --> Loader Class Initialized
INFO - 2024-12-19 14:40:34 --> Helper loaded: url_helper
INFO - 2024-12-19 14:40:34 --> Helper loaded: form_helper
INFO - 2024-12-19 14:40:34 --> Helper loaded: file_helper
INFO - 2024-12-19 14:40:34 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:40:34 --> Form Validation Class Initialized
INFO - 2024-12-19 14:40:34 --> Upload Class Initialized
INFO - 2024-12-19 14:40:34 --> Model "M_login" initialized
INFO - 2024-12-19 14:40:34 --> Model "M_home" initialized
INFO - 2024-12-19 14:40:34 --> Model "M_setting" initialized
INFO - 2024-12-19 14:40:34 --> Controller Class Initialized
INFO - 2024-12-19 14:40:34 --> Model "M_guru" initialized
INFO - 2024-12-19 14:40:34 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 14:40:34 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 14:40:34 --> Final output sent to browser
DEBUG - 2024-12-19 14:40:34 --> Total execution time: 0.1092
INFO - 2024-12-19 14:40:35 --> Config Class Initialized
INFO - 2024-12-19 14:40:35 --> Hooks Class Initialized
INFO - 2024-12-19 14:40:35 --> Config Class Initialized
INFO - 2024-12-19 14:40:35 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:40:35 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:40:35 --> Utf8 Class Initialized
INFO - 2024-12-19 14:40:35 --> URI Class Initialized
INFO - 2024-12-19 14:40:35 --> Router Class Initialized
DEBUG - 2024-12-19 14:40:35 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:40:35 --> Utf8 Class Initialized
INFO - 2024-12-19 14:40:35 --> URI Class Initialized
INFO - 2024-12-19 14:40:35 --> Output Class Initialized
INFO - 2024-12-19 14:40:35 --> Security Class Initialized
INFO - 2024-12-19 14:40:35 --> Router Class Initialized
DEBUG - 2024-12-19 14:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:40:35 --> Input Class Initialized
INFO - 2024-12-19 14:40:35 --> Output Class Initialized
INFO - 2024-12-19 14:40:35 --> Language Class Initialized
ERROR - 2024-12-19 14:40:35 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 14:40:35 --> Security Class Initialized
DEBUG - 2024-12-19 14:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:40:35 --> Input Class Initialized
INFO - 2024-12-19 14:40:35 --> Language Class Initialized
ERROR - 2024-12-19 14:40:35 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 14:40:35 --> Config Class Initialized
INFO - 2024-12-19 14:40:35 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:40:35 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:40:35 --> Utf8 Class Initialized
INFO - 2024-12-19 14:40:35 --> URI Class Initialized
INFO - 2024-12-19 14:40:35 --> Router Class Initialized
INFO - 2024-12-19 14:40:35 --> Output Class Initialized
INFO - 2024-12-19 14:40:35 --> Security Class Initialized
DEBUG - 2024-12-19 14:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:40:35 --> Input Class Initialized
INFO - 2024-12-19 14:40:35 --> Language Class Initialized
ERROR - 2024-12-19 14:40:35 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 14:42:05 --> Config Class Initialized
INFO - 2024-12-19 14:42:05 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:42:05 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:42:05 --> Utf8 Class Initialized
INFO - 2024-12-19 14:42:05 --> URI Class Initialized
INFO - 2024-12-19 14:42:05 --> Router Class Initialized
INFO - 2024-12-19 14:42:05 --> Output Class Initialized
INFO - 2024-12-19 14:42:05 --> Security Class Initialized
DEBUG - 2024-12-19 14:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:42:05 --> Input Class Initialized
INFO - 2024-12-19 14:42:05 --> Language Class Initialized
INFO - 2024-12-19 14:42:05 --> Loader Class Initialized
INFO - 2024-12-19 14:42:05 --> Helper loaded: url_helper
INFO - 2024-12-19 14:42:05 --> Helper loaded: form_helper
INFO - 2024-12-19 14:42:05 --> Helper loaded: file_helper
INFO - 2024-12-19 14:42:05 --> Database Driver Class Initialized
DEBUG - 2024-12-19 14:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 14:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 14:42:05 --> Form Validation Class Initialized
INFO - 2024-12-19 14:42:05 --> Upload Class Initialized
INFO - 2024-12-19 14:42:05 --> Model "M_login" initialized
INFO - 2024-12-19 14:42:05 --> Model "M_home" initialized
INFO - 2024-12-19 14:42:05 --> Model "M_setting" initialized
INFO - 2024-12-19 14:42:05 --> Controller Class Initialized
INFO - 2024-12-19 14:42:05 --> Model "M_guru" initialized
INFO - 2024-12-19 14:42:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-19 14:42:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-19 14:42:05 --> Final output sent to browser
DEBUG - 2024-12-19 14:42:05 --> Total execution time: 0.1021
INFO - 2024-12-19 14:42:06 --> Config Class Initialized
INFO - 2024-12-19 14:42:06 --> Hooks Class Initialized
DEBUG - 2024-12-19 14:42:06 --> UTF-8 Support Enabled
INFO - 2024-12-19 14:42:06 --> Utf8 Class Initialized
INFO - 2024-12-19 14:42:06 --> URI Class Initialized
INFO - 2024-12-19 14:42:06 --> Router Class Initialized
INFO - 2024-12-19 14:42:06 --> Output Class Initialized
INFO - 2024-12-19 14:42:06 --> Security Class Initialized
DEBUG - 2024-12-19 14:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 14:42:06 --> Input Class Initialized
INFO - 2024-12-19 14:42:06 --> Language Class Initialized
ERROR - 2024-12-19 14:42:06 --> 404 Page Not Found: Home/images
INFO - 2024-12-19 15:01:26 --> Config Class Initialized
INFO - 2024-12-19 15:01:26 --> Hooks Class Initialized
DEBUG - 2024-12-19 15:01:26 --> UTF-8 Support Enabled
INFO - 2024-12-19 15:01:26 --> Utf8 Class Initialized
INFO - 2024-12-19 15:01:26 --> URI Class Initialized
DEBUG - 2024-12-19 15:01:26 --> No URI present. Default controller set.
INFO - 2024-12-19 15:01:26 --> Router Class Initialized
INFO - 2024-12-19 15:01:26 --> Output Class Initialized
INFO - 2024-12-19 15:01:26 --> Security Class Initialized
DEBUG - 2024-12-19 15:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 15:01:26 --> Input Class Initialized
INFO - 2024-12-19 15:01:26 --> Language Class Initialized
INFO - 2024-12-19 15:01:26 --> Loader Class Initialized
INFO - 2024-12-19 15:01:26 --> Helper loaded: url_helper
INFO - 2024-12-19 15:01:26 --> Helper loaded: form_helper
INFO - 2024-12-19 15:01:26 --> Helper loaded: file_helper
INFO - 2024-12-19 15:01:26 --> Database Driver Class Initialized
DEBUG - 2024-12-19 15:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 15:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 15:01:26 --> Form Validation Class Initialized
INFO - 2024-12-19 15:01:26 --> Upload Class Initialized
INFO - 2024-12-19 15:01:26 --> Model "M_login" initialized
INFO - 2024-12-19 15:01:26 --> Model "M_home" initialized
INFO - 2024-12-19 15:01:26 --> Model "M_setting" initialized
INFO - 2024-12-19 15:01:26 --> Controller Class Initialized
INFO - 2024-12-19 15:01:26 --> Model "M_guru" initialized
INFO - 2024-12-19 15:01:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-19 15:01:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-19 15:01:26 --> Final output sent to browser
DEBUG - 2024-12-19 15:01:26 --> Total execution time: 0.1155
INFO - 2024-12-19 15:01:27 --> Config Class Initialized
INFO - 2024-12-19 15:01:27 --> Hooks Class Initialized
INFO - 2024-12-19 15:01:27 --> Config Class Initialized
INFO - 2024-12-19 15:01:27 --> Hooks Class Initialized
DEBUG - 2024-12-19 15:01:27 --> UTF-8 Support Enabled
INFO - 2024-12-19 15:01:27 --> Utf8 Class Initialized
DEBUG - 2024-12-19 15:01:27 --> UTF-8 Support Enabled
INFO - 2024-12-19 15:01:27 --> Utf8 Class Initialized
INFO - 2024-12-19 15:01:27 --> URI Class Initialized
INFO - 2024-12-19 15:01:27 --> URI Class Initialized
INFO - 2024-12-19 15:01:27 --> Router Class Initialized
INFO - 2024-12-19 15:01:27 --> Router Class Initialized
INFO - 2024-12-19 15:01:27 --> Output Class Initialized
INFO - 2024-12-19 15:01:27 --> Output Class Initialized
INFO - 2024-12-19 15:01:27 --> Security Class Initialized
DEBUG - 2024-12-19 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 15:01:27 --> Security Class Initialized
INFO - 2024-12-19 15:01:27 --> Input Class Initialized
INFO - 2024-12-19 15:01:27 --> Language Class Initialized
DEBUG - 2024-12-19 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 15:01:27 --> Input Class Initialized
ERROR - 2024-12-19 15:01:27 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-19 15:01:27 --> Language Class Initialized
ERROR - 2024-12-19 15:01:27 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-19 15:01:27 --> Config Class Initialized
INFO - 2024-12-19 15:01:27 --> Hooks Class Initialized
DEBUG - 2024-12-19 15:01:27 --> UTF-8 Support Enabled
INFO - 2024-12-19 15:01:27 --> Utf8 Class Initialized
INFO - 2024-12-19 15:01:27 --> URI Class Initialized
INFO - 2024-12-19 15:01:27 --> Router Class Initialized
INFO - 2024-12-19 15:01:27 --> Output Class Initialized
INFO - 2024-12-19 15:01:27 --> Security Class Initialized
DEBUG - 2024-12-19 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 15:01:27 --> Input Class Initialized
INFO - 2024-12-19 15:01:27 --> Language Class Initialized
ERROR - 2024-12-19 15:01:27 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-19 15:06:16 --> Config Class Initialized
INFO - 2024-12-19 15:06:16 --> Hooks Class Initialized
DEBUG - 2024-12-19 15:06:16 --> UTF-8 Support Enabled
INFO - 2024-12-19 15:06:16 --> Utf8 Class Initialized
INFO - 2024-12-19 15:06:16 --> URI Class Initialized
DEBUG - 2024-12-19 15:06:16 --> No URI present. Default controller set.
INFO - 2024-12-19 15:06:16 --> Router Class Initialized
INFO - 2024-12-19 15:06:16 --> Output Class Initialized
INFO - 2024-12-19 15:06:16 --> Security Class Initialized
DEBUG - 2024-12-19 15:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 15:06:16 --> Input Class Initialized
INFO - 2024-12-19 15:06:16 --> Language Class Initialized
ERROR - 2024-12-19 15:06:16 --> Severity: Compile Error --> Cannot redeclare NilaiController::index() C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\controllers\NilaiController.php 19
INFO - 2024-12-19 15:42:40 --> Config Class Initialized
INFO - 2024-12-19 15:42:40 --> Hooks Class Initialized
DEBUG - 2024-12-19 15:42:40 --> UTF-8 Support Enabled
INFO - 2024-12-19 15:42:40 --> Utf8 Class Initialized
INFO - 2024-12-19 15:42:40 --> URI Class Initialized
DEBUG - 2024-12-19 15:42:40 --> No URI present. Default controller set.
INFO - 2024-12-19 15:42:40 --> Router Class Initialized
INFO - 2024-12-19 15:42:40 --> Output Class Initialized
INFO - 2024-12-19 15:42:40 --> Security Class Initialized
DEBUG - 2024-12-19 15:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 15:42:40 --> Input Class Initialized
INFO - 2024-12-19 15:42:40 --> Language Class Initialized
INFO - 2024-12-19 15:42:40 --> Loader Class Initialized
INFO - 2024-12-19 15:42:40 --> Helper loaded: url_helper
INFO - 2024-12-19 15:42:40 --> Helper loaded: form_helper
INFO - 2024-12-19 15:42:40 --> Helper loaded: file_helper
INFO - 2024-12-19 15:42:40 --> Database Driver Class Initialized
DEBUG - 2024-12-19 15:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 15:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 15:42:40 --> Form Validation Class Initialized
INFO - 2024-12-19 15:42:40 --> Upload Class Initialized
INFO - 2024-12-19 15:42:40 --> Model "M_login" initialized
INFO - 2024-12-19 15:42:40 --> Model "M_home" initialized
INFO - 2024-12-19 15:42:40 --> Model "M_setting" initialized
INFO - 2024-12-19 15:42:40 --> Controller Class Initialized
INFO - 2024-12-19 15:42:40 --> Model "NilaiModel" initialized
INFO - 2024-12-19 15:42:40 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\nilai_form.php
INFO - 2024-12-19 15:42:40 --> Final output sent to browser
DEBUG - 2024-12-19 15:42:40 --> Total execution time: 0.0839
INFO - 2024-12-19 15:43:08 --> Config Class Initialized
INFO - 2024-12-19 15:43:08 --> Hooks Class Initialized
DEBUG - 2024-12-19 15:43:08 --> UTF-8 Support Enabled
INFO - 2024-12-19 15:43:08 --> Utf8 Class Initialized
INFO - 2024-12-19 15:43:08 --> URI Class Initialized
DEBUG - 2024-12-19 15:43:08 --> No URI present. Default controller set.
INFO - 2024-12-19 15:43:08 --> Router Class Initialized
INFO - 2024-12-19 15:43:08 --> Output Class Initialized
INFO - 2024-12-19 15:43:08 --> Security Class Initialized
DEBUG - 2024-12-19 15:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 15:43:08 --> Input Class Initialized
INFO - 2024-12-19 15:43:08 --> Language Class Initialized
INFO - 2024-12-19 15:43:08 --> Loader Class Initialized
INFO - 2024-12-19 15:43:08 --> Helper loaded: url_helper
INFO - 2024-12-19 15:43:08 --> Helper loaded: form_helper
INFO - 2024-12-19 15:43:08 --> Helper loaded: file_helper
INFO - 2024-12-19 15:43:08 --> Database Driver Class Initialized
DEBUG - 2024-12-19 15:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 15:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 15:43:08 --> Form Validation Class Initialized
INFO - 2024-12-19 15:43:08 --> Upload Class Initialized
INFO - 2024-12-19 15:43:08 --> Model "M_login" initialized
INFO - 2024-12-19 15:43:08 --> Model "M_home" initialized
INFO - 2024-12-19 15:43:08 --> Model "M_setting" initialized
INFO - 2024-12-19 15:43:08 --> Controller Class Initialized
INFO - 2024-12-19 15:43:08 --> Model "NilaiModel" initialized
INFO - 2024-12-19 15:43:08 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\nilai_form.php
INFO - 2024-12-19 15:43:08 --> Final output sent to browser
DEBUG - 2024-12-19 15:43:08 --> Total execution time: 0.1258
INFO - 2024-12-19 16:23:23 --> Config Class Initialized
INFO - 2024-12-19 16:23:23 --> Hooks Class Initialized
DEBUG - 2024-12-19 16:23:23 --> UTF-8 Support Enabled
INFO - 2024-12-19 16:23:23 --> Utf8 Class Initialized
INFO - 2024-12-19 16:23:23 --> URI Class Initialized
DEBUG - 2024-12-19 16:23:23 --> No URI present. Default controller set.
INFO - 2024-12-19 16:23:23 --> Router Class Initialized
INFO - 2024-12-19 16:23:23 --> Output Class Initialized
INFO - 2024-12-19 16:23:23 --> Security Class Initialized
DEBUG - 2024-12-19 16:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-19 16:23:23 --> Input Class Initialized
INFO - 2024-12-19 16:23:23 --> Language Class Initialized
INFO - 2024-12-19 16:23:23 --> Loader Class Initialized
INFO - 2024-12-19 16:23:23 --> Helper loaded: url_helper
INFO - 2024-12-19 16:23:23 --> Helper loaded: form_helper
INFO - 2024-12-19 16:23:23 --> Helper loaded: file_helper
INFO - 2024-12-19 16:23:23 --> Database Driver Class Initialized
DEBUG - 2024-12-19 16:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-19 16:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-19 16:23:23 --> Form Validation Class Initialized
INFO - 2024-12-19 16:23:23 --> Upload Class Initialized
INFO - 2024-12-19 16:23:23 --> Model "M_login" initialized
INFO - 2024-12-19 16:23:23 --> Model "M_home" initialized
INFO - 2024-12-19 16:23:23 --> Model "M_setting" initialized
INFO - 2024-12-19 16:23:23 --> Controller Class Initialized
INFO - 2024-12-19 16:23:23 --> Model "NilaiModel" initialized
INFO - 2024-12-19 16:23:23 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\nilai_form.php
INFO - 2024-12-19 16:23:23 --> Final output sent to browser
DEBUG - 2024-12-19 16:23:23 --> Total execution time: 0.0766
