<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-14 05:44:12 --> Config Class Initialized
INFO - 2024-12-14 05:44:12 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:12 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:12 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:12 --> URI Class Initialized
DEBUG - 2024-12-14 05:44:12 --> No URI present. Default controller set.
INFO - 2024-12-14 05:44:12 --> Router Class Initialized
INFO - 2024-12-14 05:44:12 --> Output Class Initialized
INFO - 2024-12-14 05:44:12 --> Security Class Initialized
DEBUG - 2024-12-14 05:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:12 --> Input Class Initialized
INFO - 2024-12-14 05:44:12 --> Language Class Initialized
INFO - 2024-12-14 05:44:12 --> Loader Class Initialized
INFO - 2024-12-14 05:44:12 --> Helper loaded: url_helper
INFO - 2024-12-14 05:44:12 --> Helper loaded: form_helper
INFO - 2024-12-14 05:44:12 --> Helper loaded: file_helper
INFO - 2024-12-14 05:44:12 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:44:12 --> Form Validation Class Initialized
INFO - 2024-12-14 05:44:12 --> Upload Class Initialized
INFO - 2024-12-14 05:44:12 --> Model "M_login" initialized
INFO - 2024-12-14 05:44:12 --> Model "M_home" initialized
INFO - 2024-12-14 05:44:12 --> Model "M_setting" initialized
INFO - 2024-12-14 05:44:12 --> Controller Class Initialized
INFO - 2024-12-14 05:44:12 --> Model "M_guru" initialized
INFO - 2024-12-14 05:44:12 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:44:12 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:44:12 --> Final output sent to browser
DEBUG - 2024-12-14 05:44:12 --> Total execution time: 0.1411
INFO - 2024-12-14 05:44:13 --> Config Class Initialized
INFO - 2024-12-14 05:44:13 --> Config Class Initialized
INFO - 2024-12-14 05:44:13 --> Hooks Class Initialized
INFO - 2024-12-14 05:44:13 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:13 --> UTF-8 Support Enabled
DEBUG - 2024-12-14 05:44:13 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:13 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:13 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:13 --> URI Class Initialized
INFO - 2024-12-14 05:44:13 --> URI Class Initialized
INFO - 2024-12-14 05:44:13 --> Router Class Initialized
INFO - 2024-12-14 05:44:13 --> Router Class Initialized
INFO - 2024-12-14 05:44:13 --> Output Class Initialized
INFO - 2024-12-14 05:44:13 --> Output Class Initialized
INFO - 2024-12-14 05:44:13 --> Security Class Initialized
INFO - 2024-12-14 05:44:13 --> Security Class Initialized
DEBUG - 2024-12-14 05:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:13 --> Input Class Initialized
INFO - 2024-12-14 05:44:13 --> Language Class Initialized
DEBUG - 2024-12-14 05:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:13 --> Input Class Initialized
ERROR - 2024-12-14 05:44:13 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-14 05:44:13 --> Language Class Initialized
ERROR - 2024-12-14 05:44:13 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-14 05:44:13 --> Config Class Initialized
INFO - 2024-12-14 05:44:13 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:13 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:13 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:13 --> URI Class Initialized
INFO - 2024-12-14 05:44:13 --> Router Class Initialized
INFO - 2024-12-14 05:44:13 --> Output Class Initialized
INFO - 2024-12-14 05:44:13 --> Security Class Initialized
DEBUG - 2024-12-14 05:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:13 --> Input Class Initialized
INFO - 2024-12-14 05:44:13 --> Language Class Initialized
ERROR - 2024-12-14 05:44:13 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-14 05:44:16 --> Config Class Initialized
INFO - 2024-12-14 05:44:16 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:16 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:16 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:16 --> URI Class Initialized
INFO - 2024-12-14 05:44:16 --> Router Class Initialized
INFO - 2024-12-14 05:44:16 --> Output Class Initialized
INFO - 2024-12-14 05:44:16 --> Security Class Initialized
DEBUG - 2024-12-14 05:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:16 --> Input Class Initialized
INFO - 2024-12-14 05:44:16 --> Language Class Initialized
INFO - 2024-12-14 05:44:16 --> Loader Class Initialized
INFO - 2024-12-14 05:44:16 --> Helper loaded: url_helper
INFO - 2024-12-14 05:44:16 --> Helper loaded: form_helper
INFO - 2024-12-14 05:44:16 --> Helper loaded: file_helper
INFO - 2024-12-14 05:44:16 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:44:16 --> Form Validation Class Initialized
INFO - 2024-12-14 05:44:16 --> Upload Class Initialized
INFO - 2024-12-14 05:44:16 --> Model "M_login" initialized
INFO - 2024-12-14 05:44:16 --> Model "M_home" initialized
INFO - 2024-12-14 05:44:16 --> Model "M_setting" initialized
INFO - 2024-12-14 05:44:16 --> Controller Class Initialized
INFO - 2024-12-14 05:44:16 --> Model "M_guru" initialized
INFO - 2024-12-14 05:44:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-14 05:44:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 05:44:16 --> Final output sent to browser
DEBUG - 2024-12-14 05:44:16 --> Total execution time: 0.1606
INFO - 2024-12-14 05:44:17 --> Config Class Initialized
INFO - 2024-12-14 05:44:17 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:17 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:17 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:17 --> URI Class Initialized
INFO - 2024-12-14 05:44:17 --> Router Class Initialized
INFO - 2024-12-14 05:44:17 --> Output Class Initialized
INFO - 2024-12-14 05:44:17 --> Security Class Initialized
DEBUG - 2024-12-14 05:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:17 --> Input Class Initialized
INFO - 2024-12-14 05:44:17 --> Language Class Initialized
ERROR - 2024-12-14 05:44:17 --> 404 Page Not Found: Home/images
INFO - 2024-12-14 05:44:53 --> Config Class Initialized
INFO - 2024-12-14 05:44:53 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:53 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:53 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:53 --> URI Class Initialized
DEBUG - 2024-12-14 05:44:53 --> No URI present. Default controller set.
INFO - 2024-12-14 05:44:53 --> Router Class Initialized
INFO - 2024-12-14 05:44:53 --> Output Class Initialized
INFO - 2024-12-14 05:44:53 --> Security Class Initialized
DEBUG - 2024-12-14 05:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:53 --> Input Class Initialized
INFO - 2024-12-14 05:44:53 --> Language Class Initialized
INFO - 2024-12-14 05:44:53 --> Loader Class Initialized
INFO - 2024-12-14 05:44:53 --> Helper loaded: url_helper
INFO - 2024-12-14 05:44:53 --> Helper loaded: form_helper
INFO - 2024-12-14 05:44:53 --> Helper loaded: file_helper
INFO - 2024-12-14 05:44:53 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:44:53 --> Form Validation Class Initialized
INFO - 2024-12-14 05:44:53 --> Upload Class Initialized
INFO - 2024-12-14 05:44:53 --> Model "M_login" initialized
INFO - 2024-12-14 05:44:53 --> Model "M_home" initialized
INFO - 2024-12-14 05:44:53 --> Model "M_setting" initialized
INFO - 2024-12-14 05:44:53 --> Controller Class Initialized
INFO - 2024-12-14 05:44:53 --> Model "M_guru" initialized
INFO - 2024-12-14 05:44:53 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:44:53 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:44:53 --> Final output sent to browser
DEBUG - 2024-12-14 05:44:53 --> Total execution time: 0.1616
INFO - 2024-12-14 05:44:54 --> Config Class Initialized
INFO - 2024-12-14 05:44:54 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:54 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:54 --> URI Class Initialized
INFO - 2024-12-14 05:44:54 --> Router Class Initialized
INFO - 2024-12-14 05:44:54 --> Output Class Initialized
INFO - 2024-12-14 05:44:54 --> Security Class Initialized
INFO - 2024-12-14 05:44:54 --> Config Class Initialized
INFO - 2024-12-14 05:44:54 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:54 --> Input Class Initialized
INFO - 2024-12-14 05:44:54 --> Language Class Initialized
INFO - 2024-12-14 05:44:54 --> Config Class Initialized
INFO - 2024-12-14 05:44:54 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:54 --> Utf8 Class Initialized
INFO - 2024-12-14 05:44:54 --> URI Class Initialized
DEBUG - 2024-12-14 05:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:44:54 --> Utf8 Class Initialized
ERROR - 2024-12-14 05:44:54 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-14 05:44:54 --> Router Class Initialized
INFO - 2024-12-14 05:44:54 --> URI Class Initialized
INFO - 2024-12-14 05:44:54 --> Output Class Initialized
INFO - 2024-12-14 05:44:54 --> Router Class Initialized
INFO - 2024-12-14 05:44:54 --> Security Class Initialized
INFO - 2024-12-14 05:44:54 --> Output Class Initialized
DEBUG - 2024-12-14 05:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:54 --> Input Class Initialized
INFO - 2024-12-14 05:44:54 --> Security Class Initialized
INFO - 2024-12-14 05:44:54 --> Language Class Initialized
DEBUG - 2024-12-14 05:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:44:54 --> Input Class Initialized
ERROR - 2024-12-14 05:44:54 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-14 05:44:54 --> Language Class Initialized
ERROR - 2024-12-14 05:44:54 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-14 05:45:27 --> Config Class Initialized
INFO - 2024-12-14 05:45:27 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:45:27 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:45:27 --> Utf8 Class Initialized
INFO - 2024-12-14 05:45:27 --> URI Class Initialized
INFO - 2024-12-14 05:45:27 --> Router Class Initialized
INFO - 2024-12-14 05:45:27 --> Output Class Initialized
INFO - 2024-12-14 05:45:27 --> Security Class Initialized
DEBUG - 2024-12-14 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:45:27 --> Input Class Initialized
INFO - 2024-12-14 05:45:27 --> Language Class Initialized
ERROR - 2024-12-14 05:45:27 --> 404 Page Not Found: Abouthtml/index
INFO - 2024-12-14 05:45:30 --> Config Class Initialized
INFO - 2024-12-14 05:45:30 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:45:30 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:45:30 --> Utf8 Class Initialized
INFO - 2024-12-14 05:45:30 --> URI Class Initialized
DEBUG - 2024-12-14 05:45:30 --> No URI present. Default controller set.
INFO - 2024-12-14 05:45:30 --> Router Class Initialized
INFO - 2024-12-14 05:45:30 --> Output Class Initialized
INFO - 2024-12-14 05:45:30 --> Security Class Initialized
DEBUG - 2024-12-14 05:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:45:30 --> Input Class Initialized
INFO - 2024-12-14 05:45:30 --> Language Class Initialized
INFO - 2024-12-14 05:45:30 --> Loader Class Initialized
INFO - 2024-12-14 05:45:31 --> Helper loaded: url_helper
INFO - 2024-12-14 05:45:31 --> Helper loaded: form_helper
INFO - 2024-12-14 05:45:31 --> Helper loaded: file_helper
INFO - 2024-12-14 05:45:31 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:45:31 --> Form Validation Class Initialized
INFO - 2024-12-14 05:45:31 --> Upload Class Initialized
INFO - 2024-12-14 05:45:31 --> Model "M_login" initialized
INFO - 2024-12-14 05:45:31 --> Model "M_home" initialized
INFO - 2024-12-14 05:45:31 --> Model "M_setting" initialized
INFO - 2024-12-14 05:45:31 --> Controller Class Initialized
INFO - 2024-12-14 05:45:31 --> Model "M_guru" initialized
INFO - 2024-12-14 05:45:31 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:45:31 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:45:31 --> Final output sent to browser
DEBUG - 2024-12-14 05:45:31 --> Total execution time: 0.1229
INFO - 2024-12-14 05:45:38 --> Config Class Initialized
INFO - 2024-12-14 05:45:38 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:45:38 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:45:38 --> Utf8 Class Initialized
INFO - 2024-12-14 05:45:38 --> URI Class Initialized
INFO - 2024-12-14 05:45:38 --> Router Class Initialized
INFO - 2024-12-14 05:45:38 --> Output Class Initialized
INFO - 2024-12-14 05:45:38 --> Security Class Initialized
DEBUG - 2024-12-14 05:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:45:38 --> Input Class Initialized
INFO - 2024-12-14 05:45:38 --> Language Class Initialized
ERROR - 2024-12-14 05:45:38 --> 404 Page Not Found: Abouthtml/index
INFO - 2024-12-14 05:45:41 --> Config Class Initialized
INFO - 2024-12-14 05:45:41 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:45:41 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:45:41 --> Utf8 Class Initialized
INFO - 2024-12-14 05:45:41 --> URI Class Initialized
DEBUG - 2024-12-14 05:45:41 --> No URI present. Default controller set.
INFO - 2024-12-14 05:45:41 --> Router Class Initialized
INFO - 2024-12-14 05:45:41 --> Output Class Initialized
INFO - 2024-12-14 05:45:41 --> Security Class Initialized
DEBUG - 2024-12-14 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:45:41 --> Input Class Initialized
INFO - 2024-12-14 05:45:41 --> Language Class Initialized
INFO - 2024-12-14 05:45:41 --> Loader Class Initialized
INFO - 2024-12-14 05:45:41 --> Helper loaded: url_helper
INFO - 2024-12-14 05:45:41 --> Helper loaded: form_helper
INFO - 2024-12-14 05:45:41 --> Helper loaded: file_helper
INFO - 2024-12-14 05:45:41 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:45:41 --> Form Validation Class Initialized
INFO - 2024-12-14 05:45:41 --> Upload Class Initialized
INFO - 2024-12-14 05:45:41 --> Model "M_login" initialized
INFO - 2024-12-14 05:45:41 --> Model "M_home" initialized
INFO - 2024-12-14 05:45:41 --> Model "M_setting" initialized
INFO - 2024-12-14 05:45:41 --> Controller Class Initialized
INFO - 2024-12-14 05:45:41 --> Model "M_guru" initialized
INFO - 2024-12-14 05:45:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:45:41 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:45:41 --> Final output sent to browser
DEBUG - 2024-12-14 05:45:41 --> Total execution time: 0.1579
INFO - 2024-12-14 05:45:44 --> Config Class Initialized
INFO - 2024-12-14 05:45:44 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:45:44 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:45:44 --> Utf8 Class Initialized
INFO - 2024-12-14 05:45:44 --> URI Class Initialized
INFO - 2024-12-14 05:45:44 --> Router Class Initialized
INFO - 2024-12-14 05:45:44 --> Output Class Initialized
INFO - 2024-12-14 05:45:44 --> Security Class Initialized
DEBUG - 2024-12-14 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:45:44 --> Input Class Initialized
INFO - 2024-12-14 05:45:44 --> Language Class Initialized
ERROR - 2024-12-14 05:45:44 --> 404 Page Not Found: Indexhtml/index
INFO - 2024-12-14 05:45:46 --> Config Class Initialized
INFO - 2024-12-14 05:45:46 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:45:46 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:45:46 --> Utf8 Class Initialized
INFO - 2024-12-14 05:45:46 --> URI Class Initialized
DEBUG - 2024-12-14 05:45:46 --> No URI present. Default controller set.
INFO - 2024-12-14 05:45:46 --> Router Class Initialized
INFO - 2024-12-14 05:45:46 --> Output Class Initialized
INFO - 2024-12-14 05:45:46 --> Security Class Initialized
DEBUG - 2024-12-14 05:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:45:46 --> Input Class Initialized
INFO - 2024-12-14 05:45:46 --> Language Class Initialized
INFO - 2024-12-14 05:45:46 --> Loader Class Initialized
INFO - 2024-12-14 05:45:46 --> Helper loaded: url_helper
INFO - 2024-12-14 05:45:46 --> Helper loaded: form_helper
INFO - 2024-12-14 05:45:46 --> Helper loaded: file_helper
INFO - 2024-12-14 05:45:46 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:45:47 --> Form Validation Class Initialized
INFO - 2024-12-14 05:45:47 --> Upload Class Initialized
INFO - 2024-12-14 05:45:47 --> Model "M_login" initialized
INFO - 2024-12-14 05:45:47 --> Model "M_home" initialized
INFO - 2024-12-14 05:45:47 --> Model "M_setting" initialized
INFO - 2024-12-14 05:45:47 --> Controller Class Initialized
INFO - 2024-12-14 05:45:47 --> Model "M_guru" initialized
INFO - 2024-12-14 05:45:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:45:47 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:45:47 --> Final output sent to browser
DEBUG - 2024-12-14 05:45:47 --> Total execution time: 0.1448
INFO - 2024-12-14 05:46:02 --> Config Class Initialized
INFO - 2024-12-14 05:46:02 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:46:02 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:02 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:02 --> URI Class Initialized
INFO - 2024-12-14 05:46:02 --> Router Class Initialized
INFO - 2024-12-14 05:46:02 --> Output Class Initialized
INFO - 2024-12-14 05:46:02 --> Security Class Initialized
DEBUG - 2024-12-14 05:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:46:02 --> Input Class Initialized
INFO - 2024-12-14 05:46:02 --> Language Class Initialized
ERROR - 2024-12-14 05:46:02 --> 404 Page Not Found: Courseshtml/index
INFO - 2024-12-14 05:46:05 --> Config Class Initialized
INFO - 2024-12-14 05:46:05 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:46:05 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:05 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:05 --> URI Class Initialized
DEBUG - 2024-12-14 05:46:05 --> No URI present. Default controller set.
INFO - 2024-12-14 05:46:05 --> Router Class Initialized
INFO - 2024-12-14 05:46:05 --> Output Class Initialized
INFO - 2024-12-14 05:46:05 --> Security Class Initialized
DEBUG - 2024-12-14 05:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:46:05 --> Input Class Initialized
INFO - 2024-12-14 05:46:05 --> Language Class Initialized
INFO - 2024-12-14 05:46:05 --> Loader Class Initialized
INFO - 2024-12-14 05:46:05 --> Helper loaded: url_helper
INFO - 2024-12-14 05:46:05 --> Helper loaded: form_helper
INFO - 2024-12-14 05:46:05 --> Helper loaded: file_helper
INFO - 2024-12-14 05:46:05 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:46:05 --> Form Validation Class Initialized
INFO - 2024-12-14 05:46:05 --> Upload Class Initialized
INFO - 2024-12-14 05:46:05 --> Model "M_login" initialized
INFO - 2024-12-14 05:46:05 --> Model "M_home" initialized
INFO - 2024-12-14 05:46:05 --> Model "M_setting" initialized
INFO - 2024-12-14 05:46:05 --> Controller Class Initialized
INFO - 2024-12-14 05:46:05 --> Model "M_guru" initialized
INFO - 2024-12-14 05:46:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:46:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:46:05 --> Final output sent to browser
DEBUG - 2024-12-14 05:46:05 --> Total execution time: 0.2156
INFO - 2024-12-14 05:46:10 --> Config Class Initialized
INFO - 2024-12-14 05:46:10 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:46:10 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:10 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:10 --> URI Class Initialized
INFO - 2024-12-14 05:46:10 --> Router Class Initialized
INFO - 2024-12-14 05:46:10 --> Output Class Initialized
INFO - 2024-12-14 05:46:10 --> Security Class Initialized
DEBUG - 2024-12-14 05:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:46:10 --> Input Class Initialized
INFO - 2024-12-14 05:46:10 --> Language Class Initialized
INFO - 2024-12-14 05:46:10 --> Loader Class Initialized
INFO - 2024-12-14 05:46:10 --> Helper loaded: url_helper
INFO - 2024-12-14 05:46:10 --> Helper loaded: form_helper
INFO - 2024-12-14 05:46:10 --> Helper loaded: file_helper
INFO - 2024-12-14 05:46:10 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:46:10 --> Form Validation Class Initialized
INFO - 2024-12-14 05:46:10 --> Upload Class Initialized
INFO - 2024-12-14 05:46:10 --> Model "M_login" initialized
INFO - 2024-12-14 05:46:10 --> Model "M_home" initialized
INFO - 2024-12-14 05:46:10 --> Model "M_setting" initialized
INFO - 2024-12-14 05:46:10 --> Controller Class Initialized
INFO - 2024-12-14 05:46:10 --> Model "M_guru" initialized
INFO - 2024-12-14 05:46:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-14 05:46:10 --> Pagination Class Initialized
INFO - 2024-12-14 05:46:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-14 05:46:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 05:46:10 --> Final output sent to browser
DEBUG - 2024-12-14 05:46:10 --> Total execution time: 0.1737
INFO - 2024-12-14 05:46:14 --> Config Class Initialized
INFO - 2024-12-14 05:46:14 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:46:14 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:14 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:14 --> URI Class Initialized
DEBUG - 2024-12-14 05:46:14 --> No URI present. Default controller set.
INFO - 2024-12-14 05:46:14 --> Router Class Initialized
INFO - 2024-12-14 05:46:14 --> Output Class Initialized
INFO - 2024-12-14 05:46:14 --> Security Class Initialized
DEBUG - 2024-12-14 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:46:14 --> Input Class Initialized
INFO - 2024-12-14 05:46:14 --> Language Class Initialized
INFO - 2024-12-14 05:46:14 --> Loader Class Initialized
INFO - 2024-12-14 05:46:14 --> Helper loaded: url_helper
INFO - 2024-12-14 05:46:14 --> Helper loaded: form_helper
INFO - 2024-12-14 05:46:14 --> Helper loaded: file_helper
INFO - 2024-12-14 05:46:14 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:46:14 --> Form Validation Class Initialized
INFO - 2024-12-14 05:46:14 --> Upload Class Initialized
INFO - 2024-12-14 05:46:14 --> Model "M_login" initialized
INFO - 2024-12-14 05:46:14 --> Model "M_home" initialized
INFO - 2024-12-14 05:46:14 --> Model "M_setting" initialized
INFO - 2024-12-14 05:46:14 --> Controller Class Initialized
INFO - 2024-12-14 05:46:14 --> Model "M_guru" initialized
INFO - 2024-12-14 05:46:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:46:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:46:14 --> Final output sent to browser
DEBUG - 2024-12-14 05:46:14 --> Total execution time: 0.1638
INFO - 2024-12-14 05:46:14 --> Config Class Initialized
INFO - 2024-12-14 05:46:14 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:46:14 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:14 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:14 --> URI Class Initialized
INFO - 2024-12-14 05:46:14 --> Router Class Initialized
INFO - 2024-12-14 05:46:14 --> Output Class Initialized
INFO - 2024-12-14 05:46:14 --> Config Class Initialized
INFO - 2024-12-14 05:46:14 --> Security Class Initialized
INFO - 2024-12-14 05:46:14 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:46:14 --> Input Class Initialized
DEBUG - 2024-12-14 05:46:14 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:14 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:14 --> Language Class Initialized
ERROR - 2024-12-14 05:46:14 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-14 05:46:14 --> URI Class Initialized
INFO - 2024-12-14 05:46:14 --> Config Class Initialized
INFO - 2024-12-14 05:46:14 --> Hooks Class Initialized
INFO - 2024-12-14 05:46:14 --> Router Class Initialized
DEBUG - 2024-12-14 05:46:14 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:14 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:14 --> Output Class Initialized
INFO - 2024-12-14 05:46:14 --> URI Class Initialized
INFO - 2024-12-14 05:46:14 --> Security Class Initialized
INFO - 2024-12-14 05:46:14 --> Router Class Initialized
INFO - 2024-12-14 05:46:14 --> Output Class Initialized
DEBUG - 2024-12-14 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:46:14 --> Input Class Initialized
INFO - 2024-12-14 05:46:14 --> Security Class Initialized
INFO - 2024-12-14 05:46:14 --> Language Class Initialized
DEBUG - 2024-12-14 05:46:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-12-14 05:46:14 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-14 05:46:14 --> Input Class Initialized
INFO - 2024-12-14 05:46:14 --> Language Class Initialized
ERROR - 2024-12-14 05:46:14 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-14 05:46:28 --> Config Class Initialized
INFO - 2024-12-14 05:46:28 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:46:28 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:28 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:28 --> URI Class Initialized
INFO - 2024-12-14 05:46:28 --> Router Class Initialized
INFO - 2024-12-14 05:46:28 --> Output Class Initialized
INFO - 2024-12-14 05:46:28 --> Security Class Initialized
DEBUG - 2024-12-14 05:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:46:28 --> Input Class Initialized
INFO - 2024-12-14 05:46:28 --> Language Class Initialized
INFO - 2024-12-14 05:46:28 --> Loader Class Initialized
INFO - 2024-12-14 05:46:28 --> Helper loaded: url_helper
INFO - 2024-12-14 05:46:28 --> Helper loaded: form_helper
INFO - 2024-12-14 05:46:28 --> Helper loaded: file_helper
INFO - 2024-12-14 05:46:28 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:46:28 --> Form Validation Class Initialized
INFO - 2024-12-14 05:46:28 --> Upload Class Initialized
INFO - 2024-12-14 05:46:28 --> Model "M_login" initialized
INFO - 2024-12-14 05:46:28 --> Model "M_home" initialized
INFO - 2024-12-14 05:46:28 --> Model "M_setting" initialized
INFO - 2024-12-14 05:46:28 --> Controller Class Initialized
INFO - 2024-12-14 05:46:28 --> Model "M_guru" initialized
INFO - 2024-12-14 05:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-14 05:46:28 --> Pagination Class Initialized
INFO - 2024-12-14 05:46:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-14 05:46:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 05:46:28 --> Final output sent to browser
DEBUG - 2024-12-14 05:46:28 --> Total execution time: 0.1620
INFO - 2024-12-14 05:46:48 --> Config Class Initialized
INFO - 2024-12-14 05:46:48 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:46:48 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:46:48 --> Utf8 Class Initialized
INFO - 2024-12-14 05:46:48 --> URI Class Initialized
INFO - 2024-12-14 05:46:48 --> Router Class Initialized
INFO - 2024-12-14 05:46:48 --> Output Class Initialized
INFO - 2024-12-14 05:46:48 --> Security Class Initialized
DEBUG - 2024-12-14 05:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:46:48 --> Input Class Initialized
INFO - 2024-12-14 05:46:49 --> Language Class Initialized
INFO - 2024-12-14 05:46:49 --> Loader Class Initialized
INFO - 2024-12-14 05:46:49 --> Helper loaded: url_helper
INFO - 2024-12-14 05:46:49 --> Helper loaded: form_helper
INFO - 2024-12-14 05:46:49 --> Helper loaded: file_helper
INFO - 2024-12-14 05:46:49 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:46:49 --> Form Validation Class Initialized
INFO - 2024-12-14 05:46:49 --> Upload Class Initialized
INFO - 2024-12-14 05:46:49 --> Model "M_login" initialized
INFO - 2024-12-14 05:46:49 --> Model "M_home" initialized
INFO - 2024-12-14 05:46:49 --> Model "M_setting" initialized
INFO - 2024-12-14 05:46:49 --> Controller Class Initialized
INFO - 2024-12-14 05:46:49 --> Model "M_guru" initialized
INFO - 2024-12-14 05:46:49 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-14 05:46:49 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 05:46:49 --> Final output sent to browser
DEBUG - 2024-12-14 05:46:49 --> Total execution time: 0.1965
INFO - 2024-12-14 05:49:05 --> Config Class Initialized
INFO - 2024-12-14 05:49:05 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:49:05 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:49:05 --> Utf8 Class Initialized
INFO - 2024-12-14 05:49:05 --> URI Class Initialized
DEBUG - 2024-12-14 05:49:05 --> No URI present. Default controller set.
INFO - 2024-12-14 05:49:05 --> Router Class Initialized
INFO - 2024-12-14 05:49:05 --> Output Class Initialized
INFO - 2024-12-14 05:49:05 --> Security Class Initialized
DEBUG - 2024-12-14 05:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:49:05 --> Input Class Initialized
INFO - 2024-12-14 05:49:05 --> Language Class Initialized
INFO - 2024-12-14 05:49:05 --> Loader Class Initialized
INFO - 2024-12-14 05:49:05 --> Helper loaded: url_helper
INFO - 2024-12-14 05:49:05 --> Helper loaded: form_helper
INFO - 2024-12-14 05:49:05 --> Helper loaded: file_helper
INFO - 2024-12-14 05:49:05 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:49:05 --> Form Validation Class Initialized
INFO - 2024-12-14 05:49:05 --> Upload Class Initialized
INFO - 2024-12-14 05:49:05 --> Model "M_login" initialized
INFO - 2024-12-14 05:49:05 --> Model "M_home" initialized
INFO - 2024-12-14 05:49:05 --> Model "M_setting" initialized
INFO - 2024-12-14 05:49:05 --> Controller Class Initialized
INFO - 2024-12-14 05:49:05 --> Model "M_guru" initialized
INFO - 2024-12-14 05:49:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:49:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:49:05 --> Final output sent to browser
DEBUG - 2024-12-14 05:49:05 --> Total execution time: 0.1166
INFO - 2024-12-14 05:49:06 --> Config Class Initialized
INFO - 2024-12-14 05:49:06 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:49:06 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:49:06 --> Utf8 Class Initialized
INFO - 2024-12-14 05:49:06 --> URI Class Initialized
INFO - 2024-12-14 05:49:06 --> Router Class Initialized
INFO - 2024-12-14 05:49:06 --> Output Class Initialized
INFO - 2024-12-14 05:49:06 --> Security Class Initialized
DEBUG - 2024-12-14 05:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:49:06 --> Input Class Initialized
INFO - 2024-12-14 05:49:06 --> Language Class Initialized
ERROR - 2024-12-14 05:49:06 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-14 05:49:06 --> Config Class Initialized
INFO - 2024-12-14 05:49:06 --> Hooks Class Initialized
INFO - 2024-12-14 05:49:06 --> Config Class Initialized
INFO - 2024-12-14 05:49:06 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:49:06 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:49:06 --> Utf8 Class Initialized
DEBUG - 2024-12-14 05:49:06 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:49:06 --> Utf8 Class Initialized
INFO - 2024-12-14 05:49:06 --> URI Class Initialized
INFO - 2024-12-14 05:49:06 --> URI Class Initialized
INFO - 2024-12-14 05:49:06 --> Router Class Initialized
INFO - 2024-12-14 05:49:06 --> Router Class Initialized
INFO - 2024-12-14 05:49:06 --> Output Class Initialized
INFO - 2024-12-14 05:49:06 --> Security Class Initialized
INFO - 2024-12-14 05:49:06 --> Output Class Initialized
DEBUG - 2024-12-14 05:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:49:06 --> Input Class Initialized
INFO - 2024-12-14 05:49:06 --> Language Class Initialized
INFO - 2024-12-14 05:49:06 --> Security Class Initialized
DEBUG - 2024-12-14 05:49:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-12-14 05:49:06 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-14 05:49:06 --> Input Class Initialized
INFO - 2024-12-14 05:49:06 --> Language Class Initialized
ERROR - 2024-12-14 05:49:06 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-14 05:49:20 --> Config Class Initialized
INFO - 2024-12-14 05:49:20 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:49:20 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:49:20 --> Utf8 Class Initialized
INFO - 2024-12-14 05:49:20 --> URI Class Initialized
INFO - 2024-12-14 05:49:20 --> Router Class Initialized
INFO - 2024-12-14 05:49:20 --> Output Class Initialized
INFO - 2024-12-14 05:49:20 --> Security Class Initialized
DEBUG - 2024-12-14 05:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:49:20 --> Input Class Initialized
INFO - 2024-12-14 05:49:20 --> Language Class Initialized
INFO - 2024-12-14 05:49:20 --> Loader Class Initialized
INFO - 2024-12-14 05:49:20 --> Helper loaded: url_helper
INFO - 2024-12-14 05:49:20 --> Helper loaded: form_helper
INFO - 2024-12-14 05:49:20 --> Helper loaded: file_helper
INFO - 2024-12-14 05:49:20 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:49:20 --> Form Validation Class Initialized
INFO - 2024-12-14 05:49:20 --> Upload Class Initialized
INFO - 2024-12-14 05:49:20 --> Model "M_login" initialized
INFO - 2024-12-14 05:49:20 --> Model "M_home" initialized
INFO - 2024-12-14 05:49:20 --> Model "M_setting" initialized
INFO - 2024-12-14 05:49:20 --> Controller Class Initialized
INFO - 2024-12-14 05:49:20 --> Model "M_guru" initialized
INFO - 2024-12-14 05:49:20 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-14 05:49:20 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 05:49:20 --> Final output sent to browser
DEBUG - 2024-12-14 05:49:20 --> Total execution time: 0.1460
INFO - 2024-12-14 05:49:54 --> Config Class Initialized
INFO - 2024-12-14 05:49:54 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:49:54 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:49:54 --> Utf8 Class Initialized
INFO - 2024-12-14 05:49:54 --> URI Class Initialized
INFO - 2024-12-14 05:49:54 --> Router Class Initialized
INFO - 2024-12-14 05:49:54 --> Output Class Initialized
INFO - 2024-12-14 05:49:54 --> Security Class Initialized
DEBUG - 2024-12-14 05:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:49:54 --> Input Class Initialized
INFO - 2024-12-14 05:49:54 --> Language Class Initialized
INFO - 2024-12-14 05:49:54 --> Loader Class Initialized
INFO - 2024-12-14 05:49:54 --> Helper loaded: url_helper
INFO - 2024-12-14 05:49:54 --> Helper loaded: form_helper
INFO - 2024-12-14 05:49:54 --> Helper loaded: file_helper
INFO - 2024-12-14 05:49:54 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:49:54 --> Form Validation Class Initialized
INFO - 2024-12-14 05:49:54 --> Upload Class Initialized
INFO - 2024-12-14 05:49:54 --> Model "M_login" initialized
INFO - 2024-12-14 05:49:54 --> Model "M_home" initialized
INFO - 2024-12-14 05:49:54 --> Model "M_setting" initialized
INFO - 2024-12-14 05:49:54 --> Controller Class Initialized
INFO - 2024-12-14 05:49:54 --> Model "M_guru" initialized
INFO - 2024-12-14 05:49:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-14 05:49:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 05:49:54 --> Final output sent to browser
DEBUG - 2024-12-14 05:49:54 --> Total execution time: 0.1270
INFO - 2024-12-14 05:51:33 --> Config Class Initialized
INFO - 2024-12-14 05:51:33 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:51:33 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:51:33 --> Utf8 Class Initialized
INFO - 2024-12-14 05:51:33 --> URI Class Initialized
INFO - 2024-12-14 05:51:33 --> Router Class Initialized
INFO - 2024-12-14 05:51:33 --> Output Class Initialized
INFO - 2024-12-14 05:51:33 --> Security Class Initialized
DEBUG - 2024-12-14 05:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:51:33 --> Input Class Initialized
INFO - 2024-12-14 05:51:33 --> Language Class Initialized
ERROR - 2024-12-14 05:51:33 --> 404 Page Not Found: Home/index.html
INFO - 2024-12-14 05:51:44 --> Config Class Initialized
INFO - 2024-12-14 05:51:44 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:51:44 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:51:44 --> Utf8 Class Initialized
INFO - 2024-12-14 05:51:44 --> URI Class Initialized
INFO - 2024-12-14 05:51:44 --> Router Class Initialized
INFO - 2024-12-14 05:51:44 --> Output Class Initialized
INFO - 2024-12-14 05:51:44 --> Security Class Initialized
DEBUG - 2024-12-14 05:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:51:44 --> Input Class Initialized
INFO - 2024-12-14 05:51:44 --> Language Class Initialized
INFO - 2024-12-14 05:51:44 --> Loader Class Initialized
INFO - 2024-12-14 05:51:44 --> Helper loaded: url_helper
INFO - 2024-12-14 05:51:44 --> Helper loaded: form_helper
INFO - 2024-12-14 05:51:44 --> Helper loaded: file_helper
INFO - 2024-12-14 05:51:44 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:51:44 --> Form Validation Class Initialized
INFO - 2024-12-14 05:51:44 --> Upload Class Initialized
INFO - 2024-12-14 05:51:44 --> Model "M_login" initialized
INFO - 2024-12-14 05:51:44 --> Model "M_home" initialized
INFO - 2024-12-14 05:51:44 --> Model "M_setting" initialized
INFO - 2024-12-14 05:51:44 --> Controller Class Initialized
INFO - 2024-12-14 05:51:44 --> Model "M_guru" initialized
INFO - 2024-12-14 05:51:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-14 05:51:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 05:51:44 --> Final output sent to browser
DEBUG - 2024-12-14 05:51:44 --> Total execution time: 0.1492
INFO - 2024-12-14 05:51:53 --> Config Class Initialized
INFO - 2024-12-14 05:51:53 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:51:53 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:51:53 --> Utf8 Class Initialized
INFO - 2024-12-14 05:51:53 --> URI Class Initialized
INFO - 2024-12-14 05:51:53 --> Router Class Initialized
INFO - 2024-12-14 05:51:53 --> Output Class Initialized
INFO - 2024-12-14 05:51:53 --> Security Class Initialized
DEBUG - 2024-12-14 05:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:51:53 --> Input Class Initialized
INFO - 2024-12-14 05:51:53 --> Language Class Initialized
ERROR - 2024-12-14 05:51:53 --> 404 Page Not Found: Home/index.html
INFO - 2024-12-14 05:51:56 --> Config Class Initialized
INFO - 2024-12-14 05:51:56 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:51:56 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:51:56 --> Utf8 Class Initialized
INFO - 2024-12-14 05:51:56 --> URI Class Initialized
INFO - 2024-12-14 05:51:56 --> Router Class Initialized
INFO - 2024-12-14 05:51:56 --> Output Class Initialized
INFO - 2024-12-14 05:51:56 --> Security Class Initialized
DEBUG - 2024-12-14 05:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:51:56 --> Input Class Initialized
INFO - 2024-12-14 05:51:56 --> Language Class Initialized
INFO - 2024-12-14 05:51:56 --> Loader Class Initialized
INFO - 2024-12-14 05:51:56 --> Helper loaded: url_helper
INFO - 2024-12-14 05:51:56 --> Helper loaded: form_helper
INFO - 2024-12-14 05:51:56 --> Helper loaded: file_helper
INFO - 2024-12-14 05:51:56 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:51:56 --> Form Validation Class Initialized
INFO - 2024-12-14 05:51:56 --> Upload Class Initialized
INFO - 2024-12-14 05:51:56 --> Model "M_login" initialized
INFO - 2024-12-14 05:51:56 --> Model "M_home" initialized
INFO - 2024-12-14 05:51:56 --> Model "M_setting" initialized
INFO - 2024-12-14 05:51:56 --> Controller Class Initialized
INFO - 2024-12-14 05:51:56 --> Model "M_guru" initialized
INFO - 2024-12-14 05:51:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-14 05:51:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 05:51:56 --> Final output sent to browser
DEBUG - 2024-12-14 05:51:56 --> Total execution time: 0.1466
INFO - 2024-12-14 05:52:03 --> Config Class Initialized
INFO - 2024-12-14 05:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:52:03 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:52:03 --> Utf8 Class Initialized
INFO - 2024-12-14 05:52:03 --> URI Class Initialized
DEBUG - 2024-12-14 05:52:03 --> No URI present. Default controller set.
INFO - 2024-12-14 05:52:03 --> Router Class Initialized
INFO - 2024-12-14 05:52:03 --> Output Class Initialized
INFO - 2024-12-14 05:52:03 --> Security Class Initialized
DEBUG - 2024-12-14 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:52:03 --> Input Class Initialized
INFO - 2024-12-14 05:52:03 --> Language Class Initialized
INFO - 2024-12-14 05:52:03 --> Loader Class Initialized
INFO - 2024-12-14 05:52:03 --> Helper loaded: url_helper
INFO - 2024-12-14 05:52:03 --> Helper loaded: form_helper
INFO - 2024-12-14 05:52:03 --> Helper loaded: file_helper
INFO - 2024-12-14 05:52:03 --> Database Driver Class Initialized
DEBUG - 2024-12-14 05:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 05:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 05:52:04 --> Form Validation Class Initialized
INFO - 2024-12-14 05:52:04 --> Upload Class Initialized
INFO - 2024-12-14 05:52:04 --> Model "M_login" initialized
INFO - 2024-12-14 05:52:04 --> Model "M_home" initialized
INFO - 2024-12-14 05:52:04 --> Model "M_setting" initialized
INFO - 2024-12-14 05:52:04 --> Controller Class Initialized
INFO - 2024-12-14 05:52:04 --> Model "M_guru" initialized
INFO - 2024-12-14 05:52:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 05:52:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 05:52:04 --> Final output sent to browser
DEBUG - 2024-12-14 05:52:04 --> Total execution time: 0.1578
INFO - 2024-12-14 05:52:04 --> Config Class Initialized
INFO - 2024-12-14 05:52:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:52:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:52:04 --> Utf8 Class Initialized
INFO - 2024-12-14 05:52:04 --> URI Class Initialized
INFO - 2024-12-14 05:52:04 --> Router Class Initialized
INFO - 2024-12-14 05:52:04 --> Config Class Initialized
INFO - 2024-12-14 05:52:04 --> Hooks Class Initialized
INFO - 2024-12-14 05:52:04 --> Output Class Initialized
DEBUG - 2024-12-14 05:52:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:52:04 --> Utf8 Class Initialized
INFO - 2024-12-14 05:52:04 --> Security Class Initialized
INFO - 2024-12-14 05:52:04 --> URI Class Initialized
DEBUG - 2024-12-14 05:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:52:04 --> Router Class Initialized
INFO - 2024-12-14 05:52:04 --> Input Class Initialized
INFO - 2024-12-14 05:52:04 --> Language Class Initialized
INFO - 2024-12-14 05:52:04 --> Output Class Initialized
ERROR - 2024-12-14 05:52:04 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-14 05:52:04 --> Security Class Initialized
DEBUG - 2024-12-14 05:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:52:04 --> Input Class Initialized
INFO - 2024-12-14 05:52:04 --> Language Class Initialized
ERROR - 2024-12-14 05:52:04 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-14 05:52:04 --> Config Class Initialized
INFO - 2024-12-14 05:52:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 05:52:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 05:52:04 --> Utf8 Class Initialized
INFO - 2024-12-14 05:52:04 --> URI Class Initialized
INFO - 2024-12-14 05:52:04 --> Router Class Initialized
INFO - 2024-12-14 05:52:04 --> Output Class Initialized
INFO - 2024-12-14 05:52:04 --> Security Class Initialized
DEBUG - 2024-12-14 05:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 05:52:04 --> Input Class Initialized
INFO - 2024-12-14 05:52:04 --> Language Class Initialized
ERROR - 2024-12-14 05:52:04 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-14 06:05:17 --> Config Class Initialized
INFO - 2024-12-14 06:05:17 --> Hooks Class Initialized
DEBUG - 2024-12-14 06:05:17 --> UTF-8 Support Enabled
INFO - 2024-12-14 06:05:17 --> Utf8 Class Initialized
INFO - 2024-12-14 06:05:17 --> URI Class Initialized
INFO - 2024-12-14 06:05:17 --> Router Class Initialized
INFO - 2024-12-14 06:05:17 --> Output Class Initialized
INFO - 2024-12-14 06:05:17 --> Security Class Initialized
DEBUG - 2024-12-14 06:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 06:05:17 --> Input Class Initialized
INFO - 2024-12-14 06:05:17 --> Language Class Initialized
INFO - 2024-12-14 06:05:17 --> Loader Class Initialized
INFO - 2024-12-14 06:05:17 --> Helper loaded: url_helper
INFO - 2024-12-14 06:05:17 --> Helper loaded: form_helper
INFO - 2024-12-14 06:05:17 --> Helper loaded: file_helper
INFO - 2024-12-14 06:05:17 --> Database Driver Class Initialized
DEBUG - 2024-12-14 06:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 06:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 06:05:17 --> Form Validation Class Initialized
INFO - 2024-12-14 06:05:17 --> Upload Class Initialized
INFO - 2024-12-14 06:05:17 --> Model "M_login" initialized
INFO - 2024-12-14 06:05:17 --> Model "M_home" initialized
INFO - 2024-12-14 06:05:17 --> Model "M_setting" initialized
INFO - 2024-12-14 06:05:17 --> Controller Class Initialized
INFO - 2024-12-14 06:05:17 --> Model "M_guru" initialized
INFO - 2024-12-14 06:05:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-14 06:05:17 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 06:05:17 --> Final output sent to browser
DEBUG - 2024-12-14 06:05:17 --> Total execution time: 0.1555
INFO - 2024-12-14 06:08:32 --> Config Class Initialized
INFO - 2024-12-14 06:08:32 --> Hooks Class Initialized
DEBUG - 2024-12-14 06:08:32 --> UTF-8 Support Enabled
INFO - 2024-12-14 06:08:32 --> Utf8 Class Initialized
INFO - 2024-12-14 06:08:32 --> URI Class Initialized
INFO - 2024-12-14 06:08:32 --> Router Class Initialized
INFO - 2024-12-14 06:08:32 --> Output Class Initialized
INFO - 2024-12-14 06:08:32 --> Security Class Initialized
DEBUG - 2024-12-14 06:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 06:08:32 --> Input Class Initialized
INFO - 2024-12-14 06:08:32 --> Language Class Initialized
INFO - 2024-12-14 06:08:32 --> Loader Class Initialized
INFO - 2024-12-14 06:08:32 --> Helper loaded: url_helper
INFO - 2024-12-14 06:08:32 --> Helper loaded: form_helper
INFO - 2024-12-14 06:08:32 --> Helper loaded: file_helper
INFO - 2024-12-14 06:08:32 --> Database Driver Class Initialized
DEBUG - 2024-12-14 06:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 06:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 06:08:32 --> Form Validation Class Initialized
INFO - 2024-12-14 06:08:32 --> Upload Class Initialized
INFO - 2024-12-14 06:08:32 --> Model "M_login" initialized
INFO - 2024-12-14 06:08:32 --> Model "M_home" initialized
INFO - 2024-12-14 06:08:32 --> Model "M_setting" initialized
INFO - 2024-12-14 06:08:32 --> Controller Class Initialized
INFO - 2024-12-14 06:08:32 --> Model "M_guru" initialized
INFO - 2024-12-14 06:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-14 06:08:32 --> Pagination Class Initialized
INFO - 2024-12-14 06:08:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-14 06:08:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-14 06:08:32 --> Final output sent to browser
DEBUG - 2024-12-14 06:08:32 --> Total execution time: 0.1584
INFO - 2024-12-14 06:09:51 --> Config Class Initialized
INFO - 2024-12-14 06:09:51 --> Hooks Class Initialized
DEBUG - 2024-12-14 06:09:51 --> UTF-8 Support Enabled
INFO - 2024-12-14 06:09:51 --> Utf8 Class Initialized
INFO - 2024-12-14 06:09:51 --> URI Class Initialized
DEBUG - 2024-12-14 06:09:51 --> No URI present. Default controller set.
INFO - 2024-12-14 06:09:51 --> Router Class Initialized
INFO - 2024-12-14 06:09:51 --> Output Class Initialized
INFO - 2024-12-14 06:09:51 --> Security Class Initialized
DEBUG - 2024-12-14 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 06:09:51 --> Input Class Initialized
INFO - 2024-12-14 06:09:51 --> Language Class Initialized
INFO - 2024-12-14 06:09:52 --> Loader Class Initialized
INFO - 2024-12-14 06:09:52 --> Helper loaded: url_helper
INFO - 2024-12-14 06:09:52 --> Helper loaded: form_helper
INFO - 2024-12-14 06:09:52 --> Helper loaded: file_helper
INFO - 2024-12-14 06:09:52 --> Database Driver Class Initialized
DEBUG - 2024-12-14 06:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 06:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 06:09:52 --> Form Validation Class Initialized
INFO - 2024-12-14 06:09:52 --> Upload Class Initialized
INFO - 2024-12-14 06:09:52 --> Model "M_login" initialized
INFO - 2024-12-14 06:09:52 --> Model "M_home" initialized
INFO - 2024-12-14 06:09:52 --> Model "M_setting" initialized
INFO - 2024-12-14 06:09:52 --> Controller Class Initialized
INFO - 2024-12-14 06:09:52 --> Model "M_guru" initialized
INFO - 2024-12-14 06:09:52 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 06:09:52 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 06:09:52 --> Final output sent to browser
DEBUG - 2024-12-14 06:09:52 --> Total execution time: 0.1443
INFO - 2024-12-14 06:09:52 --> Config Class Initialized
INFO - 2024-12-14 06:09:52 --> Hooks Class Initialized
INFO - 2024-12-14 06:09:52 --> Config Class Initialized
INFO - 2024-12-14 06:09:52 --> Hooks Class Initialized
DEBUG - 2024-12-14 06:09:52 --> UTF-8 Support Enabled
INFO - 2024-12-14 06:09:52 --> Utf8 Class Initialized
INFO - 2024-12-14 06:09:52 --> URI Class Initialized
DEBUG - 2024-12-14 06:09:52 --> UTF-8 Support Enabled
INFO - 2024-12-14 06:09:52 --> Utf8 Class Initialized
INFO - 2024-12-14 06:09:52 --> URI Class Initialized
INFO - 2024-12-14 06:09:52 --> Router Class Initialized
INFO - 2024-12-14 06:09:52 --> Router Class Initialized
INFO - 2024-12-14 06:09:52 --> Output Class Initialized
INFO - 2024-12-14 06:09:52 --> Security Class Initialized
INFO - 2024-12-14 06:09:52 --> Output Class Initialized
INFO - 2024-12-14 06:09:52 --> Security Class Initialized
DEBUG - 2024-12-14 06:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 06:09:52 --> Input Class Initialized
DEBUG - 2024-12-14 06:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 06:09:52 --> Input Class Initialized
INFO - 2024-12-14 06:09:52 --> Language Class Initialized
INFO - 2024-12-14 06:09:52 --> Language Class Initialized
ERROR - 2024-12-14 06:09:52 --> 404 Page Not Found: Images/courses_background.jpg
ERROR - 2024-12-14 06:09:52 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-14 06:09:52 --> Config Class Initialized
INFO - 2024-12-14 06:09:52 --> Hooks Class Initialized
DEBUG - 2024-12-14 06:09:52 --> UTF-8 Support Enabled
INFO - 2024-12-14 06:09:52 --> Utf8 Class Initialized
INFO - 2024-12-14 06:09:52 --> URI Class Initialized
INFO - 2024-12-14 06:09:52 --> Router Class Initialized
INFO - 2024-12-14 06:09:52 --> Output Class Initialized
INFO - 2024-12-14 06:09:52 --> Security Class Initialized
DEBUG - 2024-12-14 06:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 06:09:53 --> Input Class Initialized
INFO - 2024-12-14 06:09:53 --> Language Class Initialized
ERROR - 2024-12-14 06:09:53 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-14 21:56:44 --> Config Class Initialized
INFO - 2024-12-14 21:56:44 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:56:44 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:56:44 --> Utf8 Class Initialized
INFO - 2024-12-14 21:56:44 --> URI Class Initialized
DEBUG - 2024-12-14 21:56:44 --> No URI present. Default controller set.
INFO - 2024-12-14 21:56:44 --> Router Class Initialized
INFO - 2024-12-14 21:56:44 --> Output Class Initialized
INFO - 2024-12-14 21:56:44 --> Security Class Initialized
DEBUG - 2024-12-14 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:56:44 --> Input Class Initialized
INFO - 2024-12-14 21:56:44 --> Language Class Initialized
INFO - 2024-12-14 21:56:44 --> Loader Class Initialized
INFO - 2024-12-14 21:56:44 --> Helper loaded: url_helper
INFO - 2024-12-14 21:56:44 --> Helper loaded: form_helper
INFO - 2024-12-14 21:56:44 --> Helper loaded: file_helper
INFO - 2024-12-14 21:56:44 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:56:44 --> Form Validation Class Initialized
INFO - 2024-12-14 21:56:44 --> Upload Class Initialized
INFO - 2024-12-14 21:56:44 --> Model "M_login" initialized
INFO - 2024-12-14 21:56:44 --> Model "M_home" initialized
INFO - 2024-12-14 21:56:44 --> Model "M_setting" initialized
INFO - 2024-12-14 21:56:44 --> Controller Class Initialized
INFO - 2024-12-14 21:56:44 --> Model "M_guru" initialized
INFO - 2024-12-14 21:56:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-14 21:56:44 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-14 21:56:44 --> Final output sent to browser
DEBUG - 2024-12-14 21:56:44 --> Total execution time: 0.0942
INFO - 2024-12-14 21:56:45 --> Config Class Initialized
INFO - 2024-12-14 21:56:45 --> Hooks Class Initialized
INFO - 2024-12-14 21:56:45 --> Config Class Initialized
INFO - 2024-12-14 21:56:45 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:56:45 --> UTF-8 Support Enabled
DEBUG - 2024-12-14 21:56:45 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:56:45 --> Utf8 Class Initialized
INFO - 2024-12-14 21:56:45 --> Utf8 Class Initialized
INFO - 2024-12-14 21:56:45 --> URI Class Initialized
INFO - 2024-12-14 21:56:45 --> URI Class Initialized
INFO - 2024-12-14 21:56:45 --> Router Class Initialized
INFO - 2024-12-14 21:56:45 --> Router Class Initialized
INFO - 2024-12-14 21:56:45 --> Output Class Initialized
INFO - 2024-12-14 21:56:45 --> Output Class Initialized
INFO - 2024-12-14 21:56:45 --> Security Class Initialized
INFO - 2024-12-14 21:56:45 --> Security Class Initialized
DEBUG - 2024-12-14 21:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:56:45 --> Input Class Initialized
INFO - 2024-12-14 21:56:45 --> Language Class Initialized
ERROR - 2024-12-14 21:56:45 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-14 21:56:45 --> Config Class Initialized
INFO - 2024-12-14 21:56:45 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:56:45 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:56:45 --> Utf8 Class Initialized
INFO - 2024-12-14 21:56:45 --> URI Class Initialized
DEBUG - 2024-12-14 21:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:56:45 --> Input Class Initialized
INFO - 2024-12-14 21:56:45 --> Router Class Initialized
INFO - 2024-12-14 21:56:45 --> Language Class Initialized
INFO - 2024-12-14 21:56:45 --> Output Class Initialized
ERROR - 2024-12-14 21:56:45 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-14 21:56:45 --> Security Class Initialized
DEBUG - 2024-12-14 21:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:56:45 --> Input Class Initialized
INFO - 2024-12-14 21:56:45 --> Language Class Initialized
ERROR - 2024-12-14 21:56:45 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-14 21:56:52 --> Config Class Initialized
INFO - 2024-12-14 21:56:52 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:56:52 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:56:52 --> Utf8 Class Initialized
INFO - 2024-12-14 21:56:52 --> URI Class Initialized
INFO - 2024-12-14 21:56:52 --> Router Class Initialized
INFO - 2024-12-14 21:56:52 --> Output Class Initialized
INFO - 2024-12-14 21:56:52 --> Security Class Initialized
DEBUG - 2024-12-14 21:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:56:52 --> Input Class Initialized
INFO - 2024-12-14 21:56:52 --> Language Class Initialized
INFO - 2024-12-14 21:56:52 --> Loader Class Initialized
INFO - 2024-12-14 21:56:52 --> Helper loaded: url_helper
INFO - 2024-12-14 21:56:52 --> Helper loaded: form_helper
INFO - 2024-12-14 21:56:52 --> Helper loaded: file_helper
INFO - 2024-12-14 21:56:52 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:56:52 --> Form Validation Class Initialized
INFO - 2024-12-14 21:56:52 --> Upload Class Initialized
INFO - 2024-12-14 21:56:52 --> Model "M_login" initialized
INFO - 2024-12-14 21:56:52 --> Model "M_home" initialized
INFO - 2024-12-14 21:56:52 --> Model "M_setting" initialized
INFO - 2024-12-14 21:56:52 --> Controller Class Initialized
INFO - 2024-12-14 21:56:52 --> Config Class Initialized
INFO - 2024-12-14 21:56:52 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:56:52 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:56:52 --> Utf8 Class Initialized
INFO - 2024-12-14 21:56:52 --> URI Class Initialized
INFO - 2024-12-14 21:56:52 --> Router Class Initialized
INFO - 2024-12-14 21:56:52 --> Output Class Initialized
INFO - 2024-12-14 21:56:52 --> Security Class Initialized
DEBUG - 2024-12-14 21:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:56:52 --> Input Class Initialized
INFO - 2024-12-14 21:56:52 --> Language Class Initialized
INFO - 2024-12-14 21:56:52 --> Loader Class Initialized
INFO - 2024-12-14 21:56:52 --> Helper loaded: url_helper
INFO - 2024-12-14 21:56:52 --> Helper loaded: form_helper
INFO - 2024-12-14 21:56:52 --> Helper loaded: file_helper
INFO - 2024-12-14 21:56:52 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:56:52 --> Form Validation Class Initialized
INFO - 2024-12-14 21:56:52 --> Upload Class Initialized
INFO - 2024-12-14 21:56:52 --> Model "M_login" initialized
INFO - 2024-12-14 21:56:52 --> Model "M_home" initialized
INFO - 2024-12-14 21:56:52 --> Model "M_setting" initialized
INFO - 2024-12-14 21:56:52 --> Controller Class Initialized
INFO - 2024-12-14 21:56:52 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_login.php
INFO - 2024-12-14 21:56:52 --> Final output sent to browser
DEBUG - 2024-12-14 21:56:52 --> Total execution time: 0.0461
INFO - 2024-12-14 21:56:54 --> Config Class Initialized
INFO - 2024-12-14 21:56:54 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:56:54 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:56:54 --> Utf8 Class Initialized
INFO - 2024-12-14 21:56:54 --> URI Class Initialized
INFO - 2024-12-14 21:56:54 --> Router Class Initialized
INFO - 2024-12-14 21:56:54 --> Output Class Initialized
INFO - 2024-12-14 21:56:54 --> Security Class Initialized
DEBUG - 2024-12-14 21:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:56:54 --> Input Class Initialized
INFO - 2024-12-14 21:56:54 --> Language Class Initialized
INFO - 2024-12-14 21:56:54 --> Loader Class Initialized
INFO - 2024-12-14 21:56:54 --> Helper loaded: url_helper
INFO - 2024-12-14 21:56:54 --> Helper loaded: form_helper
INFO - 2024-12-14 21:56:54 --> Helper loaded: file_helper
INFO - 2024-12-14 21:56:54 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:56:54 --> Form Validation Class Initialized
INFO - 2024-12-14 21:56:54 --> Upload Class Initialized
INFO - 2024-12-14 21:56:54 --> Model "M_login" initialized
INFO - 2024-12-14 21:56:54 --> Model "M_home" initialized
INFO - 2024-12-14 21:56:54 --> Model "M_setting" initialized
INFO - 2024-12-14 21:56:54 --> Controller Class Initialized
INFO - 2024-12-14 21:56:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-14 21:56:54 --> Config Class Initialized
INFO - 2024-12-14 21:56:54 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:56:54 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:56:54 --> Utf8 Class Initialized
INFO - 2024-12-14 21:56:54 --> URI Class Initialized
INFO - 2024-12-14 21:56:54 --> Router Class Initialized
INFO - 2024-12-14 21:56:54 --> Output Class Initialized
INFO - 2024-12-14 21:56:54 --> Security Class Initialized
DEBUG - 2024-12-14 21:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:56:54 --> Input Class Initialized
INFO - 2024-12-14 21:56:54 --> Language Class Initialized
INFO - 2024-12-14 21:56:54 --> Loader Class Initialized
INFO - 2024-12-14 21:56:54 --> Helper loaded: url_helper
INFO - 2024-12-14 21:56:54 --> Helper loaded: form_helper
INFO - 2024-12-14 21:56:54 --> Helper loaded: file_helper
INFO - 2024-12-14 21:56:54 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:56:54 --> Form Validation Class Initialized
INFO - 2024-12-14 21:56:54 --> Upload Class Initialized
INFO - 2024-12-14 21:56:54 --> Model "M_login" initialized
INFO - 2024-12-14 21:56:54 --> Model "M_home" initialized
INFO - 2024-12-14 21:56:54 --> Model "M_setting" initialized
INFO - 2024-12-14 21:56:54 --> Controller Class Initialized
INFO - 2024-12-14 21:56:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_login.php
INFO - 2024-12-14 21:56:54 --> Final output sent to browser
DEBUG - 2024-12-14 21:56:54 --> Total execution time: 0.0428
INFO - 2024-12-14 21:57:04 --> Config Class Initialized
INFO - 2024-12-14 21:57:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:57:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:57:04 --> Utf8 Class Initialized
INFO - 2024-12-14 21:57:04 --> URI Class Initialized
INFO - 2024-12-14 21:57:04 --> Router Class Initialized
INFO - 2024-12-14 21:57:04 --> Output Class Initialized
INFO - 2024-12-14 21:57:04 --> Security Class Initialized
DEBUG - 2024-12-14 21:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:57:04 --> Input Class Initialized
INFO - 2024-12-14 21:57:04 --> Language Class Initialized
INFO - 2024-12-14 21:57:04 --> Loader Class Initialized
INFO - 2024-12-14 21:57:04 --> Helper loaded: url_helper
INFO - 2024-12-14 21:57:04 --> Helper loaded: form_helper
INFO - 2024-12-14 21:57:04 --> Helper loaded: file_helper
INFO - 2024-12-14 21:57:04 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:57:04 --> Form Validation Class Initialized
INFO - 2024-12-14 21:57:04 --> Upload Class Initialized
INFO - 2024-12-14 21:57:04 --> Model "M_login" initialized
INFO - 2024-12-14 21:57:04 --> Model "M_home" initialized
INFO - 2024-12-14 21:57:04 --> Model "M_setting" initialized
INFO - 2024-12-14 21:57:04 --> Controller Class Initialized
INFO - 2024-12-14 21:57:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-14 21:57:04 --> Config Class Initialized
INFO - 2024-12-14 21:57:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:57:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:57:04 --> Utf8 Class Initialized
INFO - 2024-12-14 21:57:04 --> URI Class Initialized
INFO - 2024-12-14 21:57:04 --> Router Class Initialized
INFO - 2024-12-14 21:57:04 --> Output Class Initialized
INFO - 2024-12-14 21:57:04 --> Security Class Initialized
DEBUG - 2024-12-14 21:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:57:04 --> Input Class Initialized
INFO - 2024-12-14 21:57:04 --> Language Class Initialized
INFO - 2024-12-14 21:57:04 --> Loader Class Initialized
INFO - 2024-12-14 21:57:04 --> Helper loaded: url_helper
INFO - 2024-12-14 21:57:04 --> Helper loaded: form_helper
INFO - 2024-12-14 21:57:04 --> Helper loaded: file_helper
INFO - 2024-12-14 21:57:04 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:57:04 --> Form Validation Class Initialized
INFO - 2024-12-14 21:57:04 --> Upload Class Initialized
INFO - 2024-12-14 21:57:04 --> Model "M_login" initialized
INFO - 2024-12-14 21:57:04 --> Model "M_home" initialized
INFO - 2024-12-14 21:57:04 --> Model "M_setting" initialized
INFO - 2024-12-14 21:57:04 --> Controller Class Initialized
INFO - 2024-12-14 21:57:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\Admin/v_dashboard.php
INFO - 2024-12-14 21:57:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 21:57:04 --> Final output sent to browser
DEBUG - 2024-12-14 21:57:04 --> Total execution time: 0.0501
INFO - 2024-12-14 21:57:10 --> Config Class Initialized
INFO - 2024-12-14 21:57:10 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:57:10 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:57:10 --> Utf8 Class Initialized
INFO - 2024-12-14 21:57:10 --> URI Class Initialized
INFO - 2024-12-14 21:57:10 --> Router Class Initialized
INFO - 2024-12-14 21:57:10 --> Output Class Initialized
INFO - 2024-12-14 21:57:10 --> Security Class Initialized
DEBUG - 2024-12-14 21:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:57:10 --> Input Class Initialized
INFO - 2024-12-14 21:57:10 --> Language Class Initialized
INFO - 2024-12-14 21:57:10 --> Loader Class Initialized
INFO - 2024-12-14 21:57:10 --> Helper loaded: url_helper
INFO - 2024-12-14 21:57:10 --> Helper loaded: form_helper
INFO - 2024-12-14 21:57:10 --> Helper loaded: file_helper
INFO - 2024-12-14 21:57:10 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:57:10 --> Form Validation Class Initialized
INFO - 2024-12-14 21:57:10 --> Upload Class Initialized
INFO - 2024-12-14 21:57:10 --> Model "M_login" initialized
INFO - 2024-12-14 21:57:10 --> Model "M_home" initialized
INFO - 2024-12-14 21:57:10 --> Model "M_setting" initialized
INFO - 2024-12-14 21:57:10 --> Controller Class Initialized
INFO - 2024-12-14 21:57:10 --> Model "M_guru" initialized
INFO - 2024-12-14 21:57:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-14 21:57:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 21:57:10 --> Final output sent to browser
DEBUG - 2024-12-14 21:57:10 --> Total execution time: 0.0502
INFO - 2024-12-14 21:57:28 --> Config Class Initialized
INFO - 2024-12-14 21:57:28 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:57:28 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:57:28 --> Utf8 Class Initialized
INFO - 2024-12-14 21:57:28 --> URI Class Initialized
INFO - 2024-12-14 21:57:28 --> Router Class Initialized
INFO - 2024-12-14 21:57:28 --> Output Class Initialized
INFO - 2024-12-14 21:57:28 --> Security Class Initialized
DEBUG - 2024-12-14 21:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:57:28 --> Input Class Initialized
INFO - 2024-12-14 21:57:28 --> Language Class Initialized
INFO - 2024-12-14 21:57:28 --> Loader Class Initialized
INFO - 2024-12-14 21:57:28 --> Helper loaded: url_helper
INFO - 2024-12-14 21:57:28 --> Helper loaded: form_helper
INFO - 2024-12-14 21:57:28 --> Helper loaded: file_helper
INFO - 2024-12-14 21:57:28 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:57:28 --> Form Validation Class Initialized
INFO - 2024-12-14 21:57:28 --> Upload Class Initialized
INFO - 2024-12-14 21:57:28 --> Model "M_login" initialized
INFO - 2024-12-14 21:57:28 --> Model "M_home" initialized
INFO - 2024-12-14 21:57:28 --> Model "M_setting" initialized
INFO - 2024-12-14 21:57:28 --> Controller Class Initialized
INFO - 2024-12-14 21:57:28 --> Model "M_guru" initialized
INFO - 2024-12-14 21:57:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_edit.php
INFO - 2024-12-14 21:57:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 21:57:28 --> Final output sent to browser
DEBUG - 2024-12-14 21:57:28 --> Total execution time: 0.0648
INFO - 2024-12-14 21:57:31 --> Config Class Initialized
INFO - 2024-12-14 21:57:31 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:57:31 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:57:31 --> Utf8 Class Initialized
INFO - 2024-12-14 21:57:31 --> URI Class Initialized
INFO - 2024-12-14 21:57:31 --> Router Class Initialized
INFO - 2024-12-14 21:57:31 --> Output Class Initialized
INFO - 2024-12-14 21:57:31 --> Security Class Initialized
DEBUG - 2024-12-14 21:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:57:31 --> Input Class Initialized
INFO - 2024-12-14 21:57:31 --> Language Class Initialized
INFO - 2024-12-14 21:57:31 --> Loader Class Initialized
INFO - 2024-12-14 21:57:31 --> Helper loaded: url_helper
INFO - 2024-12-14 21:57:32 --> Helper loaded: form_helper
INFO - 2024-12-14 21:57:32 --> Helper loaded: file_helper
INFO - 2024-12-14 21:57:32 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:57:32 --> Form Validation Class Initialized
INFO - 2024-12-14 21:57:32 --> Upload Class Initialized
INFO - 2024-12-14 21:57:32 --> Model "M_login" initialized
INFO - 2024-12-14 21:57:32 --> Model "M_home" initialized
INFO - 2024-12-14 21:57:32 --> Model "M_setting" initialized
INFO - 2024-12-14 21:57:32 --> Controller Class Initialized
INFO - 2024-12-14 21:57:32 --> Model "M_guru" initialized
INFO - 2024-12-14 21:57:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-14 21:57:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 21:57:32 --> Final output sent to browser
DEBUG - 2024-12-14 21:57:32 --> Total execution time: 0.0743
INFO - 2024-12-14 21:57:35 --> Config Class Initialized
INFO - 2024-12-14 21:57:35 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:57:35 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:57:35 --> Utf8 Class Initialized
INFO - 2024-12-14 21:57:35 --> URI Class Initialized
INFO - 2024-12-14 21:57:35 --> Router Class Initialized
INFO - 2024-12-14 21:57:35 --> Output Class Initialized
INFO - 2024-12-14 21:57:35 --> Security Class Initialized
DEBUG - 2024-12-14 21:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:57:35 --> Input Class Initialized
INFO - 2024-12-14 21:57:35 --> Language Class Initialized
INFO - 2024-12-14 21:57:35 --> Loader Class Initialized
INFO - 2024-12-14 21:57:35 --> Helper loaded: url_helper
INFO - 2024-12-14 21:57:35 --> Helper loaded: form_helper
INFO - 2024-12-14 21:57:35 --> Helper loaded: file_helper
INFO - 2024-12-14 21:57:35 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:57:35 --> Form Validation Class Initialized
INFO - 2024-12-14 21:57:35 --> Upload Class Initialized
INFO - 2024-12-14 21:57:35 --> Model "M_login" initialized
INFO - 2024-12-14 21:57:35 --> Model "M_home" initialized
INFO - 2024-12-14 21:57:35 --> Model "M_setting" initialized
INFO - 2024-12-14 21:57:35 --> Controller Class Initialized
INFO - 2024-12-14 21:57:35 --> Model "M_guru" initialized
INFO - 2024-12-14 21:57:35 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_add.php
INFO - 2024-12-14 21:57:35 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 21:57:35 --> Final output sent to browser
DEBUG - 2024-12-14 21:57:35 --> Total execution time: 0.0469
INFO - 2024-12-14 21:57:38 --> Config Class Initialized
INFO - 2024-12-14 21:57:38 --> Hooks Class Initialized
DEBUG - 2024-12-14 21:57:38 --> UTF-8 Support Enabled
INFO - 2024-12-14 21:57:38 --> Utf8 Class Initialized
INFO - 2024-12-14 21:57:38 --> URI Class Initialized
INFO - 2024-12-14 21:57:38 --> Router Class Initialized
INFO - 2024-12-14 21:57:38 --> Output Class Initialized
INFO - 2024-12-14 21:57:38 --> Security Class Initialized
DEBUG - 2024-12-14 21:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 21:57:38 --> Input Class Initialized
INFO - 2024-12-14 21:57:38 --> Language Class Initialized
INFO - 2024-12-14 21:57:38 --> Loader Class Initialized
INFO - 2024-12-14 21:57:38 --> Helper loaded: url_helper
INFO - 2024-12-14 21:57:38 --> Helper loaded: form_helper
INFO - 2024-12-14 21:57:38 --> Helper loaded: file_helper
INFO - 2024-12-14 21:57:38 --> Database Driver Class Initialized
DEBUG - 2024-12-14 21:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 21:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 21:57:38 --> Form Validation Class Initialized
INFO - 2024-12-14 21:57:38 --> Upload Class Initialized
INFO - 2024-12-14 21:57:38 --> Model "M_login" initialized
INFO - 2024-12-14 21:57:38 --> Model "M_home" initialized
INFO - 2024-12-14 21:57:38 --> Model "M_setting" initialized
INFO - 2024-12-14 21:57:38 --> Controller Class Initialized
INFO - 2024-12-14 21:57:38 --> Model "M_guru" initialized
INFO - 2024-12-14 21:57:38 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-14 21:57:38 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 21:57:38 --> Final output sent to browser
DEBUG - 2024-12-14 21:57:38 --> Total execution time: 0.0755
INFO - 2024-12-14 22:36:56 --> Config Class Initialized
INFO - 2024-12-14 22:36:56 --> Hooks Class Initialized
DEBUG - 2024-12-14 22:36:56 --> UTF-8 Support Enabled
INFO - 2024-12-14 22:36:56 --> Utf8 Class Initialized
INFO - 2024-12-14 22:36:56 --> URI Class Initialized
INFO - 2024-12-14 22:36:56 --> Router Class Initialized
INFO - 2024-12-14 22:36:56 --> Output Class Initialized
INFO - 2024-12-14 22:36:56 --> Security Class Initialized
DEBUG - 2024-12-14 22:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 22:36:56 --> Input Class Initialized
INFO - 2024-12-14 22:36:56 --> Language Class Initialized
INFO - 2024-12-14 22:36:56 --> Loader Class Initialized
INFO - 2024-12-14 22:36:56 --> Helper loaded: url_helper
INFO - 2024-12-14 22:36:56 --> Helper loaded: form_helper
INFO - 2024-12-14 22:36:56 --> Helper loaded: file_helper
INFO - 2024-12-14 22:36:56 --> Database Driver Class Initialized
DEBUG - 2024-12-14 22:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 22:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 22:36:56 --> Form Validation Class Initialized
INFO - 2024-12-14 22:36:56 --> Upload Class Initialized
INFO - 2024-12-14 22:36:56 --> Model "M_login" initialized
INFO - 2024-12-14 22:36:56 --> Model "M_home" initialized
INFO - 2024-12-14 22:36:56 --> Model "M_setting" initialized
INFO - 2024-12-14 22:36:56 --> Controller Class Initialized
INFO - 2024-12-14 22:36:56 --> Model "M_guru" initialized
INFO - 2024-12-14 22:36:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_edit.php
INFO - 2024-12-14 22:36:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 22:36:56 --> Final output sent to browser
DEBUG - 2024-12-14 22:36:56 --> Total execution time: 0.0725
INFO - 2024-12-14 22:37:05 --> Config Class Initialized
INFO - 2024-12-14 22:37:05 --> Hooks Class Initialized
DEBUG - 2024-12-14 22:37:05 --> UTF-8 Support Enabled
INFO - 2024-12-14 22:37:05 --> Utf8 Class Initialized
INFO - 2024-12-14 22:37:05 --> URI Class Initialized
INFO - 2024-12-14 22:37:05 --> Router Class Initialized
INFO - 2024-12-14 22:37:05 --> Output Class Initialized
INFO - 2024-12-14 22:37:05 --> Security Class Initialized
DEBUG - 2024-12-14 22:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 22:37:05 --> Input Class Initialized
INFO - 2024-12-14 22:37:05 --> Language Class Initialized
INFO - 2024-12-14 22:37:05 --> Loader Class Initialized
INFO - 2024-12-14 22:37:05 --> Helper loaded: url_helper
INFO - 2024-12-14 22:37:05 --> Helper loaded: form_helper
INFO - 2024-12-14 22:37:05 --> Helper loaded: file_helper
INFO - 2024-12-14 22:37:05 --> Database Driver Class Initialized
DEBUG - 2024-12-14 22:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 22:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 22:37:05 --> Form Validation Class Initialized
INFO - 2024-12-14 22:37:05 --> Upload Class Initialized
INFO - 2024-12-14 22:37:05 --> Model "M_login" initialized
INFO - 2024-12-14 22:37:05 --> Model "M_home" initialized
INFO - 2024-12-14 22:37:05 --> Model "M_setting" initialized
INFO - 2024-12-14 22:37:05 --> Controller Class Initialized
INFO - 2024-12-14 22:37:05 --> Model "M_guru" initialized
INFO - 2024-12-14 22:37:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-14 22:37:05 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 22:37:05 --> Final output sent to browser
DEBUG - 2024-12-14 22:37:05 --> Total execution time: 0.0504
INFO - 2024-12-14 22:37:08 --> Config Class Initialized
INFO - 2024-12-14 22:37:08 --> Hooks Class Initialized
DEBUG - 2024-12-14 22:37:08 --> UTF-8 Support Enabled
INFO - 2024-12-14 22:37:08 --> Utf8 Class Initialized
INFO - 2024-12-14 22:37:08 --> URI Class Initialized
INFO - 2024-12-14 22:37:08 --> Router Class Initialized
INFO - 2024-12-14 22:37:08 --> Output Class Initialized
INFO - 2024-12-14 22:37:08 --> Security Class Initialized
DEBUG - 2024-12-14 22:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 22:37:08 --> Input Class Initialized
INFO - 2024-12-14 22:37:08 --> Language Class Initialized
INFO - 2024-12-14 22:37:08 --> Loader Class Initialized
INFO - 2024-12-14 22:37:08 --> Helper loaded: url_helper
INFO - 2024-12-14 22:37:08 --> Helper loaded: form_helper
INFO - 2024-12-14 22:37:08 --> Helper loaded: file_helper
INFO - 2024-12-14 22:37:08 --> Database Driver Class Initialized
DEBUG - 2024-12-14 22:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 22:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 22:37:08 --> Form Validation Class Initialized
INFO - 2024-12-14 22:37:08 --> Upload Class Initialized
INFO - 2024-12-14 22:37:08 --> Model "M_login" initialized
INFO - 2024-12-14 22:37:08 --> Model "M_home" initialized
INFO - 2024-12-14 22:37:08 --> Model "M_setting" initialized
INFO - 2024-12-14 22:37:08 --> Controller Class Initialized
INFO - 2024-12-14 22:37:08 --> Model "M_guru" initialized
INFO - 2024-12-14 22:37:08 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_edit.php
INFO - 2024-12-14 22:37:08 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-14 22:37:08 --> Final output sent to browser
DEBUG - 2024-12-14 22:37:08 --> Total execution time: 0.0461
