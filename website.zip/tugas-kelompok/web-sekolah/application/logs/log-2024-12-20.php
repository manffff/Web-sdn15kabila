<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-20 10:09:16 --> Config Class Initialized
INFO - 2024-12-20 10:09:16 --> Hooks Class Initialized
DEBUG - 2024-12-20 10:09:16 --> UTF-8 Support Enabled
INFO - 2024-12-20 10:09:16 --> Utf8 Class Initialized
INFO - 2024-12-20 10:09:16 --> URI Class Initialized
INFO - 2024-12-20 10:09:16 --> Router Class Initialized
INFO - 2024-12-20 10:09:16 --> Output Class Initialized
INFO - 2024-12-20 10:09:16 --> Security Class Initialized
DEBUG - 2024-12-20 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 10:09:16 --> Input Class Initialized
INFO - 2024-12-20 10:09:16 --> Language Class Initialized
INFO - 2024-12-20 10:09:16 --> Loader Class Initialized
INFO - 2024-12-20 10:09:16 --> Helper loaded: url_helper
INFO - 2024-12-20 10:09:16 --> Helper loaded: form_helper
INFO - 2024-12-20 10:09:16 --> Helper loaded: file_helper
INFO - 2024-12-20 10:09:16 --> Database Driver Class Initialized
DEBUG - 2024-12-20 10:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 10:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 10:09:16 --> Form Validation Class Initialized
INFO - 2024-12-20 10:09:16 --> Upload Class Initialized
INFO - 2024-12-20 10:09:16 --> Model "M_login" initialized
INFO - 2024-12-20 10:09:16 --> Model "M_home" initialized
INFO - 2024-12-20 10:09:16 --> Model "M_setting" initialized
INFO - 2024-12-20 10:09:16 --> Controller Class Initialized
INFO - 2024-12-20 10:09:16 --> Config Class Initialized
INFO - 2024-12-20 10:09:16 --> Hooks Class Initialized
DEBUG - 2024-12-20 10:09:16 --> UTF-8 Support Enabled
INFO - 2024-12-20 10:09:16 --> Utf8 Class Initialized
INFO - 2024-12-20 10:09:16 --> URI Class Initialized
INFO - 2024-12-20 10:09:16 --> Router Class Initialized
INFO - 2024-12-20 10:09:16 --> Output Class Initialized
INFO - 2024-12-20 10:09:16 --> Security Class Initialized
DEBUG - 2024-12-20 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 10:09:16 --> Input Class Initialized
INFO - 2024-12-20 10:09:16 --> Language Class Initialized
INFO - 2024-12-20 10:09:16 --> Loader Class Initialized
INFO - 2024-12-20 10:09:16 --> Helper loaded: url_helper
INFO - 2024-12-20 10:09:16 --> Helper loaded: form_helper
INFO - 2024-12-20 10:09:16 --> Helper loaded: file_helper
INFO - 2024-12-20 10:09:16 --> Database Driver Class Initialized
DEBUG - 2024-12-20 10:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 10:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 10:09:16 --> Form Validation Class Initialized
INFO - 2024-12-20 10:09:16 --> Upload Class Initialized
INFO - 2024-12-20 10:09:16 --> Model "M_login" initialized
INFO - 2024-12-20 10:09:16 --> Model "M_home" initialized
INFO - 2024-12-20 10:09:16 --> Model "M_setting" initialized
INFO - 2024-12-20 10:09:16 --> Controller Class Initialized
INFO - 2024-12-20 10:09:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_login.php
INFO - 2024-12-20 10:09:16 --> Final output sent to browser
DEBUG - 2024-12-20 10:09:16 --> Total execution time: 0.1108
INFO - 2024-12-20 10:09:18 --> Config Class Initialized
INFO - 2024-12-20 10:09:18 --> Hooks Class Initialized
DEBUG - 2024-12-20 10:09:18 --> UTF-8 Support Enabled
INFO - 2024-12-20 10:09:18 --> Utf8 Class Initialized
INFO - 2024-12-20 10:09:18 --> URI Class Initialized
DEBUG - 2024-12-20 10:09:18 --> No URI present. Default controller set.
INFO - 2024-12-20 10:09:18 --> Router Class Initialized
INFO - 2024-12-20 10:09:18 --> Output Class Initialized
INFO - 2024-12-20 10:09:18 --> Security Class Initialized
DEBUG - 2024-12-20 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 10:09:18 --> Input Class Initialized
INFO - 2024-12-20 10:09:18 --> Language Class Initialized
INFO - 2024-12-20 10:09:18 --> Loader Class Initialized
INFO - 2024-12-20 10:09:18 --> Helper loaded: url_helper
INFO - 2024-12-20 10:09:18 --> Helper loaded: form_helper
INFO - 2024-12-20 10:09:18 --> Helper loaded: file_helper
INFO - 2024-12-20 10:09:18 --> Database Driver Class Initialized
DEBUG - 2024-12-20 10:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 10:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 10:09:18 --> Form Validation Class Initialized
INFO - 2024-12-20 10:09:18 --> Upload Class Initialized
INFO - 2024-12-20 10:09:18 --> Model "M_login" initialized
INFO - 2024-12-20 10:09:18 --> Model "M_home" initialized
INFO - 2024-12-20 10:09:18 --> Model "M_setting" initialized
INFO - 2024-12-20 10:09:18 --> Controller Class Initialized
INFO - 2024-12-20 10:09:18 --> Model "NilaiModel" initialized
INFO - 2024-12-20 10:09:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\nilai_form.php
INFO - 2024-12-20 10:09:18 --> Final output sent to browser
DEBUG - 2024-12-20 10:09:18 --> Total execution time: 0.1218
INFO - 2024-12-20 13:26:45 --> Config Class Initialized
INFO - 2024-12-20 13:26:45 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:26:45 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:26:45 --> Utf8 Class Initialized
INFO - 2024-12-20 13:26:45 --> URI Class Initialized
DEBUG - 2024-12-20 13:26:45 --> No URI present. Default controller set.
INFO - 2024-12-20 13:26:45 --> Router Class Initialized
INFO - 2024-12-20 13:26:45 --> Output Class Initialized
INFO - 2024-12-20 13:26:45 --> Security Class Initialized
DEBUG - 2024-12-20 13:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:26:45 --> Input Class Initialized
INFO - 2024-12-20 13:26:45 --> Language Class Initialized
INFO - 2024-12-20 13:26:45 --> Loader Class Initialized
INFO - 2024-12-20 13:26:45 --> Helper loaded: url_helper
INFO - 2024-12-20 13:26:45 --> Helper loaded: form_helper
INFO - 2024-12-20 13:26:45 --> Helper loaded: file_helper
INFO - 2024-12-20 13:26:45 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:26:45 --> Form Validation Class Initialized
INFO - 2024-12-20 13:26:45 --> Upload Class Initialized
INFO - 2024-12-20 13:26:45 --> Model "M_login" initialized
INFO - 2024-12-20 13:26:45 --> Model "M_home" initialized
INFO - 2024-12-20 13:26:45 --> Model "M_setting" initialized
INFO - 2024-12-20 13:26:45 --> Controller Class Initialized
INFO - 2024-12-20 13:26:45 --> Model "NilaiModel" initialized
INFO - 2024-12-20 13:26:45 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\nilai_form.php
INFO - 2024-12-20 13:26:45 --> Final output sent to browser
DEBUG - 2024-12-20 13:26:45 --> Total execution time: 0.0921
INFO - 2024-12-20 13:32:29 --> Config Class Initialized
INFO - 2024-12-20 13:32:29 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:32:29 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:32:29 --> Utf8 Class Initialized
INFO - 2024-12-20 13:32:29 --> URI Class Initialized
DEBUG - 2024-12-20 13:32:29 --> No URI present. Default controller set.
INFO - 2024-12-20 13:32:29 --> Router Class Initialized
INFO - 2024-12-20 13:32:29 --> Output Class Initialized
INFO - 2024-12-20 13:32:29 --> Security Class Initialized
DEBUG - 2024-12-20 13:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:32:29 --> Input Class Initialized
INFO - 2024-12-20 13:32:29 --> Language Class Initialized
INFO - 2024-12-20 13:32:29 --> Loader Class Initialized
INFO - 2024-12-20 13:32:29 --> Helper loaded: url_helper
INFO - 2024-12-20 13:32:29 --> Helper loaded: form_helper
INFO - 2024-12-20 13:32:29 --> Helper loaded: file_helper
INFO - 2024-12-20 13:32:29 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:32:29 --> Form Validation Class Initialized
INFO - 2024-12-20 13:32:29 --> Upload Class Initialized
INFO - 2024-12-20 13:32:29 --> Model "M_login" initialized
INFO - 2024-12-20 13:32:29 --> Model "M_home" initialized
INFO - 2024-12-20 13:32:29 --> Model "M_setting" initialized
INFO - 2024-12-20 13:32:29 --> Controller Class Initialized
INFO - 2024-12-20 13:32:29 --> Model "M_guru" initialized
INFO - 2024-12-20 13:32:29 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-20 13:32:29 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-20 13:32:29 --> Final output sent to browser
DEBUG - 2024-12-20 13:32:29 --> Total execution time: 0.0875
INFO - 2024-12-20 13:32:30 --> Config Class Initialized
INFO - 2024-12-20 13:32:30 --> Hooks Class Initialized
INFO - 2024-12-20 13:32:30 --> Config Class Initialized
INFO - 2024-12-20 13:32:30 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:32:30 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:32:30 --> Utf8 Class Initialized
DEBUG - 2024-12-20 13:32:30 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:32:30 --> URI Class Initialized
INFO - 2024-12-20 13:32:30 --> Config Class Initialized
INFO - 2024-12-20 13:32:30 --> Utf8 Class Initialized
INFO - 2024-12-20 13:32:30 --> Hooks Class Initialized
INFO - 2024-12-20 13:32:30 --> Router Class Initialized
INFO - 2024-12-20 13:32:30 --> URI Class Initialized
INFO - 2024-12-20 13:32:30 --> Output Class Initialized
DEBUG - 2024-12-20 13:32:30 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:32:30 --> Router Class Initialized
INFO - 2024-12-20 13:32:30 --> Utf8 Class Initialized
INFO - 2024-12-20 13:32:30 --> Output Class Initialized
INFO - 2024-12-20 13:32:30 --> Security Class Initialized
DEBUG - 2024-12-20 13:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:32:30 --> Input Class Initialized
INFO - 2024-12-20 13:32:30 --> Language Class Initialized
INFO - 2024-12-20 13:32:30 --> Security Class Initialized
INFO - 2024-12-20 13:32:30 --> URI Class Initialized
ERROR - 2024-12-20 13:32:30 --> 404 Page Not Found: Images/courses_background.jpg
DEBUG - 2024-12-20 13:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:32:30 --> Input Class Initialized
INFO - 2024-12-20 13:32:30 --> Router Class Initialized
INFO - 2024-12-20 13:32:30 --> Language Class Initialized
INFO - 2024-12-20 13:32:30 --> Output Class Initialized
ERROR - 2024-12-20 13:32:30 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-20 13:32:30 --> Security Class Initialized
DEBUG - 2024-12-20 13:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:32:30 --> Input Class Initialized
INFO - 2024-12-20 13:32:30 --> Language Class Initialized
ERROR - 2024-12-20 13:32:30 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-20 13:43:40 --> Config Class Initialized
INFO - 2024-12-20 13:43:40 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:43:40 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:43:40 --> Utf8 Class Initialized
INFO - 2024-12-20 13:43:40 --> URI Class Initialized
INFO - 2024-12-20 13:43:40 --> Router Class Initialized
INFO - 2024-12-20 13:43:40 --> Output Class Initialized
INFO - 2024-12-20 13:43:40 --> Security Class Initialized
DEBUG - 2024-12-20 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:43:40 --> Input Class Initialized
INFO - 2024-12-20 13:43:40 --> Language Class Initialized
INFO - 2024-12-20 13:43:40 --> Loader Class Initialized
INFO - 2024-12-20 13:43:40 --> Helper loaded: url_helper
INFO - 2024-12-20 13:43:40 --> Helper loaded: form_helper
INFO - 2024-12-20 13:43:40 --> Helper loaded: file_helper
INFO - 2024-12-20 13:43:40 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:43:40 --> Form Validation Class Initialized
INFO - 2024-12-20 13:43:40 --> Upload Class Initialized
INFO - 2024-12-20 13:43:40 --> Model "M_login" initialized
INFO - 2024-12-20 13:43:40 --> Model "M_home" initialized
INFO - 2024-12-20 13:43:40 --> Model "M_setting" initialized
INFO - 2024-12-20 13:43:40 --> Controller Class Initialized
INFO - 2024-12-20 13:43:40 --> Model "M_guru" initialized
INFO - 2024-12-20 13:43:40 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-20 13:43:40 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 13:43:40 --> Final output sent to browser
DEBUG - 2024-12-20 13:43:40 --> Total execution time: 0.0697
INFO - 2024-12-20 13:43:48 --> Config Class Initialized
INFO - 2024-12-20 13:43:48 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:43:48 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:43:48 --> Utf8 Class Initialized
INFO - 2024-12-20 13:43:48 --> URI Class Initialized
INFO - 2024-12-20 13:43:48 --> Router Class Initialized
INFO - 2024-12-20 13:43:48 --> Output Class Initialized
INFO - 2024-12-20 13:43:48 --> Security Class Initialized
DEBUG - 2024-12-20 13:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:43:48 --> Input Class Initialized
INFO - 2024-12-20 13:43:48 --> Language Class Initialized
INFO - 2024-12-20 13:43:48 --> Loader Class Initialized
INFO - 2024-12-20 13:43:48 --> Helper loaded: url_helper
INFO - 2024-12-20 13:43:48 --> Helper loaded: form_helper
INFO - 2024-12-20 13:43:48 --> Helper loaded: file_helper
INFO - 2024-12-20 13:43:48 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:43:48 --> Form Validation Class Initialized
INFO - 2024-12-20 13:43:48 --> Upload Class Initialized
INFO - 2024-12-20 13:43:48 --> Model "M_login" initialized
INFO - 2024-12-20 13:43:48 --> Model "M_home" initialized
INFO - 2024-12-20 13:43:48 --> Model "M_setting" initialized
INFO - 2024-12-20 13:43:48 --> Controller Class Initialized
INFO - 2024-12-20 13:43:48 --> Model "M_guru" initialized
INFO - 2024-12-20 13:43:48 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-20 13:43:48 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 13:43:48 --> Final output sent to browser
DEBUG - 2024-12-20 13:43:48 --> Total execution time: 0.0690
INFO - 2024-12-20 13:43:58 --> Config Class Initialized
INFO - 2024-12-20 13:43:58 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:43:58 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:43:58 --> Utf8 Class Initialized
INFO - 2024-12-20 13:43:58 --> URI Class Initialized
INFO - 2024-12-20 13:43:58 --> Router Class Initialized
INFO - 2024-12-20 13:43:58 --> Output Class Initialized
INFO - 2024-12-20 13:43:58 --> Security Class Initialized
DEBUG - 2024-12-20 13:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:43:58 --> Input Class Initialized
INFO - 2024-12-20 13:43:58 --> Language Class Initialized
INFO - 2024-12-20 13:43:58 --> Loader Class Initialized
INFO - 2024-12-20 13:43:58 --> Helper loaded: url_helper
INFO - 2024-12-20 13:43:58 --> Helper loaded: form_helper
INFO - 2024-12-20 13:43:58 --> Helper loaded: file_helper
INFO - 2024-12-20 13:43:58 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:43:58 --> Form Validation Class Initialized
INFO - 2024-12-20 13:43:58 --> Upload Class Initialized
INFO - 2024-12-20 13:43:58 --> Model "M_login" initialized
INFO - 2024-12-20 13:43:58 --> Model "M_home" initialized
INFO - 2024-12-20 13:43:58 --> Model "M_setting" initialized
INFO - 2024-12-20 13:43:58 --> Controller Class Initialized
INFO - 2024-12-20 13:43:58 --> Model "M_guru" initialized
INFO - 2024-12-20 13:43:58 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-20 13:43:58 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 13:43:58 --> Final output sent to browser
DEBUG - 2024-12-20 13:43:58 --> Total execution time: 0.0569
INFO - 2024-12-20 13:44:04 --> Config Class Initialized
INFO - 2024-12-20 13:44:04 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:44:04 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:44:04 --> Utf8 Class Initialized
INFO - 2024-12-20 13:44:04 --> URI Class Initialized
INFO - 2024-12-20 13:44:04 --> Router Class Initialized
INFO - 2024-12-20 13:44:04 --> Output Class Initialized
INFO - 2024-12-20 13:44:04 --> Security Class Initialized
DEBUG - 2024-12-20 13:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:44:04 --> Input Class Initialized
INFO - 2024-12-20 13:44:04 --> Language Class Initialized
INFO - 2024-12-20 13:44:04 --> Loader Class Initialized
INFO - 2024-12-20 13:44:04 --> Helper loaded: url_helper
INFO - 2024-12-20 13:44:04 --> Helper loaded: form_helper
INFO - 2024-12-20 13:44:04 --> Helper loaded: file_helper
INFO - 2024-12-20 13:44:04 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:44:04 --> Form Validation Class Initialized
INFO - 2024-12-20 13:44:04 --> Upload Class Initialized
INFO - 2024-12-20 13:44:04 --> Model "M_login" initialized
INFO - 2024-12-20 13:44:04 --> Model "M_home" initialized
INFO - 2024-12-20 13:44:04 --> Model "M_setting" initialized
INFO - 2024-12-20 13:44:04 --> Controller Class Initialized
INFO - 2024-12-20 13:44:04 --> Model "M_guru" initialized
INFO - 2024-12-20 13:44:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_gallery.php
INFO - 2024-12-20 13:44:04 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 13:44:04 --> Final output sent to browser
DEBUG - 2024-12-20 13:44:04 --> Total execution time: 0.0722
INFO - 2024-12-20 13:44:09 --> Config Class Initialized
INFO - 2024-12-20 13:44:09 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:44:09 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:44:09 --> Utf8 Class Initialized
INFO - 2024-12-20 13:44:09 --> URI Class Initialized
INFO - 2024-12-20 13:44:09 --> Router Class Initialized
INFO - 2024-12-20 13:44:09 --> Output Class Initialized
INFO - 2024-12-20 13:44:09 --> Security Class Initialized
DEBUG - 2024-12-20 13:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:44:09 --> Input Class Initialized
INFO - 2024-12-20 13:44:09 --> Language Class Initialized
INFO - 2024-12-20 13:44:09 --> Loader Class Initialized
INFO - 2024-12-20 13:44:09 --> Helper loaded: url_helper
INFO - 2024-12-20 13:44:09 --> Helper loaded: form_helper
INFO - 2024-12-20 13:44:09 --> Helper loaded: file_helper
INFO - 2024-12-20 13:44:09 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:44:09 --> Form Validation Class Initialized
INFO - 2024-12-20 13:44:09 --> Upload Class Initialized
INFO - 2024-12-20 13:44:09 --> Model "M_login" initialized
INFO - 2024-12-20 13:44:09 --> Model "M_home" initialized
INFO - 2024-12-20 13:44:09 --> Model "M_setting" initialized
INFO - 2024-12-20 13:44:09 --> Controller Class Initialized
INFO - 2024-12-20 13:44:09 --> Model "M_guru" initialized
INFO - 2024-12-20 13:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-20 13:44:09 --> Pagination Class Initialized
INFO - 2024-12-20 13:44:09 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-20 13:44:09 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 13:44:09 --> Final output sent to browser
DEBUG - 2024-12-20 13:44:09 --> Total execution time: 0.0592
INFO - 2024-12-20 13:44:13 --> Config Class Initialized
INFO - 2024-12-20 13:44:13 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:44:13 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:44:13 --> Utf8 Class Initialized
INFO - 2024-12-20 13:44:13 --> URI Class Initialized
INFO - 2024-12-20 13:44:13 --> Router Class Initialized
INFO - 2024-12-20 13:44:13 --> Output Class Initialized
INFO - 2024-12-20 13:44:13 --> Security Class Initialized
DEBUG - 2024-12-20 13:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:44:13 --> Input Class Initialized
INFO - 2024-12-20 13:44:13 --> Language Class Initialized
INFO - 2024-12-20 13:44:13 --> Loader Class Initialized
INFO - 2024-12-20 13:44:13 --> Helper loaded: url_helper
INFO - 2024-12-20 13:44:13 --> Helper loaded: form_helper
INFO - 2024-12-20 13:44:13 --> Helper loaded: file_helper
INFO - 2024-12-20 13:44:13 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:44:13 --> Form Validation Class Initialized
INFO - 2024-12-20 13:44:13 --> Upload Class Initialized
INFO - 2024-12-20 13:44:13 --> Model "M_login" initialized
INFO - 2024-12-20 13:44:13 --> Model "M_home" initialized
INFO - 2024-12-20 13:44:13 --> Model "M_setting" initialized
INFO - 2024-12-20 13:44:13 --> Controller Class Initialized
INFO - 2024-12-20 13:44:13 --> Model "M_guru" initialized
INFO - 2024-12-20 13:44:13 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-20 13:44:13 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 13:44:13 --> Final output sent to browser
DEBUG - 2024-12-20 13:44:13 --> Total execution time: 0.0528
INFO - 2024-12-20 13:44:13 --> Config Class Initialized
INFO - 2024-12-20 13:44:13 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:44:13 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:44:13 --> Utf8 Class Initialized
INFO - 2024-12-20 13:44:13 --> URI Class Initialized
INFO - 2024-12-20 13:44:13 --> Router Class Initialized
INFO - 2024-12-20 13:44:13 --> Output Class Initialized
INFO - 2024-12-20 13:44:13 --> Security Class Initialized
DEBUG - 2024-12-20 13:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:44:13 --> Input Class Initialized
INFO - 2024-12-20 13:44:13 --> Language Class Initialized
ERROR - 2024-12-20 13:44:13 --> 404 Page Not Found: Home/images
INFO - 2024-12-20 13:52:18 --> Config Class Initialized
INFO - 2024-12-20 13:52:18 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:52:18 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:52:18 --> Utf8 Class Initialized
INFO - 2024-12-20 13:52:18 --> URI Class Initialized
INFO - 2024-12-20 13:52:18 --> Router Class Initialized
INFO - 2024-12-20 13:52:18 --> Output Class Initialized
INFO - 2024-12-20 13:52:18 --> Security Class Initialized
DEBUG - 2024-12-20 13:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:52:18 --> Input Class Initialized
INFO - 2024-12-20 13:52:18 --> Language Class Initialized
INFO - 2024-12-20 13:52:18 --> Loader Class Initialized
INFO - 2024-12-20 13:52:18 --> Helper loaded: url_helper
INFO - 2024-12-20 13:52:18 --> Helper loaded: form_helper
INFO - 2024-12-20 13:52:18 --> Helper loaded: file_helper
INFO - 2024-12-20 13:52:18 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:52:18 --> Form Validation Class Initialized
INFO - 2024-12-20 13:52:18 --> Upload Class Initialized
INFO - 2024-12-20 13:52:18 --> Model "M_login" initialized
INFO - 2024-12-20 13:52:18 --> Model "M_home" initialized
INFO - 2024-12-20 13:52:18 --> Model "M_setting" initialized
INFO - 2024-12-20 13:52:18 --> Controller Class Initialized
INFO - 2024-12-20 13:52:18 --> Config Class Initialized
INFO - 2024-12-20 13:52:18 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:52:18 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:52:18 --> Utf8 Class Initialized
INFO - 2024-12-20 13:52:18 --> URI Class Initialized
INFO - 2024-12-20 13:52:18 --> Router Class Initialized
INFO - 2024-12-20 13:52:18 --> Output Class Initialized
INFO - 2024-12-20 13:52:18 --> Security Class Initialized
DEBUG - 2024-12-20 13:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:52:18 --> Input Class Initialized
INFO - 2024-12-20 13:52:18 --> Language Class Initialized
INFO - 2024-12-20 13:52:18 --> Loader Class Initialized
INFO - 2024-12-20 13:52:18 --> Helper loaded: url_helper
INFO - 2024-12-20 13:52:18 --> Helper loaded: form_helper
INFO - 2024-12-20 13:52:18 --> Helper loaded: file_helper
INFO - 2024-12-20 13:52:18 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:52:18 --> Form Validation Class Initialized
INFO - 2024-12-20 13:52:18 --> Upload Class Initialized
INFO - 2024-12-20 13:52:18 --> Model "M_login" initialized
INFO - 2024-12-20 13:52:18 --> Model "M_home" initialized
INFO - 2024-12-20 13:52:18 --> Model "M_setting" initialized
INFO - 2024-12-20 13:52:18 --> Controller Class Initialized
INFO - 2024-12-20 13:52:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_login.php
INFO - 2024-12-20 13:52:18 --> Final output sent to browser
DEBUG - 2024-12-20 13:52:18 --> Total execution time: 0.0346
INFO - 2024-12-20 13:52:21 --> Config Class Initialized
INFO - 2024-12-20 13:52:21 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:52:21 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:52:21 --> Utf8 Class Initialized
INFO - 2024-12-20 13:52:21 --> URI Class Initialized
INFO - 2024-12-20 13:52:21 --> Router Class Initialized
INFO - 2024-12-20 13:52:21 --> Output Class Initialized
INFO - 2024-12-20 13:52:21 --> Security Class Initialized
DEBUG - 2024-12-20 13:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:52:21 --> Input Class Initialized
INFO - 2024-12-20 13:52:21 --> Language Class Initialized
INFO - 2024-12-20 13:52:21 --> Loader Class Initialized
INFO - 2024-12-20 13:52:21 --> Helper loaded: url_helper
INFO - 2024-12-20 13:52:21 --> Helper loaded: form_helper
INFO - 2024-12-20 13:52:21 --> Helper loaded: file_helper
INFO - 2024-12-20 13:52:21 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:52:21 --> Form Validation Class Initialized
INFO - 2024-12-20 13:52:21 --> Upload Class Initialized
INFO - 2024-12-20 13:52:21 --> Model "M_login" initialized
INFO - 2024-12-20 13:52:21 --> Model "M_home" initialized
INFO - 2024-12-20 13:52:21 --> Model "M_setting" initialized
INFO - 2024-12-20 13:52:21 --> Controller Class Initialized
INFO - 2024-12-20 13:52:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-20 13:52:21 --> Config Class Initialized
INFO - 2024-12-20 13:52:21 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:52:21 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:52:21 --> Utf8 Class Initialized
INFO - 2024-12-20 13:52:21 --> URI Class Initialized
INFO - 2024-12-20 13:52:21 --> Router Class Initialized
INFO - 2024-12-20 13:52:21 --> Output Class Initialized
INFO - 2024-12-20 13:52:21 --> Security Class Initialized
DEBUG - 2024-12-20 13:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:52:21 --> Input Class Initialized
INFO - 2024-12-20 13:52:21 --> Language Class Initialized
INFO - 2024-12-20 13:52:21 --> Loader Class Initialized
INFO - 2024-12-20 13:52:21 --> Helper loaded: url_helper
INFO - 2024-12-20 13:52:21 --> Helper loaded: form_helper
INFO - 2024-12-20 13:52:21 --> Helper loaded: file_helper
INFO - 2024-12-20 13:52:21 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:52:21 --> Form Validation Class Initialized
INFO - 2024-12-20 13:52:21 --> Upload Class Initialized
INFO - 2024-12-20 13:52:21 --> Model "M_login" initialized
INFO - 2024-12-20 13:52:21 --> Model "M_home" initialized
INFO - 2024-12-20 13:52:21 --> Model "M_setting" initialized
INFO - 2024-12-20 13:52:21 --> Controller Class Initialized
INFO - 2024-12-20 13:52:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\Admin/v_dashboard.php
INFO - 2024-12-20 13:52:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-20 13:52:21 --> Final output sent to browser
DEBUG - 2024-12-20 13:52:21 --> Total execution time: 0.0479
INFO - 2024-12-20 13:52:27 --> Config Class Initialized
INFO - 2024-12-20 13:52:27 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:52:27 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:52:27 --> Utf8 Class Initialized
INFO - 2024-12-20 13:52:27 --> URI Class Initialized
INFO - 2024-12-20 13:52:27 --> Router Class Initialized
INFO - 2024-12-20 13:52:27 --> Output Class Initialized
INFO - 2024-12-20 13:52:27 --> Security Class Initialized
DEBUG - 2024-12-20 13:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:52:27 --> Input Class Initialized
INFO - 2024-12-20 13:52:27 --> Language Class Initialized
INFO - 2024-12-20 13:52:27 --> Loader Class Initialized
INFO - 2024-12-20 13:52:27 --> Helper loaded: url_helper
INFO - 2024-12-20 13:52:27 --> Helper loaded: form_helper
INFO - 2024-12-20 13:52:27 --> Helper loaded: file_helper
INFO - 2024-12-20 13:52:27 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:52:27 --> Form Validation Class Initialized
INFO - 2024-12-20 13:52:27 --> Upload Class Initialized
INFO - 2024-12-20 13:52:27 --> Model "M_login" initialized
INFO - 2024-12-20 13:52:27 --> Model "M_home" initialized
INFO - 2024-12-20 13:52:27 --> Model "M_setting" initialized
INFO - 2024-12-20 13:52:27 --> Controller Class Initialized
INFO - 2024-12-20 13:52:27 --> Model "M_guru" initialized
INFO - 2024-12-20 13:52:27 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-20 13:52:27 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-20 13:52:27 --> Final output sent to browser
DEBUG - 2024-12-20 13:52:27 --> Total execution time: 0.0656
INFO - 2024-12-20 13:52:32 --> Config Class Initialized
INFO - 2024-12-20 13:52:32 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:52:32 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:52:32 --> Utf8 Class Initialized
INFO - 2024-12-20 13:52:32 --> URI Class Initialized
INFO - 2024-12-20 13:52:32 --> Router Class Initialized
INFO - 2024-12-20 13:52:32 --> Output Class Initialized
INFO - 2024-12-20 13:52:32 --> Security Class Initialized
DEBUG - 2024-12-20 13:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:52:32 --> Input Class Initialized
INFO - 2024-12-20 13:52:32 --> Language Class Initialized
INFO - 2024-12-20 13:52:32 --> Loader Class Initialized
INFO - 2024-12-20 13:52:32 --> Helper loaded: url_helper
INFO - 2024-12-20 13:52:32 --> Helper loaded: form_helper
INFO - 2024-12-20 13:52:32 --> Helper loaded: file_helper
INFO - 2024-12-20 13:52:32 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:52:32 --> Form Validation Class Initialized
INFO - 2024-12-20 13:52:32 --> Upload Class Initialized
INFO - 2024-12-20 13:52:32 --> Model "M_login" initialized
INFO - 2024-12-20 13:52:32 --> Model "M_home" initialized
INFO - 2024-12-20 13:52:32 --> Model "M_setting" initialized
INFO - 2024-12-20 13:52:32 --> Controller Class Initialized
INFO - 2024-12-20 13:52:32 --> Model "M_berita" initialized
INFO - 2024-12-20 13:52:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/berita/v_list.php
INFO - 2024-12-20 13:52:32 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-20 13:52:32 --> Final output sent to browser
DEBUG - 2024-12-20 13:52:32 --> Total execution time: 0.0724
INFO - 2024-12-20 13:52:34 --> Config Class Initialized
INFO - 2024-12-20 13:52:34 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:52:34 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:52:34 --> Utf8 Class Initialized
INFO - 2024-12-20 13:52:34 --> URI Class Initialized
INFO - 2024-12-20 13:52:34 --> Router Class Initialized
INFO - 2024-12-20 13:52:34 --> Output Class Initialized
INFO - 2024-12-20 13:52:34 --> Security Class Initialized
DEBUG - 2024-12-20 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:52:34 --> Input Class Initialized
INFO - 2024-12-20 13:52:34 --> Language Class Initialized
INFO - 2024-12-20 13:52:34 --> Loader Class Initialized
INFO - 2024-12-20 13:52:34 --> Helper loaded: url_helper
INFO - 2024-12-20 13:52:34 --> Helper loaded: form_helper
INFO - 2024-12-20 13:52:34 --> Helper loaded: file_helper
INFO - 2024-12-20 13:52:34 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:52:34 --> Form Validation Class Initialized
INFO - 2024-12-20 13:52:34 --> Upload Class Initialized
INFO - 2024-12-20 13:52:34 --> Model "M_login" initialized
INFO - 2024-12-20 13:52:34 --> Model "M_home" initialized
INFO - 2024-12-20 13:52:34 --> Model "M_setting" initialized
INFO - 2024-12-20 13:52:34 --> Controller Class Initialized
INFO - 2024-12-20 13:52:34 --> Model "M_gallery" initialized
INFO - 2024-12-20 13:52:34 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/gallery/v_list.php
INFO - 2024-12-20 13:52:34 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-20 13:52:34 --> Final output sent to browser
DEBUG - 2024-12-20 13:52:34 --> Total execution time: 0.0880
INFO - 2024-12-20 13:52:36 --> Config Class Initialized
INFO - 2024-12-20 13:52:36 --> Hooks Class Initialized
DEBUG - 2024-12-20 13:52:36 --> UTF-8 Support Enabled
INFO - 2024-12-20 13:52:36 --> Utf8 Class Initialized
INFO - 2024-12-20 13:52:36 --> URI Class Initialized
INFO - 2024-12-20 13:52:36 --> Router Class Initialized
INFO - 2024-12-20 13:52:36 --> Output Class Initialized
INFO - 2024-12-20 13:52:36 --> Security Class Initialized
DEBUG - 2024-12-20 13:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 13:52:36 --> Input Class Initialized
INFO - 2024-12-20 13:52:36 --> Language Class Initialized
INFO - 2024-12-20 13:52:36 --> Loader Class Initialized
INFO - 2024-12-20 13:52:36 --> Helper loaded: url_helper
INFO - 2024-12-20 13:52:36 --> Helper loaded: form_helper
INFO - 2024-12-20 13:52:36 --> Helper loaded: file_helper
INFO - 2024-12-20 13:52:36 --> Database Driver Class Initialized
DEBUG - 2024-12-20 13:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 13:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 13:52:36 --> Form Validation Class Initialized
INFO - 2024-12-20 13:52:36 --> Upload Class Initialized
INFO - 2024-12-20 13:52:36 --> Model "M_login" initialized
INFO - 2024-12-20 13:52:36 --> Model "M_home" initialized
INFO - 2024-12-20 13:52:36 --> Model "M_setting" initialized
INFO - 2024-12-20 13:52:36 --> Controller Class Initialized
INFO - 2024-12-20 13:52:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/v_setting.php
INFO - 2024-12-20 13:52:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-20 13:52:36 --> Final output sent to browser
DEBUG - 2024-12-20 13:52:36 --> Total execution time: 0.0518
INFO - 2024-12-20 14:08:16 --> Config Class Initialized
INFO - 2024-12-20 14:08:16 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:08:16 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:08:16 --> Utf8 Class Initialized
INFO - 2024-12-20 14:08:16 --> URI Class Initialized
DEBUG - 2024-12-20 14:08:16 --> No URI present. Default controller set.
INFO - 2024-12-20 14:08:16 --> Router Class Initialized
INFO - 2024-12-20 14:08:16 --> Output Class Initialized
INFO - 2024-12-20 14:08:16 --> Security Class Initialized
DEBUG - 2024-12-20 14:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:08:16 --> Input Class Initialized
INFO - 2024-12-20 14:08:16 --> Language Class Initialized
INFO - 2024-12-20 14:08:16 --> Loader Class Initialized
INFO - 2024-12-20 14:08:16 --> Helper loaded: url_helper
INFO - 2024-12-20 14:08:16 --> Helper loaded: form_helper
INFO - 2024-12-20 14:08:16 --> Helper loaded: file_helper
INFO - 2024-12-20 14:08:16 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:08:16 --> Form Validation Class Initialized
INFO - 2024-12-20 14:08:16 --> Upload Class Initialized
INFO - 2024-12-20 14:08:16 --> Model "M_login" initialized
INFO - 2024-12-20 14:08:16 --> Model "M_home" initialized
INFO - 2024-12-20 14:08:16 --> Model "M_setting" initialized
INFO - 2024-12-20 14:08:16 --> Controller Class Initialized
INFO - 2024-12-20 14:08:16 --> Model "M_guru" initialized
INFO - 2024-12-20 14:08:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-20 14:08:16 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-20 14:08:16 --> Final output sent to browser
DEBUG - 2024-12-20 14:08:16 --> Total execution time: 0.0693
INFO - 2024-12-20 14:08:17 --> Config Class Initialized
INFO - 2024-12-20 14:08:17 --> Config Class Initialized
INFO - 2024-12-20 14:08:17 --> Hooks Class Initialized
INFO - 2024-12-20 14:08:17 --> Config Class Initialized
INFO - 2024-12-20 14:08:17 --> Hooks Class Initialized
INFO - 2024-12-20 14:08:17 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:08:17 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:08:17 --> Utf8 Class Initialized
DEBUG - 2024-12-20 14:08:17 --> UTF-8 Support Enabled
DEBUG - 2024-12-20 14:08:17 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:08:17 --> Utf8 Class Initialized
INFO - 2024-12-20 14:08:17 --> URI Class Initialized
INFO - 2024-12-20 14:08:17 --> URI Class Initialized
INFO - 2024-12-20 14:08:17 --> Router Class Initialized
INFO - 2024-12-20 14:08:17 --> Router Class Initialized
INFO - 2024-12-20 14:08:17 --> Output Class Initialized
INFO - 2024-12-20 14:08:17 --> Output Class Initialized
INFO - 2024-12-20 14:08:17 --> Security Class Initialized
INFO - 2024-12-20 14:08:17 --> Security Class Initialized
DEBUG - 2024-12-20 14:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-20 14:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:08:17 --> Input Class Initialized
INFO - 2024-12-20 14:08:17 --> Input Class Initialized
INFO - 2024-12-20 14:08:17 --> Language Class Initialized
INFO - 2024-12-20 14:08:17 --> Language Class Initialized
INFO - 2024-12-20 14:08:17 --> Utf8 Class Initialized
ERROR - 2024-12-20 14:08:17 --> 404 Page Not Found: Images/newsletter.jpg
ERROR - 2024-12-20 14:08:17 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-20 14:08:17 --> URI Class Initialized
INFO - 2024-12-20 14:08:17 --> Router Class Initialized
INFO - 2024-12-20 14:08:17 --> Output Class Initialized
INFO - 2024-12-20 14:08:17 --> Security Class Initialized
DEBUG - 2024-12-20 14:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:08:17 --> Input Class Initialized
INFO - 2024-12-20 14:08:17 --> Language Class Initialized
ERROR - 2024-12-20 14:08:17 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-20 14:32:33 --> Config Class Initialized
INFO - 2024-12-20 14:32:33 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:32:33 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:32:33 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:33 --> URI Class Initialized
DEBUG - 2024-12-20 14:32:33 --> No URI present. Default controller set.
INFO - 2024-12-20 14:32:33 --> Router Class Initialized
INFO - 2024-12-20 14:32:33 --> Output Class Initialized
INFO - 2024-12-20 14:32:33 --> Security Class Initialized
DEBUG - 2024-12-20 14:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:33 --> Input Class Initialized
INFO - 2024-12-20 14:32:33 --> Language Class Initialized
INFO - 2024-12-20 14:32:33 --> Loader Class Initialized
INFO - 2024-12-20 14:32:33 --> Helper loaded: url_helper
INFO - 2024-12-20 14:32:33 --> Helper loaded: form_helper
INFO - 2024-12-20 14:32:33 --> Helper loaded: file_helper
INFO - 2024-12-20 14:32:33 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:32:33 --> Form Validation Class Initialized
INFO - 2024-12-20 14:32:33 --> Upload Class Initialized
INFO - 2024-12-20 14:32:33 --> Model "M_login" initialized
INFO - 2024-12-20 14:32:33 --> Model "M_home" initialized
INFO - 2024-12-20 14:32:33 --> Model "M_setting" initialized
INFO - 2024-12-20 14:32:33 --> Controller Class Initialized
INFO - 2024-12-20 14:32:33 --> Model "M_guru" initialized
INFO - 2024-12-20 14:32:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-20 14:32:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-20 14:32:33 --> Final output sent to browser
DEBUG - 2024-12-20 14:32:33 --> Total execution time: 0.2357
INFO - 2024-12-20 14:32:36 --> Config Class Initialized
INFO - 2024-12-20 14:32:36 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:32:36 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:32:36 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:36 --> URI Class Initialized
DEBUG - 2024-12-20 14:32:36 --> No URI present. Default controller set.
INFO - 2024-12-20 14:32:36 --> Router Class Initialized
INFO - 2024-12-20 14:32:36 --> Output Class Initialized
INFO - 2024-12-20 14:32:36 --> Security Class Initialized
DEBUG - 2024-12-20 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:36 --> Input Class Initialized
INFO - 2024-12-20 14:32:36 --> Language Class Initialized
INFO - 2024-12-20 14:32:36 --> Loader Class Initialized
INFO - 2024-12-20 14:32:36 --> Helper loaded: url_helper
INFO - 2024-12-20 14:32:36 --> Helper loaded: form_helper
INFO - 2024-12-20 14:32:36 --> Helper loaded: file_helper
INFO - 2024-12-20 14:32:36 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:32:36 --> Form Validation Class Initialized
INFO - 2024-12-20 14:32:36 --> Upload Class Initialized
INFO - 2024-12-20 14:32:36 --> Model "M_login" initialized
INFO - 2024-12-20 14:32:36 --> Model "M_home" initialized
INFO - 2024-12-20 14:32:36 --> Model "M_setting" initialized
INFO - 2024-12-20 14:32:36 --> Controller Class Initialized
INFO - 2024-12-20 14:32:36 --> Model "M_guru" initialized
INFO - 2024-12-20 14:32:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-20 14:32:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-20 14:32:36 --> Final output sent to browser
DEBUG - 2024-12-20 14:32:36 --> Total execution time: 0.2244
INFO - 2024-12-20 14:32:37 --> Config Class Initialized
INFO - 2024-12-20 14:32:37 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:32:37 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:32:37 --> Config Class Initialized
INFO - 2024-12-20 14:32:37 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:37 --> Hooks Class Initialized
INFO - 2024-12-20 14:32:37 --> Config Class Initialized
INFO - 2024-12-20 14:32:37 --> Hooks Class Initialized
INFO - 2024-12-20 14:32:37 --> URI Class Initialized
INFO - 2024-12-20 14:32:37 --> Router Class Initialized
DEBUG - 2024-12-20 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-12-20 14:32:37 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:32:37 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:37 --> Output Class Initialized
INFO - 2024-12-20 14:32:37 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:37 --> Security Class Initialized
INFO - 2024-12-20 14:32:37 --> URI Class Initialized
DEBUG - 2024-12-20 14:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:37 --> Router Class Initialized
INFO - 2024-12-20 14:32:37 --> Input Class Initialized
INFO - 2024-12-20 14:32:37 --> Language Class Initialized
INFO - 2024-12-20 14:32:37 --> Output Class Initialized
ERROR - 2024-12-20 14:32:37 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-20 14:32:37 --> Security Class Initialized
DEBUG - 2024-12-20 14:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:37 --> Input Class Initialized
INFO - 2024-12-20 14:32:37 --> Language Class Initialized
INFO - 2024-12-20 14:32:37 --> URI Class Initialized
ERROR - 2024-12-20 14:32:37 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-20 14:32:37 --> Router Class Initialized
INFO - 2024-12-20 14:32:37 --> Output Class Initialized
INFO - 2024-12-20 14:32:37 --> Security Class Initialized
DEBUG - 2024-12-20 14:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:37 --> Input Class Initialized
INFO - 2024-12-20 14:32:37 --> Language Class Initialized
ERROR - 2024-12-20 14:32:37 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-20 14:32:38 --> Config Class Initialized
INFO - 2024-12-20 14:32:38 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:32:38 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:32:38 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:38 --> URI Class Initialized
DEBUG - 2024-12-20 14:32:38 --> No URI present. Default controller set.
INFO - 2024-12-20 14:32:38 --> Router Class Initialized
INFO - 2024-12-20 14:32:38 --> Output Class Initialized
INFO - 2024-12-20 14:32:38 --> Security Class Initialized
DEBUG - 2024-12-20 14:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:38 --> Input Class Initialized
INFO - 2024-12-20 14:32:38 --> Language Class Initialized
INFO - 2024-12-20 14:32:38 --> Loader Class Initialized
INFO - 2024-12-20 14:32:38 --> Helper loaded: url_helper
INFO - 2024-12-20 14:32:38 --> Helper loaded: form_helper
INFO - 2024-12-20 14:32:38 --> Helper loaded: file_helper
INFO - 2024-12-20 14:32:38 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:32:38 --> Form Validation Class Initialized
INFO - 2024-12-20 14:32:38 --> Upload Class Initialized
INFO - 2024-12-20 14:32:38 --> Model "M_login" initialized
INFO - 2024-12-20 14:32:38 --> Model "M_home" initialized
INFO - 2024-12-20 14:32:38 --> Model "M_setting" initialized
INFO - 2024-12-20 14:32:38 --> Controller Class Initialized
INFO - 2024-12-20 14:32:38 --> Model "M_guru" initialized
INFO - 2024-12-20 14:32:38 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-20 14:32:38 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-20 14:32:38 --> Final output sent to browser
DEBUG - 2024-12-20 14:32:38 --> Total execution time: 0.1355
INFO - 2024-12-20 14:32:39 --> Config Class Initialized
INFO - 2024-12-20 14:32:39 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:32:39 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:32:39 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:39 --> URI Class Initialized
INFO - 2024-12-20 14:32:39 --> Router Class Initialized
INFO - 2024-12-20 14:32:39 --> Output Class Initialized
INFO - 2024-12-20 14:32:39 --> Security Class Initialized
DEBUG - 2024-12-20 14:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:39 --> Input Class Initialized
INFO - 2024-12-20 14:32:39 --> Language Class Initialized
ERROR - 2024-12-20 14:32:39 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-20 14:32:39 --> Config Class Initialized
INFO - 2024-12-20 14:32:39 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:32:39 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:32:39 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:39 --> URI Class Initialized
INFO - 2024-12-20 14:32:39 --> Config Class Initialized
INFO - 2024-12-20 14:32:39 --> Hooks Class Initialized
INFO - 2024-12-20 14:32:39 --> Router Class Initialized
DEBUG - 2024-12-20 14:32:39 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:32:39 --> Output Class Initialized
INFO - 2024-12-20 14:32:39 --> Utf8 Class Initialized
INFO - 2024-12-20 14:32:39 --> Security Class Initialized
INFO - 2024-12-20 14:32:39 --> URI Class Initialized
DEBUG - 2024-12-20 14:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:39 --> Input Class Initialized
INFO - 2024-12-20 14:32:39 --> Router Class Initialized
INFO - 2024-12-20 14:32:39 --> Language Class Initialized
INFO - 2024-12-20 14:32:39 --> Output Class Initialized
ERROR - 2024-12-20 14:32:39 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-20 14:32:39 --> Security Class Initialized
DEBUG - 2024-12-20 14:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:32:39 --> Input Class Initialized
INFO - 2024-12-20 14:32:39 --> Language Class Initialized
ERROR - 2024-12-20 14:32:39 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-20 14:34:28 --> Config Class Initialized
INFO - 2024-12-20 14:34:28 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:34:28 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:28 --> Utf8 Class Initialized
INFO - 2024-12-20 14:34:28 --> URI Class Initialized
DEBUG - 2024-12-20 14:34:28 --> No URI present. Default controller set.
INFO - 2024-12-20 14:34:28 --> Router Class Initialized
INFO - 2024-12-20 14:34:28 --> Output Class Initialized
INFO - 2024-12-20 14:34:28 --> Security Class Initialized
DEBUG - 2024-12-20 14:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:34:28 --> Input Class Initialized
INFO - 2024-12-20 14:34:28 --> Language Class Initialized
INFO - 2024-12-20 14:34:28 --> Loader Class Initialized
INFO - 2024-12-20 14:34:28 --> Helper loaded: url_helper
INFO - 2024-12-20 14:34:28 --> Helper loaded: form_helper
INFO - 2024-12-20 14:34:28 --> Helper loaded: file_helper
INFO - 2024-12-20 14:34:28 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:34:28 --> Form Validation Class Initialized
INFO - 2024-12-20 14:34:28 --> Upload Class Initialized
INFO - 2024-12-20 14:34:28 --> Model "M_login" initialized
INFO - 2024-12-20 14:34:28 --> Model "M_home" initialized
INFO - 2024-12-20 14:34:28 --> Model "M_setting" initialized
INFO - 2024-12-20 14:34:28 --> Controller Class Initialized
INFO - 2024-12-20 14:34:28 --> Model "M_guru" initialized
INFO - 2024-12-20 14:34:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-20 14:34:28 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-20 14:34:28 --> Final output sent to browser
DEBUG - 2024-12-20 14:34:28 --> Total execution time: 0.1743
INFO - 2024-12-20 14:34:29 --> Config Class Initialized
INFO - 2024-12-20 14:34:29 --> Hooks Class Initialized
INFO - 2024-12-20 14:34:29 --> Config Class Initialized
INFO - 2024-12-20 14:34:29 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:34:29 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:29 --> Utf8 Class Initialized
DEBUG - 2024-12-20 14:34:29 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:29 --> Utf8 Class Initialized
INFO - 2024-12-20 14:34:29 --> URI Class Initialized
INFO - 2024-12-20 14:34:29 --> URI Class Initialized
INFO - 2024-12-20 14:34:29 --> Router Class Initialized
INFO - 2024-12-20 14:34:29 --> Router Class Initialized
INFO - 2024-12-20 14:34:29 --> Output Class Initialized
INFO - 2024-12-20 14:34:29 --> Security Class Initialized
INFO - 2024-12-20 14:34:29 --> Output Class Initialized
INFO - 2024-12-20 14:34:29 --> Security Class Initialized
DEBUG - 2024-12-20 14:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:34:29 --> Input Class Initialized
DEBUG - 2024-12-20 14:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:34:29 --> Input Class Initialized
INFO - 2024-12-20 14:34:29 --> Language Class Initialized
INFO - 2024-12-20 14:34:29 --> Config Class Initialized
INFO - 2024-12-20 14:34:29 --> Hooks Class Initialized
INFO - 2024-12-20 14:34:29 --> Language Class Initialized
ERROR - 2024-12-20 14:34:29 --> 404 Page Not Found: Images/team_background.jpg
ERROR - 2024-12-20 14:34:29 --> 404 Page Not Found: Images/courses_background.jpg
DEBUG - 2024-12-20 14:34:29 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:29 --> Utf8 Class Initialized
INFO - 2024-12-20 14:34:29 --> URI Class Initialized
INFO - 2024-12-20 14:34:29 --> Router Class Initialized
INFO - 2024-12-20 14:34:29 --> Output Class Initialized
INFO - 2024-12-20 14:34:29 --> Security Class Initialized
DEBUG - 2024-12-20 14:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:34:29 --> Input Class Initialized
INFO - 2024-12-20 14:34:29 --> Language Class Initialized
ERROR - 2024-12-20 14:34:29 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-20 14:34:31 --> Config Class Initialized
INFO - 2024-12-20 14:34:31 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:34:31 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:31 --> Utf8 Class Initialized
INFO - 2024-12-20 14:34:31 --> URI Class Initialized
INFO - 2024-12-20 14:34:31 --> Router Class Initialized
INFO - 2024-12-20 14:34:31 --> Output Class Initialized
INFO - 2024-12-20 14:34:31 --> Security Class Initialized
DEBUG - 2024-12-20 14:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:34:31 --> Input Class Initialized
INFO - 2024-12-20 14:34:31 --> Language Class Initialized
INFO - 2024-12-20 14:34:31 --> Loader Class Initialized
INFO - 2024-12-20 14:34:31 --> Helper loaded: url_helper
INFO - 2024-12-20 14:34:31 --> Helper loaded: form_helper
INFO - 2024-12-20 14:34:31 --> Helper loaded: file_helper
INFO - 2024-12-20 14:34:31 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:34:31 --> Form Validation Class Initialized
INFO - 2024-12-20 14:34:31 --> Upload Class Initialized
INFO - 2024-12-20 14:34:31 --> Model "M_login" initialized
INFO - 2024-12-20 14:34:31 --> Model "M_home" initialized
INFO - 2024-12-20 14:34:31 --> Model "M_setting" initialized
INFO - 2024-12-20 14:34:31 --> Controller Class Initialized
INFO - 2024-12-20 14:34:31 --> Model "M_guru" initialized
INFO - 2024-12-20 14:34:31 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-20 14:34:31 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-20 14:34:31 --> Final output sent to browser
DEBUG - 2024-12-20 14:34:31 --> Total execution time: 0.1675
INFO - 2024-12-20 14:34:32 --> Config Class Initialized
INFO - 2024-12-20 14:34:32 --> Config Class Initialized
INFO - 2024-12-20 14:34:32 --> Hooks Class Initialized
INFO - 2024-12-20 14:34:32 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:34:32 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:32 --> Utf8 Class Initialized
DEBUG - 2024-12-20 14:34:32 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:32 --> Utf8 Class Initialized
INFO - 2024-12-20 14:34:32 --> URI Class Initialized
INFO - 2024-12-20 14:34:32 --> URI Class Initialized
INFO - 2024-12-20 14:34:32 --> Router Class Initialized
INFO - 2024-12-20 14:34:32 --> Output Class Initialized
INFO - 2024-12-20 14:34:32 --> Router Class Initialized
INFO - 2024-12-20 14:34:32 --> Security Class Initialized
INFO - 2024-12-20 14:34:32 --> Output Class Initialized
INFO - 2024-12-20 14:34:32 --> Security Class Initialized
DEBUG - 2024-12-20 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:34:32 --> Input Class Initialized
INFO - 2024-12-20 14:34:32 --> Language Class Initialized
DEBUG - 2024-12-20 14:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-12-20 14:34:32 --> 404 Page Not Found: Images/courses_background.jpg
INFO - 2024-12-20 14:34:32 --> Input Class Initialized
INFO - 2024-12-20 14:34:32 --> Language Class Initialized
ERROR - 2024-12-20 14:34:32 --> 404 Page Not Found: Images/team_background.jpg
INFO - 2024-12-20 14:34:32 --> Config Class Initialized
INFO - 2024-12-20 14:34:32 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:34:32 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:32 --> Utf8 Class Initialized
INFO - 2024-12-20 14:34:32 --> URI Class Initialized
INFO - 2024-12-20 14:34:32 --> Router Class Initialized
INFO - 2024-12-20 14:34:32 --> Output Class Initialized
INFO - 2024-12-20 14:34:32 --> Security Class Initialized
DEBUG - 2024-12-20 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:34:32 --> Input Class Initialized
INFO - 2024-12-20 14:34:32 --> Language Class Initialized
ERROR - 2024-12-20 14:34:32 --> 404 Page Not Found: Images/newsletter.jpg
INFO - 2024-12-20 14:34:35 --> Config Class Initialized
INFO - 2024-12-20 14:34:35 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:34:35 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:34:35 --> Utf8 Class Initialized
INFO - 2024-12-20 14:34:35 --> URI Class Initialized
INFO - 2024-12-20 14:34:35 --> Router Class Initialized
INFO - 2024-12-20 14:34:35 --> Output Class Initialized
INFO - 2024-12-20 14:34:35 --> Security Class Initialized
DEBUG - 2024-12-20 14:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:34:35 --> Input Class Initialized
INFO - 2024-12-20 14:34:35 --> Language Class Initialized
INFO - 2024-12-20 14:34:35 --> Loader Class Initialized
INFO - 2024-12-20 14:34:35 --> Helper loaded: url_helper
INFO - 2024-12-20 14:34:35 --> Helper loaded: form_helper
INFO - 2024-12-20 14:34:35 --> Helper loaded: file_helper
INFO - 2024-12-20 14:34:35 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:34:35 --> Form Validation Class Initialized
INFO - 2024-12-20 14:34:35 --> Upload Class Initialized
INFO - 2024-12-20 14:34:35 --> Model "M_login" initialized
INFO - 2024-12-20 14:34:35 --> Model "M_home" initialized
INFO - 2024-12-20 14:34:35 --> Model "M_setting" initialized
INFO - 2024-12-20 14:34:35 --> Controller Class Initialized
INFO - 2024-12-20 14:34:35 --> Model "M_guru" initialized
INFO - 2024-12-20 14:34:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-20 14:34:36 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 14:34:36 --> Final output sent to browser
DEBUG - 2024-12-20 14:34:36 --> Total execution time: 0.1739
INFO - 2024-12-20 14:51:56 --> Config Class Initialized
INFO - 2024-12-20 14:51:56 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:51:56 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:51:56 --> Utf8 Class Initialized
INFO - 2024-12-20 14:51:56 --> URI Class Initialized
INFO - 2024-12-20 14:51:56 --> Router Class Initialized
INFO - 2024-12-20 14:51:56 --> Output Class Initialized
INFO - 2024-12-20 14:51:56 --> Security Class Initialized
DEBUG - 2024-12-20 14:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:51:56 --> Input Class Initialized
INFO - 2024-12-20 14:51:56 --> Language Class Initialized
INFO - 2024-12-20 14:51:56 --> Loader Class Initialized
INFO - 2024-12-20 14:51:56 --> Helper loaded: url_helper
INFO - 2024-12-20 14:51:56 --> Helper loaded: form_helper
INFO - 2024-12-20 14:51:56 --> Helper loaded: file_helper
INFO - 2024-12-20 14:51:56 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:51:56 --> Form Validation Class Initialized
INFO - 2024-12-20 14:51:56 --> Upload Class Initialized
INFO - 2024-12-20 14:51:56 --> Model "M_login" initialized
INFO - 2024-12-20 14:51:56 --> Model "M_home" initialized
INFO - 2024-12-20 14:51:56 --> Model "M_setting" initialized
INFO - 2024-12-20 14:51:56 --> Controller Class Initialized
INFO - 2024-12-20 14:51:56 --> Model "M_guru" initialized
INFO - 2024-12-20 14:51:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-20 14:51:56 --> Pagination Class Initialized
INFO - 2024-12-20 14:51:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_berita.php
INFO - 2024-12-20 14:51:56 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 14:51:56 --> Final output sent to browser
DEBUG - 2024-12-20 14:51:56 --> Total execution time: 0.1885
INFO - 2024-12-20 14:52:13 --> Config Class Initialized
INFO - 2024-12-20 14:52:13 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:52:13 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:52:13 --> Utf8 Class Initialized
INFO - 2024-12-20 14:52:13 --> URI Class Initialized
INFO - 2024-12-20 14:52:13 --> Router Class Initialized
INFO - 2024-12-20 14:52:13 --> Output Class Initialized
INFO - 2024-12-20 14:52:13 --> Security Class Initialized
DEBUG - 2024-12-20 14:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:52:13 --> Input Class Initialized
INFO - 2024-12-20 14:52:13 --> Language Class Initialized
INFO - 2024-12-20 14:52:13 --> Loader Class Initialized
INFO - 2024-12-20 14:52:13 --> Helper loaded: url_helper
INFO - 2024-12-20 14:52:13 --> Helper loaded: form_helper
INFO - 2024-12-20 14:52:13 --> Helper loaded: file_helper
INFO - 2024-12-20 14:52:13 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:52:13 --> Form Validation Class Initialized
INFO - 2024-12-20 14:52:13 --> Upload Class Initialized
INFO - 2024-12-20 14:52:13 --> Model "M_login" initialized
INFO - 2024-12-20 14:52:13 --> Model "M_home" initialized
INFO - 2024-12-20 14:52:13 --> Model "M_setting" initialized
INFO - 2024-12-20 14:52:13 --> Controller Class Initialized
INFO - 2024-12-20 14:52:13 --> Model "M_guru" initialized
INFO - 2024-12-20 14:52:13 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_profile.php
INFO - 2024-12-20 14:52:13 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 14:52:13 --> Final output sent to browser
DEBUG - 2024-12-20 14:52:13 --> Total execution time: 0.2146
INFO - 2024-12-20 14:52:21 --> Config Class Initialized
INFO - 2024-12-20 14:52:21 --> Hooks Class Initialized
DEBUG - 2024-12-20 14:52:21 --> UTF-8 Support Enabled
INFO - 2024-12-20 14:52:21 --> Utf8 Class Initialized
INFO - 2024-12-20 14:52:21 --> URI Class Initialized
INFO - 2024-12-20 14:52:21 --> Router Class Initialized
INFO - 2024-12-20 14:52:21 --> Output Class Initialized
INFO - 2024-12-20 14:52:21 --> Security Class Initialized
DEBUG - 2024-12-20 14:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 14:52:21 --> Input Class Initialized
INFO - 2024-12-20 14:52:21 --> Language Class Initialized
INFO - 2024-12-20 14:52:21 --> Loader Class Initialized
INFO - 2024-12-20 14:52:21 --> Helper loaded: url_helper
INFO - 2024-12-20 14:52:21 --> Helper loaded: form_helper
INFO - 2024-12-20 14:52:21 --> Helper loaded: file_helper
INFO - 2024-12-20 14:52:21 --> Database Driver Class Initialized
DEBUG - 2024-12-20 14:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-20 14:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 14:52:21 --> Form Validation Class Initialized
INFO - 2024-12-20 14:52:21 --> Upload Class Initialized
INFO - 2024-12-20 14:52:21 --> Model "M_login" initialized
INFO - 2024-12-20 14:52:21 --> Model "M_home" initialized
INFO - 2024-12-20 14:52:21 --> Model "M_setting" initialized
INFO - 2024-12-20 14:52:21 --> Controller Class Initialized
INFO - 2024-12-20 14:52:21 --> Model "M_guru" initialized
INFO - 2024-12-20 14:52:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_guru.php
INFO - 2024-12-20 14:52:21 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-20 14:52:21 --> Final output sent to browser
DEBUG - 2024-12-20 14:52:21 --> Total execution time: 0.2169
