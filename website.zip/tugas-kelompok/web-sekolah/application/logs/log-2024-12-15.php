<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-15 00:35:22 --> Config Class Initialized
INFO - 2024-12-15 00:35:22 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:35:22 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:35:22 --> Utf8 Class Initialized
INFO - 2024-12-15 00:35:22 --> URI Class Initialized
INFO - 2024-12-15 00:35:22 --> Router Class Initialized
INFO - 2024-12-15 00:35:22 --> Output Class Initialized
INFO - 2024-12-15 00:35:22 --> Security Class Initialized
DEBUG - 2024-12-15 00:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:35:22 --> Input Class Initialized
INFO - 2024-12-15 00:35:22 --> Language Class Initialized
INFO - 2024-12-15 00:35:22 --> Loader Class Initialized
INFO - 2024-12-15 00:35:22 --> Helper loaded: url_helper
INFO - 2024-12-15 00:35:22 --> Helper loaded: form_helper
INFO - 2024-12-15 00:35:22 --> Helper loaded: file_helper
INFO - 2024-12-15 00:35:22 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:35:22 --> Form Validation Class Initialized
INFO - 2024-12-15 00:35:22 --> Upload Class Initialized
INFO - 2024-12-15 00:35:22 --> Model "M_login" initialized
INFO - 2024-12-15 00:35:22 --> Model "M_home" initialized
INFO - 2024-12-15 00:35:22 --> Model "M_setting" initialized
INFO - 2024-12-15 00:35:22 --> Controller Class Initialized
INFO - 2024-12-15 00:35:22 --> Model "M_guru" initialized
INFO - 2024-12-15 00:35:22 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_edit.php
INFO - 2024-12-15 00:35:22 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:35:22 --> Final output sent to browser
DEBUG - 2024-12-15 00:35:22 --> Total execution time: 0.1160
INFO - 2024-12-15 00:44:29 --> Config Class Initialized
INFO - 2024-12-15 00:44:29 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:44:29 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:44:29 --> Utf8 Class Initialized
INFO - 2024-12-15 00:44:29 --> URI Class Initialized
INFO - 2024-12-15 00:44:29 --> Router Class Initialized
INFO - 2024-12-15 00:44:29 --> Output Class Initialized
INFO - 2024-12-15 00:44:29 --> Security Class Initialized
DEBUG - 2024-12-15 00:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:44:29 --> Input Class Initialized
INFO - 2024-12-15 00:44:29 --> Language Class Initialized
INFO - 2024-12-15 00:44:29 --> Loader Class Initialized
INFO - 2024-12-15 00:44:29 --> Helper loaded: url_helper
INFO - 2024-12-15 00:44:29 --> Helper loaded: form_helper
INFO - 2024-12-15 00:44:29 --> Helper loaded: file_helper
INFO - 2024-12-15 00:44:29 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:44:29 --> Form Validation Class Initialized
INFO - 2024-12-15 00:44:29 --> Upload Class Initialized
INFO - 2024-12-15 00:44:29 --> Model "M_login" initialized
INFO - 2024-12-15 00:44:29 --> Model "M_home" initialized
INFO - 2024-12-15 00:44:29 --> Model "M_setting" initialized
INFO - 2024-12-15 00:44:29 --> Controller Class Initialized
INFO - 2024-12-15 00:44:29 --> Model "M_guru" initialized
INFO - 2024-12-15 00:44:29 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-15 00:44:29 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:44:29 --> Final output sent to browser
DEBUG - 2024-12-15 00:44:29 --> Total execution time: 0.0964
INFO - 2024-12-15 00:44:33 --> Config Class Initialized
INFO - 2024-12-15 00:44:33 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:44:33 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:44:33 --> Utf8 Class Initialized
INFO - 2024-12-15 00:44:33 --> URI Class Initialized
INFO - 2024-12-15 00:44:33 --> Router Class Initialized
INFO - 2024-12-15 00:44:33 --> Output Class Initialized
INFO - 2024-12-15 00:44:33 --> Security Class Initialized
DEBUG - 2024-12-15 00:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:44:33 --> Input Class Initialized
INFO - 2024-12-15 00:44:33 --> Language Class Initialized
INFO - 2024-12-15 00:44:33 --> Loader Class Initialized
INFO - 2024-12-15 00:44:33 --> Helper loaded: url_helper
INFO - 2024-12-15 00:44:33 --> Helper loaded: form_helper
INFO - 2024-12-15 00:44:33 --> Helper loaded: file_helper
INFO - 2024-12-15 00:44:33 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:44:33 --> Form Validation Class Initialized
INFO - 2024-12-15 00:44:33 --> Upload Class Initialized
INFO - 2024-12-15 00:44:33 --> Model "M_login" initialized
INFO - 2024-12-15 00:44:33 --> Model "M_home" initialized
INFO - 2024-12-15 00:44:33 --> Model "M_setting" initialized
INFO - 2024-12-15 00:44:33 --> Controller Class Initialized
INFO - 2024-12-15 00:44:33 --> Model "M_guru" initialized
INFO - 2024-12-15 00:44:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_add.php
INFO - 2024-12-15 00:44:33 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:44:33 --> Final output sent to browser
DEBUG - 2024-12-15 00:44:33 --> Total execution time: 0.0814
INFO - 2024-12-15 00:44:35 --> Config Class Initialized
INFO - 2024-12-15 00:44:35 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:44:35 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:44:35 --> Utf8 Class Initialized
INFO - 2024-12-15 00:44:35 --> URI Class Initialized
INFO - 2024-12-15 00:44:35 --> Router Class Initialized
INFO - 2024-12-15 00:44:35 --> Output Class Initialized
INFO - 2024-12-15 00:44:35 --> Security Class Initialized
DEBUG - 2024-12-15 00:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:44:35 --> Input Class Initialized
INFO - 2024-12-15 00:44:35 --> Language Class Initialized
INFO - 2024-12-15 00:44:35 --> Loader Class Initialized
INFO - 2024-12-15 00:44:35 --> Helper loaded: url_helper
INFO - 2024-12-15 00:44:35 --> Helper loaded: form_helper
INFO - 2024-12-15 00:44:35 --> Helper loaded: file_helper
INFO - 2024-12-15 00:44:35 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:44:35 --> Form Validation Class Initialized
INFO - 2024-12-15 00:44:35 --> Upload Class Initialized
INFO - 2024-12-15 00:44:35 --> Model "M_login" initialized
INFO - 2024-12-15 00:44:35 --> Model "M_home" initialized
INFO - 2024-12-15 00:44:35 --> Model "M_setting" initialized
INFO - 2024-12-15 00:44:35 --> Controller Class Initialized
INFO - 2024-12-15 00:44:35 --> Model "M_guru" initialized
INFO - 2024-12-15 00:44:35 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-15 00:44:35 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:44:35 --> Final output sent to browser
DEBUG - 2024-12-15 00:44:35 --> Total execution time: 0.0733
INFO - 2024-12-15 00:47:54 --> Config Class Initialized
INFO - 2024-12-15 00:47:54 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:47:54 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:47:54 --> Utf8 Class Initialized
INFO - 2024-12-15 00:47:54 --> URI Class Initialized
INFO - 2024-12-15 00:47:54 --> Router Class Initialized
INFO - 2024-12-15 00:47:54 --> Output Class Initialized
INFO - 2024-12-15 00:47:54 --> Security Class Initialized
DEBUG - 2024-12-15 00:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:47:54 --> Input Class Initialized
INFO - 2024-12-15 00:47:54 --> Language Class Initialized
INFO - 2024-12-15 00:47:54 --> Loader Class Initialized
INFO - 2024-12-15 00:47:54 --> Helper loaded: url_helper
INFO - 2024-12-15 00:47:54 --> Helper loaded: form_helper
INFO - 2024-12-15 00:47:54 --> Helper loaded: file_helper
INFO - 2024-12-15 00:47:54 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:47:54 --> Form Validation Class Initialized
INFO - 2024-12-15 00:47:54 --> Upload Class Initialized
INFO - 2024-12-15 00:47:54 --> Model "M_login" initialized
INFO - 2024-12-15 00:47:54 --> Model "M_home" initialized
INFO - 2024-12-15 00:47:54 --> Model "M_setting" initialized
INFO - 2024-12-15 00:47:54 --> Controller Class Initialized
INFO - 2024-12-15 00:47:54 --> Model "M_guru" initialized
INFO - 2024-12-15 00:47:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_add.php
INFO - 2024-12-15 00:47:54 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:47:54 --> Final output sent to browser
DEBUG - 2024-12-15 00:47:54 --> Total execution time: 0.1278
INFO - 2024-12-15 00:49:15 --> Config Class Initialized
INFO - 2024-12-15 00:49:15 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:49:15 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:49:15 --> Utf8 Class Initialized
INFO - 2024-12-15 00:49:15 --> URI Class Initialized
INFO - 2024-12-15 00:49:15 --> Router Class Initialized
INFO - 2024-12-15 00:49:15 --> Output Class Initialized
INFO - 2024-12-15 00:49:15 --> Security Class Initialized
DEBUG - 2024-12-15 00:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:49:15 --> Input Class Initialized
INFO - 2024-12-15 00:49:15 --> Language Class Initialized
INFO - 2024-12-15 00:49:15 --> Loader Class Initialized
INFO - 2024-12-15 00:49:15 --> Helper loaded: url_helper
INFO - 2024-12-15 00:49:15 --> Helper loaded: form_helper
INFO - 2024-12-15 00:49:15 --> Helper loaded: file_helper
INFO - 2024-12-15 00:49:15 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:49:15 --> Form Validation Class Initialized
INFO - 2024-12-15 00:49:15 --> Upload Class Initialized
INFO - 2024-12-15 00:49:15 --> Model "M_login" initialized
INFO - 2024-12-15 00:49:15 --> Model "M_home" initialized
INFO - 2024-12-15 00:49:15 --> Model "M_setting" initialized
INFO - 2024-12-15 00:49:15 --> Controller Class Initialized
INFO - 2024-12-15 00:49:15 --> Model "M_guru" initialized
INFO - 2024-12-15 00:49:15 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-15 00:49:15 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:49:15 --> Final output sent to browser
DEBUG - 2024-12-15 00:49:15 --> Total execution time: 0.0767
INFO - 2024-12-15 00:49:18 --> Config Class Initialized
INFO - 2024-12-15 00:49:18 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:49:18 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:49:18 --> Utf8 Class Initialized
INFO - 2024-12-15 00:49:18 --> URI Class Initialized
INFO - 2024-12-15 00:49:18 --> Router Class Initialized
INFO - 2024-12-15 00:49:18 --> Output Class Initialized
INFO - 2024-12-15 00:49:18 --> Security Class Initialized
DEBUG - 2024-12-15 00:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:49:18 --> Input Class Initialized
INFO - 2024-12-15 00:49:18 --> Language Class Initialized
INFO - 2024-12-15 00:49:18 --> Loader Class Initialized
INFO - 2024-12-15 00:49:18 --> Helper loaded: url_helper
INFO - 2024-12-15 00:49:18 --> Helper loaded: form_helper
INFO - 2024-12-15 00:49:18 --> Helper loaded: file_helper
INFO - 2024-12-15 00:49:18 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:49:18 --> Form Validation Class Initialized
INFO - 2024-12-15 00:49:18 --> Upload Class Initialized
INFO - 2024-12-15 00:49:18 --> Model "M_login" initialized
INFO - 2024-12-15 00:49:18 --> Model "M_home" initialized
INFO - 2024-12-15 00:49:18 --> Model "M_setting" initialized
INFO - 2024-12-15 00:49:18 --> Controller Class Initialized
INFO - 2024-12-15 00:49:18 --> Model "M_guru" initialized
INFO - 2024-12-15 00:49:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_edit.php
INFO - 2024-12-15 00:49:18 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:49:18 --> Final output sent to browser
DEBUG - 2024-12-15 00:49:18 --> Total execution time: 0.1036
INFO - 2024-12-15 00:49:26 --> Config Class Initialized
INFO - 2024-12-15 00:49:26 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:49:26 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:49:26 --> Utf8 Class Initialized
INFO - 2024-12-15 00:49:26 --> URI Class Initialized
INFO - 2024-12-15 00:49:26 --> Router Class Initialized
INFO - 2024-12-15 00:49:26 --> Output Class Initialized
INFO - 2024-12-15 00:49:26 --> Security Class Initialized
DEBUG - 2024-12-15 00:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:49:26 --> Input Class Initialized
INFO - 2024-12-15 00:49:26 --> Language Class Initialized
INFO - 2024-12-15 00:49:26 --> Loader Class Initialized
INFO - 2024-12-15 00:49:26 --> Helper loaded: url_helper
INFO - 2024-12-15 00:49:26 --> Helper loaded: form_helper
INFO - 2024-12-15 00:49:26 --> Helper loaded: file_helper
INFO - 2024-12-15 00:49:26 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:49:26 --> Form Validation Class Initialized
INFO - 2024-12-15 00:49:26 --> Upload Class Initialized
INFO - 2024-12-15 00:49:26 --> Model "M_login" initialized
INFO - 2024-12-15 00:49:26 --> Model "M_home" initialized
INFO - 2024-12-15 00:49:26 --> Model "M_setting" initialized
INFO - 2024-12-15 00:49:26 --> Controller Class Initialized
INFO - 2024-12-15 00:49:26 --> Model "M_guru" initialized
INFO - 2024-12-15 00:49:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_list.php
INFO - 2024-12-15 00:49:26 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:49:26 --> Final output sent to browser
DEBUG - 2024-12-15 00:49:26 --> Total execution time: 0.1124
INFO - 2024-12-15 00:49:27 --> Config Class Initialized
INFO - 2024-12-15 00:49:27 --> Hooks Class Initialized
DEBUG - 2024-12-15 00:49:27 --> UTF-8 Support Enabled
INFO - 2024-12-15 00:49:27 --> Utf8 Class Initialized
INFO - 2024-12-15 00:49:27 --> URI Class Initialized
INFO - 2024-12-15 00:49:27 --> Router Class Initialized
INFO - 2024-12-15 00:49:27 --> Output Class Initialized
INFO - 2024-12-15 00:49:27 --> Security Class Initialized
DEBUG - 2024-12-15 00:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 00:49:27 --> Input Class Initialized
INFO - 2024-12-15 00:49:27 --> Language Class Initialized
INFO - 2024-12-15 00:49:27 --> Loader Class Initialized
INFO - 2024-12-15 00:49:27 --> Helper loaded: url_helper
INFO - 2024-12-15 00:49:27 --> Helper loaded: form_helper
INFO - 2024-12-15 00:49:27 --> Helper loaded: file_helper
INFO - 2024-12-15 00:49:27 --> Database Driver Class Initialized
DEBUG - 2024-12-15 00:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 00:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 00:49:27 --> Form Validation Class Initialized
INFO - 2024-12-15 00:49:27 --> Upload Class Initialized
INFO - 2024-12-15 00:49:27 --> Model "M_login" initialized
INFO - 2024-12-15 00:49:27 --> Model "M_home" initialized
INFO - 2024-12-15 00:49:27 --> Model "M_setting" initialized
INFO - 2024-12-15 00:49:27 --> Controller Class Initialized
INFO - 2024-12-15 00:49:27 --> Model "M_guru" initialized
INFO - 2024-12-15 00:49:27 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/guru/v_add.php
INFO - 2024-12-15 00:49:27 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\admin/layout/v_wrapper.php
INFO - 2024-12-15 00:49:27 --> Final output sent to browser
DEBUG - 2024-12-15 00:49:27 --> Total execution time: 0.1014
INFO - 2024-12-15 08:01:10 --> Config Class Initialized
INFO - 2024-12-15 08:01:10 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:01:10 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:01:10 --> Utf8 Class Initialized
INFO - 2024-12-15 08:01:10 --> URI Class Initialized
INFO - 2024-12-15 08:01:10 --> Router Class Initialized
INFO - 2024-12-15 08:01:10 --> Output Class Initialized
INFO - 2024-12-15 08:01:10 --> Security Class Initialized
DEBUG - 2024-12-15 08:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:01:10 --> Input Class Initialized
INFO - 2024-12-15 08:01:10 --> Language Class Initialized
INFO - 2024-12-15 08:01:10 --> Loader Class Initialized
INFO - 2024-12-15 08:01:10 --> Helper loaded: url_helper
INFO - 2024-12-15 08:01:10 --> Helper loaded: form_helper
INFO - 2024-12-15 08:01:10 --> Helper loaded: file_helper
INFO - 2024-12-15 08:01:10 --> Database Driver Class Initialized
DEBUG - 2024-12-15 08:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 08:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:01:10 --> Form Validation Class Initialized
INFO - 2024-12-15 08:01:10 --> Upload Class Initialized
INFO - 2024-12-15 08:01:10 --> Model "M_login" initialized
INFO - 2024-12-15 08:01:10 --> Model "M_home" initialized
INFO - 2024-12-15 08:01:10 --> Model "M_setting" initialized
INFO - 2024-12-15 08:01:10 --> Controller Class Initialized
INFO - 2024-12-15 08:01:10 --> Model "M_guru" initialized
INFO - 2024-12-15 08:01:10 --> Config Class Initialized
INFO - 2024-12-15 08:01:10 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:01:10 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:01:10 --> Utf8 Class Initialized
INFO - 2024-12-15 08:01:10 --> URI Class Initialized
INFO - 2024-12-15 08:01:10 --> Router Class Initialized
INFO - 2024-12-15 08:01:10 --> Output Class Initialized
INFO - 2024-12-15 08:01:10 --> Security Class Initialized
DEBUG - 2024-12-15 08:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:01:10 --> Input Class Initialized
INFO - 2024-12-15 08:01:10 --> Language Class Initialized
INFO - 2024-12-15 08:01:10 --> Loader Class Initialized
INFO - 2024-12-15 08:01:10 --> Helper loaded: url_helper
INFO - 2024-12-15 08:01:10 --> Helper loaded: form_helper
INFO - 2024-12-15 08:01:10 --> Helper loaded: file_helper
INFO - 2024-12-15 08:01:10 --> Database Driver Class Initialized
DEBUG - 2024-12-15 08:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 08:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:01:10 --> Form Validation Class Initialized
INFO - 2024-12-15 08:01:10 --> Upload Class Initialized
INFO - 2024-12-15 08:01:10 --> Model "M_login" initialized
INFO - 2024-12-15 08:01:10 --> Model "M_home" initialized
INFO - 2024-12-15 08:01:10 --> Model "M_setting" initialized
INFO - 2024-12-15 08:01:10 --> Controller Class Initialized
INFO - 2024-12-15 08:01:10 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_login.php
INFO - 2024-12-15 08:01:10 --> Final output sent to browser
DEBUG - 2024-12-15 08:01:10 --> Total execution time: 0.0403
