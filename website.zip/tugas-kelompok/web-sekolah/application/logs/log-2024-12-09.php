<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-09 10:21:00 --> Config Class Initialized
INFO - 2024-12-09 10:21:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:21:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:00 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:00 --> URI Class Initialized
INFO - 2024-12-09 10:21:00 --> Router Class Initialized
INFO - 2024-12-09 10:21:00 --> Output Class Initialized
INFO - 2024-12-09 10:21:00 --> Security Class Initialized
DEBUG - 2024-12-09 10:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:00 --> Input Class Initialized
INFO - 2024-12-09 10:21:00 --> Language Class Initialized
INFO - 2024-12-09 10:21:00 --> Loader Class Initialized
INFO - 2024-12-09 10:21:00 --> Helper loaded: url_helper
INFO - 2024-12-09 10:21:00 --> Helper loaded: form_helper
INFO - 2024-12-09 10:21:00 --> Helper loaded: file_helper
INFO - 2024-12-09 10:21:00 --> Database Driver Class Initialized
DEBUG - 2024-12-09 10:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 10:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:21:00 --> Form Validation Class Initialized
INFO - 2024-12-09 10:21:00 --> Upload Class Initialized
INFO - 2024-12-09 10:21:00 --> Model "M_login" initialized
INFO - 2024-12-09 10:21:00 --> Model "M_home" initialized
INFO - 2024-12-09 10:21:00 --> Model "M_setting" initialized
INFO - 2024-12-09 10:21:00 --> Controller Class Initialized
INFO - 2024-12-09 10:21:00 --> Model "M_guru" initialized
INFO - 2024-12-09 10:21:00 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_hubkami.php
INFO - 2024-12-09 10:21:00 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapper.php
INFO - 2024-12-09 10:21:00 --> Final output sent to browser
DEBUG - 2024-12-09 10:21:00 --> Total execution time: 0.1886
INFO - 2024-12-09 10:21:00 --> Config Class Initialized
INFO - 2024-12-09 10:21:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:21:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:00 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:00 --> URI Class Initialized
INFO - 2024-12-09 10:21:00 --> Router Class Initialized
INFO - 2024-12-09 10:21:00 --> Output Class Initialized
INFO - 2024-12-09 10:21:00 --> Security Class Initialized
DEBUG - 2024-12-09 10:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:00 --> Input Class Initialized
INFO - 2024-12-09 10:21:00 --> Language Class Initialized
ERROR - 2024-12-09 10:21:00 --> 404 Page Not Found: Home/images
INFO - 2024-12-09 10:21:05 --> Config Class Initialized
INFO - 2024-12-09 10:21:05 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:21:05 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:06 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:06 --> URI Class Initialized
INFO - 2024-12-09 10:21:06 --> Router Class Initialized
INFO - 2024-12-09 10:21:06 --> Output Class Initialized
INFO - 2024-12-09 10:21:06 --> Security Class Initialized
DEBUG - 2024-12-09 10:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:06 --> Input Class Initialized
INFO - 2024-12-09 10:21:06 --> Language Class Initialized
INFO - 2024-12-09 10:21:06 --> Loader Class Initialized
INFO - 2024-12-09 10:21:06 --> Helper loaded: url_helper
INFO - 2024-12-09 10:21:06 --> Helper loaded: form_helper
INFO - 2024-12-09 10:21:06 --> Helper loaded: file_helper
INFO - 2024-12-09 10:21:06 --> Database Driver Class Initialized
DEBUG - 2024-12-09 10:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 10:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:21:06 --> Form Validation Class Initialized
INFO - 2024-12-09 10:21:06 --> Upload Class Initialized
INFO - 2024-12-09 10:21:06 --> Model "M_login" initialized
INFO - 2024-12-09 10:21:06 --> Model "M_home" initialized
INFO - 2024-12-09 10:21:06 --> Model "M_setting" initialized
INFO - 2024-12-09 10:21:06 --> Controller Class Initialized
INFO - 2024-12-09 10:21:06 --> Model "M_guru" initialized
INFO - 2024-12-09 10:21:06 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-09 10:21:06 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-09 10:21:06 --> Final output sent to browser
DEBUG - 2024-12-09 10:21:06 --> Total execution time: 0.2096
INFO - 2024-12-09 10:21:06 --> Config Class Initialized
INFO - 2024-12-09 10:21:06 --> Hooks Class Initialized
INFO - 2024-12-09 10:21:06 --> Config Class Initialized
INFO - 2024-12-09 10:21:06 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:21:06 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:06 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:06 --> URI Class Initialized
DEBUG - 2024-12-09 10:21:06 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:06 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:06 --> Router Class Initialized
INFO - 2024-12-09 10:21:06 --> URI Class Initialized
INFO - 2024-12-09 10:21:06 --> Output Class Initialized
INFO - 2024-12-09 10:21:06 --> Router Class Initialized
INFO - 2024-12-09 10:21:06 --> Security Class Initialized
DEBUG - 2024-12-09 10:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:06 --> Output Class Initialized
INFO - 2024-12-09 10:21:06 --> Input Class Initialized
INFO - 2024-12-09 10:21:06 --> Language Class Initialized
INFO - 2024-12-09 10:21:06 --> Security Class Initialized
ERROR - 2024-12-09 10:21:06 --> 404 Page Not Found: Home/images
DEBUG - 2024-12-09 10:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:06 --> Input Class Initialized
INFO - 2024-12-09 10:21:06 --> Language Class Initialized
ERROR - 2024-12-09 10:21:06 --> 404 Page Not Found: Home/images
INFO - 2024-12-09 10:21:06 --> Config Class Initialized
INFO - 2024-12-09 10:21:06 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:21:06 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:06 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:06 --> URI Class Initialized
INFO - 2024-12-09 10:21:06 --> Router Class Initialized
INFO - 2024-12-09 10:21:06 --> Output Class Initialized
INFO - 2024-12-09 10:21:06 --> Security Class Initialized
DEBUG - 2024-12-09 10:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:06 --> Input Class Initialized
INFO - 2024-12-09 10:21:06 --> Language Class Initialized
ERROR - 2024-12-09 10:21:06 --> 404 Page Not Found: Home/images
INFO - 2024-12-09 10:21:09 --> Config Class Initialized
INFO - 2024-12-09 10:21:09 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:21:09 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:09 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:09 --> URI Class Initialized
INFO - 2024-12-09 10:21:09 --> Router Class Initialized
INFO - 2024-12-09 10:21:09 --> Output Class Initialized
INFO - 2024-12-09 10:21:09 --> Security Class Initialized
DEBUG - 2024-12-09 10:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:09 --> Input Class Initialized
INFO - 2024-12-09 10:21:09 --> Language Class Initialized
ERROR - 2024-12-09 10:21:09 --> 404 Page Not Found: Home/login
INFO - 2024-12-09 10:21:14 --> Config Class Initialized
INFO - 2024-12-09 10:21:14 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:21:14 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:14 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:14 --> URI Class Initialized
INFO - 2024-12-09 10:21:14 --> Router Class Initialized
INFO - 2024-12-09 10:21:14 --> Output Class Initialized
INFO - 2024-12-09 10:21:14 --> Security Class Initialized
DEBUG - 2024-12-09 10:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:14 --> Input Class Initialized
INFO - 2024-12-09 10:21:14 --> Language Class Initialized
INFO - 2024-12-09 10:21:14 --> Loader Class Initialized
INFO - 2024-12-09 10:21:14 --> Helper loaded: url_helper
INFO - 2024-12-09 10:21:14 --> Helper loaded: form_helper
INFO - 2024-12-09 10:21:14 --> Helper loaded: file_helper
INFO - 2024-12-09 10:21:14 --> Database Driver Class Initialized
DEBUG - 2024-12-09 10:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 10:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:21:14 --> Form Validation Class Initialized
INFO - 2024-12-09 10:21:14 --> Upload Class Initialized
INFO - 2024-12-09 10:21:14 --> Model "M_login" initialized
INFO - 2024-12-09 10:21:14 --> Model "M_home" initialized
INFO - 2024-12-09 10:21:14 --> Model "M_setting" initialized
INFO - 2024-12-09 10:21:14 --> Controller Class Initialized
INFO - 2024-12-09 10:21:14 --> Model "M_guru" initialized
INFO - 2024-12-09 10:21:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_home.php
INFO - 2024-12-09 10:21:14 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\layout/v_wrapperhome.php
INFO - 2024-12-09 10:21:14 --> Final output sent to browser
DEBUG - 2024-12-09 10:21:14 --> Total execution time: 0.1470
INFO - 2024-12-09 10:21:19 --> Config Class Initialized
INFO - 2024-12-09 10:21:19 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:21:19 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:21:19 --> Utf8 Class Initialized
INFO - 2024-12-09 10:21:19 --> URI Class Initialized
INFO - 2024-12-09 10:21:19 --> Router Class Initialized
INFO - 2024-12-09 10:21:19 --> Output Class Initialized
INFO - 2024-12-09 10:21:19 --> Security Class Initialized
DEBUG - 2024-12-09 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:21:19 --> Input Class Initialized
INFO - 2024-12-09 10:21:19 --> Language Class Initialized
INFO - 2024-12-09 10:21:19 --> Loader Class Initialized
INFO - 2024-12-09 10:21:19 --> Helper loaded: url_helper
INFO - 2024-12-09 10:21:19 --> Helper loaded: form_helper
INFO - 2024-12-09 10:21:19 --> Helper loaded: file_helper
INFO - 2024-12-09 10:21:19 --> Database Driver Class Initialized
DEBUG - 2024-12-09 10:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 10:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:21:19 --> Form Validation Class Initialized
INFO - 2024-12-09 10:21:19 --> Upload Class Initialized
INFO - 2024-12-09 10:21:19 --> Model "M_login" initialized
INFO - 2024-12-09 10:21:19 --> Model "M_home" initialized
INFO - 2024-12-09 10:21:19 --> Model "M_setting" initialized
INFO - 2024-12-09 10:21:19 --> Controller Class Initialized
INFO - 2024-12-09 10:21:19 --> File loaded: C:\xampp\htdocs\tugas-kelompok\web-sekolah\application\views\v_login.php
INFO - 2024-12-09 10:21:19 --> Final output sent to browser
DEBUG - 2024-12-09 10:21:19 --> Total execution time: 0.2712
