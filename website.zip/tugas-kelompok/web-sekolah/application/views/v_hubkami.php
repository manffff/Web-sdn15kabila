<!-- Home -->

<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="<?= base_url() ?>">Home</a></li>
								<li>Hubungi Kami</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

<!-- Contact -->

<div class="contact">
		
		<!-- Contact Map -->

		<div class="col">

			<!-- Google Map -->
					<div id="map" style=" height: 600px;"></div>
		</div>

		<!-- Contact Info -->

		<div class="contact_info_container">
			<div class="container">
				<div class="row">

					<!-- Contact Form -->
					<!-- <div class="col-lg-6"> -->
						<div class="contact_form">
							<!-- Tampilkan pesan sukses atau error -->
		
							<!-- <div class="contact_info_title">Contact Form</div> -->
							<!-- <form action="<?= base_url('contact/send'); ?>" method="POST"> -->	
				</div>
			</div>
		</div>
	</div>

<!-- Contact Info -->
<div class="col-lg-6">
						<div class="contact_info">
							<div class="contact_info_title">Contact Info</div>
							<div class="contact_info_text">
							</div>
							<div class="contact_info_location">
								<div class="contact_info_location_title">Suwawa</div>
								<ul class="location_list">
									<li>Indonesia, Provinsi Gorontalo, Kabupaten Bone Bolango, Kecamatan Kabila, Desa Po'owo.</li>
									<li>+(62) 821-5725-610</li>
									<li>sdn15kabila@gmail.com</li>
								</ul>
							</div>
							
						</div>
					</div>
				</div>
	
	<!-- Newsletter -->

	<div class="newsletter">
		<div class="newsletter_background" style="background-image:url(images/newsletter_background.jpg)"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="newsletter_container d-flex flex-lg-row flex-column align-items-center justify-content-start">
						<!-- Newsletter Content -->
						<div class="newsletter_content text-lg-left text-center">
							<div class="newsletter_title">sign up for news and offers</div>
							<div class="newsletter_subtitle">Subcribe to lastest smartphones news & great deals we offer</div>
						</div>
						<!-- Newsletter Form -->
						<div class="newsletter_form_container ml-lg-auto">
							<form action="#" id="newsletter_form" class="newsletter_form d-flex flex-row align-items-center justify-content-center">
								<input type="email" class="newsletter_input" placeholder="Your Email" required="required">
							</form>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>


<!-- Script -->
<style>
    /* Gaya untuk menentukan ukuran peta dan memastikan elemen di atas tidak tertutupi */
    #map {
        z-index: 0; /* Pastikan tidak menutupi elemen lain */
        border: 1px solid #ccc; /* Opsional: Tambahkan border */
        position: relative;
    }

    /* Pastikan elemen lain di atas peta terlihat */
    #content-above {
        position: relative;
        z-index: 1; /* Elemen ini berada di atas peta */
        background: white;
    }
</style>
<div id="map"></div> <!-- Elemen untuk menampilkan peta -->

<script>
    // Inisialisasi peta
    const map = L.map('map', {
        center: [0.556048, 123.113452], // Koordinat pusat
        zoom: 13, // Zoom awal
        scrollWheelZoom: false, // Menonaktifkan zoom dengan scroll mouse
        dragging: true // Mengaktifkan penggeseran peta
    });

    // Menambahkan layer peta OpenStreetMap
    const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    // Menambahkan marker (penanda lokasi) dengan popup
    const marker = L.marker([0.556048, 123.113452]).addTo(map)
        .bindPopup(`
            <b>SD 15 KABILA</b><br>
            Poowo, Kec. Kabila, Kabupaten Bone Bolango, Gorontalo 96119<br>
            <a href="https://maps.app.goo.gl/zYgSS25K1pUQ26278" target="_blank">SD 15 Kabila</a>
        `)
        .openPopup();

    // Event klik marker untuk membuka Google Maps
    marker.on('click', function () {
        window.open('https://maps.app.goo.gl/zYgSS25K1pUQ26278', '_blank');
    });
</script>
