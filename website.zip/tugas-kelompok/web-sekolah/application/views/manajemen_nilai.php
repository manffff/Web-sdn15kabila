<!DOCTYPE html>
<html>

<head>
    <title>Manajemen Data Nilai</title>
</head>

<body>
    <h1>Manajemen Data Nilai</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID Nilai</th>
                <th>ID Siswa</th>
                <th>ID Mata Pelajaran</th>
                <th>Jenis Penilaian</th>
                <th>Nilai</th>
                <th>Semester</th>
                <th>Tahun Ajaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($nilai as $n): ?>
                <tr>
                    <td><?php echo $n->id_nilai; ?></td>
                    <td><?php echo $n->id_siswa; ?></td>
                    <td><?php echo $n->id_mapel; ?></td>
                    <td><?php echo $n->jenis_nilai; ?></td>
                    <td><?php echo $n->nilai; ?></td>
                    <td><?php echo $n->semester; ?></td>
                    <td><?php echo $n->tahun_ajaran; ?></td>
                    <td>
                        <a href="<?php echo site_url('NilaiController/edit/' . $n->id_nilai); ?>">Edit</a>
                        <a href="<?php echo site_url('NilaiController/delete/' . $n->id_nilai); ?>">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>