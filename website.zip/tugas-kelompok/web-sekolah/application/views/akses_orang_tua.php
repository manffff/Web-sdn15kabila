<!DOCTYPE html>
<html>

<head>
    <title>Akses Orang Tua</title>
</head>

<body>
    <h1>Akses Orang Tua</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID Siswa</th>
                <th>Nama Siswa</th>
                <th>Mata Pelajaran</th>
                <th>Jenis Penilaian</th>
                <th>Nilai</th>
                <th>Semester</th>
                <th>Tahun Ajaran</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($nilai as $n): ?>
                <tr>
                    <td><?php echo $n->id_siswa; ?></td>
                    <td><?php echo $n->nama_siswa; ?></td>
                    <td><?php echo $n->nama_mapel; ?></td>
                    <td><?php echo $n->jenis_nilai; ?></td>
                    <td><?php echo $n->nilai; ?></td>
                    <td><?php echo $n->semester; ?></td>
                    <td><?php echo $n->tahun_ajaran; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>