<div class="home">
		<div class="home_slider_container">
			
			<!-- Home Slider -->
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Home Slider Item -->
				<div class="owl-item">
                <div class="home_slider_background" style="background-image:url(<?= base_url() ?>template/front-end/images/foto_bersama.png); background-size: contain; background-position: center; background-repeat: no-repeat;"></div>

		</div>
	</div>
	

    <!-- Features -->

	<div class="features">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title">Selamat Datang Di Web Sekolah</h2>
						<div class="section_subtitle"><p>Selamat Datang di Website Resmi Sekolah Kami – Gerbang Menuju Pendidikan Berkualitas, Prestasi Gemilang, dan Informasi Terkini</p></div>
					</div>
				</div>
			</div>
			<div class="row features_row">
				
				<!-- Features Item -->
				<div class="col-lg-3 feature_col">
					<div class="feature text-center trans_400">
						<div class="feature_icon"><img src="<?= base_url() ?>template/front-end/images/icon_1.png" alt=""></div>
						<h3 class="feature_title">Tentang</h3>
						
					</div>
				</div>

				<!-- Features Item -->
				<div class="col-lg-3 feature_col">
					<div class="feature text-center trans_400">
						<div class="feature_icon"><img src="<?= base_url() ?>template/front-end/images/icon_2.png" alt=""></div>
						<h3 class="feature_title">Galeri</h3>
						
					</div>
				</div>

				<!-- Features Item -->
				<div class="col-lg-3 feature_col">
					<div class="feature text-center trans_400">
						<div class="feature_icon"><img src="<?= base_url() ?>template/front-end/images/icon_3.png" alt=""></div>
						<h3 class="feature_title">Berita</h3>
						
					</div>
				</div>

				<!-- Features Item -->
				<div class="col-lg-3 feature_col">
					<div class="feature text-center trans_400">
						<div class="feature_icon"><img src="<?= base_url() ?>template/front-end/images/icon_4.png" alt=""></div>
						<h3 class="feature_title">Hubungi Kami</h3>
						
					</div>
				</div>
				

			</div>
		</div>
	</div>

	<!-- Popular Courses -->

	<div class="courses">
		<div class="section_background parallax-window" data-parallax="scroll" data-image-src="images/courses_background.jpg" data-speed="0.8"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title">Berita</h2>
						<div class="section_subtitle"><p>"Berita – Informasi Seputar Kegiatan dan Prestasi Sekolah"</p></div>
					</div>
				</div>
			</div>
			<div class="row courses_row">
				
				<!-- Course -->
				<?php foreach ($berita as $key =>$value) { ?>
					<br><br>
				<div class="col-lg-4 course_col">
					<div class="course">
						<div class="course_image"><img src="<?= base_url('foto_berita/'.$value->foto_berita) ?>"height="230px"></div>
						<div class="course_body">
							<h3 class="course_title"><a href="<?=base_url('home/detail_berita/'.$value->slug_berita) ?>"><?= substr(strip_tags($value->judul_berita),0, 25) ?>...</a></h3>
							<div class="course_teacher">By <a href="#">admin</a></div>
							<div class="course_text">
								<p><?= substr(strip_tags($value->isi_berita),0, 95) ?>..</p>
							</div>
						</div>
						<div class="course_footer">
							<div class="course_footer_content d-flex flex-row align-items-center justify-content-start">
								<div class="course_info">
									<i class="fa fa-calendar" aria-hidden="true"></i>
									<span><?= $value->tgl_berita ?></span>
								</div>
								
								
							</div>
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
			<div class="row">
				<div class="col">
					<div class="courses_button trans_200"><a href="<?= base_url('home/berita') ?>">view all news</a></div>
				</div>
			</div>
		</div>
	</div>

	
	<!-- Team -->

	<div class="team">
		<div class="team_background parallax-window" data-parallax="scroll" data-image-src="images/team_background.jpg" data-speed="0.8"></div>
		<div class="container">
			<div class="row">
			</div>
		</div>
	</div>

	

	<!-- Newsletter -->

	<div class="newsletter">
		<div class="newsletter_background parallax-window" data-parallax="scroll" data-image-src="images/newsletter.jpg" data-speed="0.8"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="newsletter_container d-flex flex-lg-row flex-column align-items-center justify-content-start">

						<!-- Newsletter Content -->
						<div class="newsletter_content text-lg-left text-center">
							<div class="newsletter_title">sign up for news and offers</div>
							<div class="newsletter_subtitle">Subcribe to lastest smartphones news & great deals we offer</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
