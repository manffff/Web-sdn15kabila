<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Web Sekolah - <?= $title ?></title>

        <!-- Bootstrap Core CSS -->
        <link href="<?= base_url() ?>template/back-end/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?= base_url() ?>template/back-end/css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <style>
            body {
                background-color: #D3D3D3; /* Warna abu-abu muda */
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                font-family: 'Arial', sans-serif;
            }
            .login-panel {
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                border-radius: 10px;
            }
            .panel-heading {
                background-color: #5cb85c; /* Hijau lembut */
                color: #fff;
                text-align: center;
                padding: 15px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
            }
            .panel-body {
                padding: 50px;
                background-color: #ffffff;
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
            }
            .btn-success {
                width: 100%;
                background-color: #5cb85c;
                border-color: #4cae4c;
            }
            .btn-primary {
                margin-top: 10px;
                width: 100%;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title"><?= $title ?></h3>
                        </div>
                        <div class="panel-body">
                            <!-- Tampilkan pesan flash untuk error atau logout -->
                            <?php if ($this->session->flashdata('error')): ?>
                                <div class="alert alert-danger">
                                    <?= $this->session->flashdata('error'); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($logout_message)): ?>
                                <div class="alert alert-success">
                                    <?= $logout_message; ?>
                                </div>
                            <?php endif; ?>

                            <?php 
                            echo form_open('login'); 
                            ?>
                                <fieldset>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Username" name="username" type="text" autofocus required>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Password" name="password" type="password" required>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-success">Login</button>
                                        <a class="btn btn-primary" href="<?= base_url() ?>">Web Sekolah</a>
                                    </div>
                                </fieldset>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- jQuery -->
        <script src="<?= base_url() ?>template/back-end/js/jquery.min.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="<?= base_url() ?>template/back-end/js/bootstrap.min.js"></script>
    </body>
</html>
