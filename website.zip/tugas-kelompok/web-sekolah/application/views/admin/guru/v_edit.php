<d class="col-lg-12">
<div class="panel panel-primary">
    <div class="panel-heading">
    Edit Data Guru
     </div>
    <div class="panel-body">
        <?php

        echo validation_errors('<div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>','</div>');



            if (isset($error_upload)){
                echo '<div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$error_upload.'</div>';
            }


        echo form_open_multipart('guru/edit/'.$guru->id_guru);       
        ?>
            <div class="form-group">
                <label>NIP</label>
                <input class="form-control" value="<?= $guru->nip ?>"type="text" name="nip" placeholder="NIP" required>
            </div>
            <div class="form-group">
                <label>Nama Guru</label>
                <input class="form-control"  value="<?= $guru->nama_guru ?>"type="text" name="nama_guru" placeholder="Nama Guru" required>
            </div>
            <div class="form-group">
                <label>Tempat Lahir</label>
                <input class="form-control" value="<?= $guru->tempat_lahir ?>"type="text" name="tempat_lahir" placeholder="Tempat Lahir" required>
            </div>
            <div class="form-group">
            <img src="<?= base_url('foto_guru/'.$guru->foto_guru) ?>" width="150px">
                
            </div>
            <div class="form-group">
            <label>Ganti Foto</label>
            <input type="file" class="form-control" value="<?= $guru->foto_guru ?>"type="text" name="foto_guru">

            </div>
            </div>
            <div class="form-group" style="margin-left: 20px;">
                <button type="submit" class="btn btn-primary"> Simpan </button>
                <button type="reset" class="btn btn-success" > Reset </button>
            </div>
    

    <?php echo form_close(); ?>
</div>
</div>
