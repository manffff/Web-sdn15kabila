<d class="col-lg-12">
<div class="panel panel-primary">
    <div class="panel-heading">
    Add Data
     </div>
    <div class="panel-body">
        <?php
            if (isset($error_upload)){
                echo '<div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$error_upload.'</div>';
            }


        echo form_open_multipart('guru/add');       
        ?>
            <div class="form-group">
                <label>NIP</label>
                <input class="form-control" type="text" name="nip" placeholder="NIP" required>
            </div>
            <div class="form-group">
                <label>Nama Guru</label>
                <input class="form-control" type="text" name="nama_guru" placeholder="Nama Guru" required>
            </div>
            <div class="form-group">
                <label>Tempat Lahir</label>
                <input class="form-control" type="text" name="tempat_lahir" placeholder="Tempat Lahir" required>
            </div>
            <div class="form-group">
                <label>Foto Guru</label>
                <input type="file" class="form-control" type="text" name="foto_guru" required>
            </div>
            </div>
            <div class="form-group" style="margin-left: 20px;">
                <button type="submit" class="btn btn-primary"> Simpan </button>
                <a href="<?= base_url('guru') ?>" class="btn btn-success"> Back </a>
            </div>
    

    <?php echo form_close(); ?>
</div>
</div>
