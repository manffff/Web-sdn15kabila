<?php
echo form_open_multipart('admin/setting'); // Form Open untuk multipart

// Menampilkan pesan sukses jika ada
if ($this->session->flashdata('pesan')) {
    echo '<div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
    echo $this->session->flashdata('pesan');
    echo '</div>';
}

// Menampilkan pesan error jika ada
if ($this->session->flashdata('error')) {
    echo '<div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
    echo $this->session->flashdata('error');
    echo '</div>';
}
?>
<div class="col-sm-4">
    <label for="">Kepala Sekolah</label><br>
    <!-- Menampilkan foto kepala sekolah -->
    <img src="<?= base_url('foto_kepsek/'.$setting->foto_kepsek) ?>" width="200px" height="260px">
    <br>

    <div class="form-group">
        <label>Ganti Foto</label>
        <!-- Perbaiki input file -->
        <input type="file" class="form-control" name="foto_kepsek">
    </div>
</div>

<div class="col-sm-8">
    <div class="form-group">
        <label>Nama Sekolah</label>
        <!-- Perbaiki penulisan name menjadi nama_sekolah -->
        <input type="text" class="form-control" value="<?= $setting->nama_sekolah ?>" name="nama_sekolah">
    </div>
    <div class="form-group">
        <label>Alamat</label>
        <!-- Perbaiki penulisan name menjadi alamat -->
        <input type="text" class="form-control" value="<?= $setting->alamat ?>" name="alamat">
    </div>
    <div class="form-group">
        <label>No Telpon</label>
        <!-- Perbaiki penulisan name menjadi no_telpon -->
        <input type="text" class="form-control" value="<?= $setting->no_telpon ?>" name="no_telpon">
    </div>
    <div class="form-group">
        <label>Kepala Sekolah</label>
        <!-- Perbaiki penulisan name menjadi kepala_sekolah -->
        <input type="text" class="form-control" value="<?= $setting->kepala_sekolah ?>" name="kepala_sekolah">
    </div>
    <div class="form-group">
        <label>NIP</label>
        <!-- Perbaiki penulisan name menjadi nip -->
        <input type="text" class="form-control" value="<?= $setting->nip ?>" name="nip">
    </div>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            <label>Sejarah Sekolah</label>
            <!-- Perbaiki penulisan name menjadi sejarah -->
            <textarea class="form-control" name="sejarah" rows="5"><?= $setting->sejarah ?></textarea>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label>Visi</label>
            <!-- Perbaiki penulisan name menjadi visi -->
            <textarea class="form-control" name="visi" rows="5"><?= $setting->visi ?></textarea>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label>Misi</label>
            <!-- Perbaiki penulisan name menjadi misi -->
            <textarea class="form-control" name="misi" rows="5"><?= $setting->misi ?></textarea>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <button type="submit" class="btn btn-success btn-sm">Update</button>
        </div>
    </div>
</div>

<?php echo form_close(); ?>
