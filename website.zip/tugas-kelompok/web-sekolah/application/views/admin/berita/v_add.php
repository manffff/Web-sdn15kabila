<d class="col-lg-12">
<div class="panel panel-primary">
    <div class="panel-heading">
    Add Data
     </div>
    <div class="panel-body">
        <?php
            if (isset($error_upload)){
                echo '<div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$error_upload.'</div>';
            }

            echo validation_errors('<div class="alert alert-warning alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>','</div>');


            echo form_open_multipart('berita/add');       
        ?>
            <div class="form-group">
                <label>Judul Berita</label>
                <input class="form-control" type="text" name="judul_berita" placeholder="Judul Berita" required>
            </div>
            <div class="form-group">
                <label>Foto Berita</label>
                <input type="file" class="form-control" type="text" name="foto_berita" required>
            </div>
            <div class="form-group"> 
                <label>Isi Berita</label>
                <textarea name="isi_berita" id="editor" required></textarea>
            </div>
            
            <div class="form-group" style="margin-left: 20px;">
                <button type="submit" class="btn btn-primary"> Simpan </button>
                <a href="<?= base_url('berita') ?>" class="btn btn-success"> Back </a>
            </div>
    

    <?php echo form_close(); ?>
</div>
</div>
