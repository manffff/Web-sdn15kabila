<div class="col-lg-12">
<div class="panel panel-primary">
    <div class="panel-heading">
    Edit Data Berita
     </div>
    <div class="panel-body">
        <?php

        echo validation_errors('<div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>','</div>');



            if (isset($error_upload)){
                echo '<div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$error_upload.'</div>';
            }


        echo form_open_multipart('berita/edit/'.$berita->id_berita);       
        ?>
            <div class="form-group">
                <label>Judul Berita</label>
                <input class="form-control" value="<?= $berita->judul_berita ?>"type="text" name="judul_berita" placeholder="Jusul Berita" required>
            </div>

            <div class="form-group">
            <label>Isi Berita</label>
            <textarea name="isi_berita" id="editor" required><?= $berita->isi_berita ?></textarea>

            <div class="form-group">
            <img src="<?= base_url('foto_berita/'.$berita->foto_berita) ?>" width="150px">
            <div class="form-group">
                <label>Foto Berita</label>
                <input type="file" class="form-control" type="text" name="foto_berita">
            </div>
            </div>
            

            </div>
            </div>
            <div class="form-group" style="margin-left: 20px;">
                <button type="submit" class="btn btn-primary"> Simpan </button>
                <button type="reset" class="btn btn-success" > Reset </button>
            </div>
    

    <?php echo form_close(); ?>
</div>
</div>
