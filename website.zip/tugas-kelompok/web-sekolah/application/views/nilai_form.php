<!DOCTYPE html>
<html>

<head>
    <title>Input Nilai</title>
</head>

<body>
    <h1>Input Nilai Siswa</h1>
    <form action="<?php echo site_url('NilaiController/simpan'); ?>" method="post">
        <label for="id_siswa">Siswa:</label>
        <select name="id_siswa" required>
            <?php foreach ($siswa as $s): ?>
                <option value="<?php echo $s->id_siswa; ?>"><?php echo $s->nama; ?></option>
            <?php endforeach; ?>
        </select><br>

        <label for="id_mapel">Mata Pelajaran:</label>
        <select name="id_mapel" required>
            <?php foreach ($mata_pelajaran as $mapel): ?>
                <option value="<?php echo $mapel->id_mapel; ?>"><?php echo $mapel->nama_mapel; ?></option>
            <?php endforeach; ?>
        </select><br>

        <label for="jenis_nilai">Jenis Penilaian:</label>
        <input type="text" name="jenis_nilai" required><br>

        <label for="nilai">Nilai:</label>
        <input type="number" name="nilai" required><br>

        <label for="semester">Semester:</label>
        <input type="text" name="semester" required><br>

        <label for="tahun_ajaran">Tahun Ajaran:</label>
        <input type="text" name="tahun_ ajaran" required><br>

        <button type="submit">Simpan</button>
    </form>
</body>

</html>