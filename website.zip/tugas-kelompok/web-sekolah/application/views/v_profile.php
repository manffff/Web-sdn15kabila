<!-- Home -->
<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="<?= base_url() ?>">Home</a></li>
								<li>Profile Sekolah</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

    <div class="contact_info_container">
			<div class="container">
				<div class="row">

            <div class="col-sm-4 text-center">
                <img src="<?= base_url('foto_kepsek/'.$sekolah->foto_kepsek) ?>" width="200px" height="260px">
                <br>
                <h4><?= $sekolah->kepala_sekolah ?></h4>
                <h4>NIP : <?= $sekolah->nip ?></h4>
            </div>
            <div class="col-sm-8">
                <div class="form-group">
                <div class="form_title">Nama Sekolah</div>
                <input type="text" class="comment_input" value="<?= $sekolah->nama_sekolah ?>" name="nama_sekolah" readonly>
                </div>

                <div class="form-group">
                <div class="form_title">Alamat</div>
                <input type="text" class="comment_input" value="<?= $sekolah->alamat ?>" name="alamat" readonly>
                </div>

                <div class="form-group">
                <div class="form_title">No Telpon</div>
                <input type="text" class="comment_input" value="<?= $sekolah->no_telpon ?>" name="no_telpon" readonly>
                </div>
            </div>
            <div class="col-sm-12">
    <div class="form-group"><br><br>
        <div class="form_title"><h4>Sejarah Sekolah</h4></div>
        <!-- Menambahkan style untuk meratakan teks kiri-kanan -->
        <p style="text-align: justify;"><?= $sekolah->sejarah ?></p>
    </div>
</div>

<div class="col-sm-12">
    <div class="form-group">
        <div class="form_title"><h4>Visi</h4></div>
        <!-- Menambahkan style untuk meratakan teks kiri-kanan -->
        <p style="text-align: justify;"><?= $sekolah->visi ?></p>
    </div>
</div>

<div class="col-sm-12">
    <div class="form-group">
        <div class="form_title"><h4>Misi</h4></div>
        <!-- Menggunakan ordered list untuk misi -->
        <ol style="padding-left: 20px;">
            <!-- Menampilkan misi dalam urutan terstruktur -->
            <?php 
                // Memisahkan misi berdasarkan baris baru
                $misi_list = explode("\n", $sekolah->misi); 

                // Memastikan bahwa array misi tidak kosong
                if (!empty($misi_list)) {
                    foreach ($misi_list as $misi) {
                        // Menghapus spasi di awal dan akhir jika ada
                        $misi = trim($misi);
                        
                        // Cek jika misi tidak kosong setelah trim
                        if (!empty($misi)) {
                            echo "<li>$misi</li>";
                        }
                    }
                }
            ?>
        </ol>
    </div>
</div>


        </div>
    </div>
</div>
	