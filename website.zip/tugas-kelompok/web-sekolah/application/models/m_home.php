<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_home extends CI_Model{
    public function guru()
    {
        $this->db->select('*');
        $this->db->from('tbl_guru');
        $this->db->order_by('id_guru', 'desc');
        return $this->db->get()->result();
    }
    public function berita($limit,$start)
    {
        $this->db->select('*');
        $this->db->from('tbl_berita');
        $this->db->order_by('id_berita', 'desc');
        $this->db->limit($limit,$start);
        return $this->db->get()->result();
    }
    public function total_berita( )
    {
        $this->db->select('*');
        $this->db->from('tbl_berita');
        $this->db->order_by('id_berita', 'desc');
        return $this->db->get()->result();
    }
    public function detail_berita($slug_berita)
    {
        $this->db->select('*');
        $this->db->from('tbl_berita');
        $this->db->where('slug_berita', $slug_berita);
        return $this->db->get()->row();
    }
    public function latest_berita()
    {
        $this->db->select('*');
        $this->db->from('tbl_berita');
        $this->db->order_by('id_berita', 'desc');
        $this->db->limit(3);
        return $this->db->get()->result();
    }
    public function gallery()
    {
        $this->db->select('tbl_gallery.*,count(tbl_foto.id_gallery) as jml_foto');
        $this->db->from('tbl_gallery');
        $this->db->join('tbl_foto', 'tbl_foto.id_gallery = tbl_gallery.id_gallery', 'left');
        $this->db->group_by('tbl_gallery.id_gallery');
        $this->db->order_by('tbl_gallery.id_gallery', 'desc');
        return $this->db->get()->result();
    }
    public function detail_gallery($id_gallery)
    {
        $this->db->select('*');
        $this->db->from('tbl_foto');
        $this->db->where('id_gallery', $id_gallery);
        $this->db->order_by('id_foto', 'desc');
        return $this->db->get()->result();
    }
    public function nama_gallery($id_gallery)
    {
        $this->db->select('*');
        $this->db->from('tbl_gallery');
        $this->db->where('id_gallery', $id_gallery);
        return $this->db->get()->row();
    }
    public function course_berita()
    {
        $this->db->select('*');
        $this->db->from('tbl_berita');
        $this->db->order_by('id_berita','desc');
        $this->db->limit(6);
        return $this->db->get()->result();
    }
    public function save_message($data) {
        return $this->db->insert('messages', $data);
    }
}
