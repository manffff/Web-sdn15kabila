<?php
defined('BASEPATH') or exit('No direct script access allowed');

class NilaiModel extends CI_Model
{

    public function getSiswa()
    {
        return $this->db->get('siswa')->result();
    }

    public function getMataPelajaran()
    {
        return $this->db->get('mata_pelajaran')->result();
    }

    public function simpanNilai($data)
    {
        return $this->db->insert('nilai', $data);
    }

    public function getNilai($id_siswa)
    {
        $this->db->where('id_siswa', $id_siswa);
        return $this->db->get('nilai')->result();
    }

    public function editNilai($data, $id_nilai)
    {
        $this->db->where('id_nilai', $id_nilai);
        return $this->db->update('nilai', $data);
    }

    public function deleteNilai($id_nilai)
    {
        $this->db->where('id_nilai', $id_nilai);
        return $this->db->delete('nilai');
    }
}
